/** Automatically generated file. DO NOT MODIFY */
package com.webview.hotdeal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}