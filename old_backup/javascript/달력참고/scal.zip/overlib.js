
var width = "180";
var border = "2";
var offsety = 4;
var fcolor = "white";
var backcolor = "#C89FB2";
var textcolor = "black";
var capcolor = "#ffffff";
var closecolor = "#99FF99";

ns4 = (document.layers)? true:false
ie4 = (document.all)? true:false
var x = 0;
var y = 0;
var snow = 0;
var sw = 0;
var cnt = 0;
var dir = 1;

if ( (ns4) || (ie4) ) {
	if (ns4) over = document.overDiv
	if (ie4) over = overDiv.style
	document.onmousemove = mouseMove
	if (ns4) document.captureEvents(Event.MOUSEMOVE)
}

function drc(d, text, title) {
	dtc(d, text,title);
}
function nd() {
	if ( cnt >= 1 ) { sw = 0 };
	if ( (ns4) || (ie4) ) {
		if ( sw == 0 ) {
			snow = 0;
			hideObject(over);
		} else {
			cnt++;
		}
	}
}
function dtc(d,text, title) {
	txt = "<TABLE WIDTH="+width+" STYLE=\"border:1 black solid\" CELLPADDING="+border+" CELLSPACING=0><TR><TD BGCOLOR=\""+backcolor+"\"><TABLE WIDTH=100% BORDER=0 CELLPADDING=0 CELLSPACING=0><TR><TD align=center><SPAN ID=\"PTT\"><FONT COLOR=\""+capcolor+"\"><B>"+title+"</B></FONT></SPAN></TD></TR></TABLE><TABLE WIDTH=100% BORDER=0 CELLPADDING=2 CELLSPACING=0 BGCOLOR=\""+fcolor+"\"><TR><TD align=left><SPAN ID=\"PST\"><FONT COLOR=\""+textcolor+"\">"+text+"</FONT><SPAN></TD></TR></TABLE></TD></TR></TABLE>"
	layerWrite(txt);
	dir = d;
	disp();
}
function disp() {
	if ( (ns4) || (ie4) ) {
		if (snow == 0) 	{
			moveTo(over,x-dir,y+offsety);
			showObject(over);
			snow = 1;
		}
	}
}
function mouseMove(e) {
	if (ns4) {x=e.pageX; y=e.pageY}
	if (ie4) {x=event.x; y=event.y}
	if (snow) {
		moveTo(over,x-dir,y+offsety);
	}
}
function cClick() {
	hideObject(over);
	sw=0;
}
function layerWrite(txt) {
        if (ns4) {
                var lyr = document.overDiv.document
                lyr.write(txt)
                lyr.close()
        }
        else if (ie4) document.all["overDiv"].innerHTML = txt
		
}
function showObject(obj) {
        if (ns4) obj.visibility = "show"
        else if (ie4) obj.visibility = "visible"
}
function hideObject(obj) {
        if (ns4) obj.visibility = "hide"
        else if (ie4) obj.visibility = "hidden"
}
function moveTo(obj,xL,yL) {
        obj.left = xL
        obj.top = yL
}

