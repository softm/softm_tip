#if !defined(AFX_ALLSEND2SERVERSOCKET_H__A24BD48C_9725_42E4_8515_9397FAEB1ED6__INCLUDED_)
#define AFX_ALLSEND2SERVERSOCKET_H__A24BD48C_9725_42E4_8515_9397FAEB1ED6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AllSend2ServerSocket.h : header file
//
#include "AllSend2ClientSocket.h"

#define WM_RECIVEDATA WM_USER+1
#define WM_DISCONNCET WM_USER+2
#define WM_ACCEPT WM_USER+4
#define WM_SEND WM_USER+5

/////////////////////////////////////////////////////////////////////////////
// AllSend2ServerSocket command target
#ifndef __ALLSEND2SERVERSOCKET_H__
#define __ALLSEND2SERVERSOCKET_H__

class AllSend2ServerSocket : public CAsyncSocket
{
// Attributes
public:
	
private:
	HWND m_hWnd;	

// Operations
public:
	AllSend2ServerSocket();
	virtual ~AllSend2ServerSocket();
	void SetHwnd(HWND hWnd);	

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(AllSend2ServerSocket)
	public:
	virtual void OnAccept(int nErrorCode);
	virtual void OnClose(int nErrorCode);	
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(AllSend2ServerSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG	
// Implementation
protected:
};

#endif
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALLSEND2SERVERSOCKET_H__A24BD48C_9725_42E4_8515_9397FAEB1ED6__INCLUDED_)
