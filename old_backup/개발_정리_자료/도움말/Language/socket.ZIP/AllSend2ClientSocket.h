#if !defined(AFX_ALLSEND2CLIENTSOCKET_H__BD785746_1AD1_40DD_88B3_8B6614963592__INCLUDED_)
#define AFX_ALLSEND2CLIENTSOCKET_H__BD785746_1AD1_40DD_88B3_8B6614963592__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AllSend2ClientSocket.h : header file
//
#include "packet.h"

#define WM_RECIVEDATA WM_USER+1
#define WM_DISCONNCET WM_USER+2
#define WM_CONNCET WM_USER+3
#define WM_SEND WM_USER+5

/////////////////////////////////////////////////////////////////////////////
// AllSend2ClientSocket command target
#ifndef __ALLSEND2CLIENTSOCKET_H__
#define __ALLSEND2CLIENTSOCKET_H__

class AllSend2ClientSocket : public CAsyncSocket
{
// Attributes
public:

private:
	HWND m_hWnd;	
// Operations
public:
	AllSend2ClientSocket();
	virtual ~AllSend2ClientSocket();
	void SetHwnd(HWND hWnd);

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(AllSend2ClientSocket)
	public:
	virtual void OnClose(int nErrorCode);
	virtual void OnConnect(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
//	virtual void OnSend(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(AllSend2ClientSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

#endif
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALLSEND2CLIENTSOCKET_H__BD785746_1AD1_40DD_88B3_8B6614963592__INCLUDED_)
