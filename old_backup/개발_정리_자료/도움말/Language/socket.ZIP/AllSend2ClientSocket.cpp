// AllSend2ClientSocket.cpp : implementation file
//

#include "stdafx.h"
#include "allsend2.h"
#include "AllSend2ClientSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// AllSend2ClientSocket

AllSend2ClientSocket::AllSend2ClientSocket()
{
}

AllSend2ClientSocket::~AllSend2ClientSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(AllSend2ClientSocket, CAsyncSocket)
	//{{AFX_MSG_MAP(AllSend2EClientSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// AllSend2ClientSocket member functions

void AllSend2ClientSocket::OnClose(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	SendMessage(this->m_hWnd, WM_DISCONNCET, (WPARAM)this, (LPARAM)nErrorCode);

	CAsyncSocket::OnClose(nErrorCode);
}

void AllSend2ClientSocket::OnConnect(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	SendMessage(this->m_hWnd, WM_CONNCET, (WPARAM)this, (LPARAM)nErrorCode);
	
	CAsyncSocket::OnConnect(nErrorCode);
}

void AllSend2ClientSocket::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class	

	SendMessage(this->m_hWnd, WM_RECIVEDATA, (WPARAM)this, (LPARAM)nErrorCode);


	CAsyncSocket::OnReceive(nErrorCode);
}

void AllSend2ClientSocket::SetHwnd(HWND hWnd)
{
	m_hWnd = hWnd;
}
/*
void AllSend2ClientSocket::OnSend(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class
	SendMessage(this->m_hWnd, WM_SEND, (WPARAM)this, (LPARAM)nErrorCode);	
	
	CAsyncSocket::OnSend(nErrorCode);
}
*/