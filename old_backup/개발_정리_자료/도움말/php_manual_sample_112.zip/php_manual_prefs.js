prefs_online  = true;
prefs_mirror  = "http://us.php.net/";
prefs_context_override = true;
prefs_context_names = Array(
    "Manual TOC",
    "Function Reference",
    "Functions Index",
    "_Separator_",
    "Copy selection to clipboard",
    "Google Search Selection",
    "AlltheWeb SearchBox"
);
prefs_context_values = Array(
    "index.html",
    "funcref.html",
    "indexes.html",
    "_Separator_",
    "copySelection()",
    "searchSelGoogle()",
    "_ATWSearch_"
);
prefs_skin = "Low";
prefHandler();
