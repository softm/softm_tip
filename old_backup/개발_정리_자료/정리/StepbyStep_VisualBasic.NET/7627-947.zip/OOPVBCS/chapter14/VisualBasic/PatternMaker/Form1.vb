Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents templates As System.Windows.Forms.Panel
    Friend WithEvents patterns As System.Windows.Forms.Panel
    Friend WithEvents editor As System.Windows.Forms.GroupBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.templates = New System.Windows.Forms.Panel()
        Me.patterns = New System.Windows.Forms.Panel()
        Me.editor = New System.Windows.Forms.GroupBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Templates"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(120, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Editor"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 232)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Patterns"
        '
        'templates
        '
        Me.templates.AutoScroll = True
        Me.templates.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.templates.Location = New System.Drawing.Point(16, 48)
        Me.templates.Name = "templates"
        Me.templates.Size = New System.Drawing.Size(90, 168)
        Me.templates.TabIndex = 3
        '
        'patterns
        '
        Me.patterns.AutoScroll = True
        Me.patterns.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.patterns.Location = New System.Drawing.Point(16, 256)
        Me.patterns.Name = "patterns"
        Me.patterns.Size = New System.Drawing.Size(304, 90)
        Me.patterns.TabIndex = 4
        '
        'editor
        '
        Me.editor.Location = New System.Drawing.Point(120, 40)
        Me.editor.Name = "editor"
        Me.editor.Size = New System.Drawing.Size(200, 175)
        Me.editor.TabIndex = 5
        Me.editor.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(336, 358)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.editor, Me.patterns, Me.templates, Me.Label3, Me.Label2, Me.Label1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim drawn1 As New DrawnPattern()
        drawn1.Points = New Point() {New Point(0, 30), New Point(60, 30), _
            New Point(60, 0), New Point(30, 0), New Point(30, 60)}
        Dim drawn2 As New DrawnPattern()
        drawn2.Points = New Point() {New Point(30, 0), New Point(60, 30), _
            New Point(30, 60), New Point(0, 30), New Point(30, 0), _
            New Point(0, 0)}
        Dim bitmap1 As New BitmapPattern()
        bitmap1.BitmapFile = "c:\OOPVBCS\Chapter10\bearpaw.bmp"
        Dim patterns() As Pattern = {drawn1, bitmap1, drawn2}
        Dim pt As Integer
        For pt = 0 To patterns.Length - 1
            Dim button As New PatternButton(patterns(pt))
            button.Top = 70 * pt
            button.Left = 5
            AddHandler button.Click, AddressOf Me.TemplateClick
            Me.templates.Controls.Add(button)
        Next
    End Sub

    Private m_newPattern As Pattern = Nothing
    Private Sub TemplateClick(ByVal sender As Object, ByVal e As EventArgs)
        Dim button As PatternButton = CType(sender, PatternButton)
        m_newPattern = button.Pattern.Clone()
        Dim designer As PatternEditor = m_newPattern.GetEditor()
        designer.Location = New Point(10, 10)
        Me.editor.Controls.Add(designer)
        AddHandler designer.Saved, AddressOf Me.PatternSaved
    End Sub

    Private Sub PatternSaved(ByVal sender As Object, ByVal e As EventArgs)
        Me.Controls.Remove(CType(sender, Control))
        CType(sender, Control).Dispose()
        Dim pb As PatternButton = New PatternButton(m_newPattern)
        pb.Left = Me.patterns.Controls.Count * 70
        pb.Top = 5
        pb.Enabled = False
        Me.patterns.Controls.Add(pb)
    End Sub
End Class

Public Class PatternButton
    Inherits UserControl
    Private m_pattern As Pattern
    Public Sub New(ByVal newPattern As Pattern)
        Me.Size = New Size(61, 61)
        m_pattern = newPattern
        AddHandler Me.Paint, AddressOf newPattern.Draw
    End Sub
    Public Property Pattern() As Pattern
        Get
            Return m_pattern
        End Get
        Set(ByVal Value As Pattern)
            m_pattern = Value
        End Set
    End Property
End Class