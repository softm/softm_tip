Public Class BitmapPattern
    Inherits Pattern

    Private m_bitmapFile As String = ""
    Public Property BitmapFile() As String
        Get
            Return m_bitmapFile
        End Get
        Set(ByVal Value As String)
            m_bitmapFile = Value
        End Set
    End Property

    Public Overrides Sub Draw(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.PaintEventArgs)
        e.Graphics.DrawImage(New _
        System.Drawing.Bitmap(m_bitmapFile), 0, 0)
    End Sub

    Public Overrides Function GetEditor() As PatternEditor
        Return New BitmapPatternEditor(Me)
    End Function

    Public Overrides Function Clone() As Pattern
        Dim newPattern As New BitmapPattern()
        newPattern.BitmapFile = Me.BitmapFile
        Return newPattern
    End Function

End Class