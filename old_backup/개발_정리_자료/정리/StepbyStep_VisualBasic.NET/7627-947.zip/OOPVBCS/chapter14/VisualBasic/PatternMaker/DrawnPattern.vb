Imports System.Drawing
Public Class DrawnPattern
    Inherits Pattern

    Private m_points() As Point = New Point() {}
    Public Property Points() As Point()
        Get
            Return m_points
        End Get
        Set(ByVal Value As Point())
            m_points = Value
        End Set
    End Property

    Public Overrides Sub Draw(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.PaintEventArgs)
        e.Graphics.DrawRectangle(Pens.Black, 0, 0, 60, 60)
        Dim point As Integer
        For point = 0 To m_points.Length - 2
            Dim ptOne As Point = m_points(point)
            Dim ptTwo As Point = m_points(point + 1)
            e.Graphics.DrawLine(System.Drawing.Pens.Black, ptOne, ptTwo)
        Next
    End Sub

    Public Overrides Function GetEditor() As PatternEditor
        Return New DrawnPatternEditor(Me)
    End Function

    Public Overrides Function Clone() As Pattern
        Dim newPattern As New DrawnPattern()
        newPattern.m_points = CType(m_points.Clone(), Point())
        Return newPattern
    End Function


End Class