Public Class BitmapPatternEditor
    Inherits PatternEditor

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents browse As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.browse = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(8, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(61, 61)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'browse
        '
        Me.browse.Location = New System.Drawing.Point(8, 112)
        Me.browse.Name = "browse"
        Me.browse.TabIndex = 1
        Me.browse.Text = "Browse"
        '
        'BitmapPatternEditor
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.browse, Me.PictureBox1})
        Me.Name = "BitmapPatternEditor"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private m_bitmapFile As String
    Private m_pattern As BitmapPattern

    Public Sub New(ByVal pattern As BitmapPattern)
        MyBase.New()
        InitializeComponent()
        m_pattern = pattern
        m_bitmapFile = pattern.BitmapFile
        AddHandler Me.pictureBox1.Paint, AddressOf Me.Draw
    End Sub

    Public Sub Draw(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs)
        e.Graphics.DrawImage(New Bitmap(m_bitmapFile), 0, 0)
    End Sub

    Private Sub browse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles browse.Click
        Me.OpenFileDialog1.ShowDialog()
        If (Me.OpenFileDialog1.FileName.Length <> 0) Then
            m_bitmapFile = Me.OpenFileDialog1.FileName
            Me.PictureBox1.Refresh()
        End If
    End Sub

    Public Overrides Sub SavePattern()
        m_pattern.BitmapFile = m_bitmapFile
    End Sub

End Class
