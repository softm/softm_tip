using System;

namespace PatternMaker
{
	/// <summary>
	/// Summary description for Pattern.
	/// </summary>
	public abstract class Pattern
	{
		public Pattern()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public abstract void Draw(object sender,
			System.Windows.Forms.PaintEventArgs e);
		public abstract PatternEditor GetEditor();
		public abstract Pattern Clone();

	}
}
