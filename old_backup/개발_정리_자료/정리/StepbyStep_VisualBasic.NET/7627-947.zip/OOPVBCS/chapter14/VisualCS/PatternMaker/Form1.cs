using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PatternMaker
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Panel templates;
		private System.Windows.Forms.Panel patterns;
		private System.Windows.Forms.GroupBox editor;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.templates = new System.Windows.Forms.Panel();
			this.patterns = new System.Windows.Forms.Panel();
			this.editor = new System.Windows.Forms.GroupBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 24);
			this.label1.Name = "label1";
			this.label1.TabIndex = 0;
			this.label1.Text = "Templates";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(120, 24);
			this.label2.Name = "label2";
			this.label2.TabIndex = 1;
			this.label2.Text = "Editor";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(16, 232);
			this.label3.Name = "label3";
			this.label3.TabIndex = 2;
			this.label3.Text = "Patterns";
			// 
			// templates
			// 
			this.templates.AutoScroll = true;
			this.templates.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.templates.Location = new System.Drawing.Point(16, 48);
			this.templates.Name = "templates";
			this.templates.Size = new System.Drawing.Size(90, 168);
			this.templates.TabIndex = 3;
			// 
			// patterns
			// 
			this.patterns.AutoScroll = true;
			this.patterns.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.patterns.Location = new System.Drawing.Point(16, 256);
			this.patterns.Name = "patterns";
			this.patterns.Size = new System.Drawing.Size(304, 90);
			this.patterns.TabIndex = 4;
			// 
			// editor
			// 
			this.editor.Location = new System.Drawing.Point(120, 40);
			this.editor.Name = "editor";
			this.editor.Size = new System.Drawing.Size(200, 175);
			this.editor.TabIndex = 5;
			this.editor.TabStop = false;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(336, 358);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.editor,
																		  this.patterns,
																		  this.templates,
																		  this.label3,
																		  this.label2,
																		  this.label1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			DrawnPattern drawn1 =new DrawnPattern();
			drawn1.Points = new Point[]{ new Point(0,30), new Point(60,30),
				new Point(60,0), new Point(30,0), new Point(30,60) };
			DrawnPattern drawn2 = new DrawnPattern();
			drawn2.Points = new Point[]{ new Point(30,0), new Point(60,30),
				new Point(30,60), new Point(0,30), new Point(30,0),
				new Point(0,0)};
			BitmapPattern bitmap1 = new BitmapPattern();
			bitmap1.BitmapFile = @"c:\OOPVBCS\Chapter10\bearpaw.bmp";
			Pattern[] patterns = new Pattern[] { drawn1, bitmap1, drawn2 };
			for (int pt = 0; pt < patterns.Length; pt++ )
			{
				PatternButton button = new PatternButton(patterns[pt]);
				button.Top = 70 * pt;
				button.Left = 5;
				button.Click += new EventHandler(this.TemplateClick);
				this.templates.Controls.Add(button);
			}

		}

		private Pattern m_newPattern = null;
		private void TemplateClick(object sender, EventArgs e)
		{
			PatternButton button =(PatternButton)sender;
			m_newPattern = button.Pattern.Clone();
			PatternEditor designer = m_newPattern.GetEditor();
			designer.Location = new Point(10,10);
			this.editor.Controls.Add(designer);
			designer.Saved += new SavedEventHandler(this.PatternSaved);
		}

		private void PatternSaved(object sender, EventArgs e)
		{
			this.Controls.Remove((Control)sender);
			((Control)sender).Dispose();
			PatternButton pb = new PatternButton(m_newPattern);
			pb.Left = this.patterns.Controls.Count * 70;
			pb.Top = 5;
			pb.Enabled = false;
			this.patterns.Controls.Add(pb);
		}

	}

	public class PatternButton : UserControl 
	{
		private Pattern m_pattern;
		public PatternButton(Pattern newPattern)
		{
			this.Size = new Size(61, 61);
			m_pattern = newPattern;
			this.Paint += new PaintEventHandler(newPattern.Draw);
		}
		public Pattern Pattern 
		{
			get {return m_pattern;}
			set {m_pattern = value;}
		}
	}

}
