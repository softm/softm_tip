using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace PatternMaker
{
	/// <summary>
	/// Summary description for DrawnPatternEditor.
	/// </summary>
	public class DrawnPatternEditor : PatternEditor
	{
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public DrawnPatternEditor()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(8, 16);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(62, 62);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
			this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 88);
			this.label1.Name = "label1";
			this.label1.TabIndex = 1;
			// 
			// DrawnPatternEditor
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label1,
																		  this.pictureBox1});
			this.Name = "DrawnPatternEditor";
			this.Size = new System.Drawing.Size(175, 150);
			this.ResumeLayout(false);

		}
		#endregion

		private Point[] m_points = new Point[0];
		private DrawnPattern m_pattern;

		public DrawnPatternEditor(DrawnPattern pattern)
		{
			InitializeComponent();
			this.m_points = new Point[pattern.Points.Length];
			pattern.Points.CopyTo(this.m_points, 0);
			this.pictureBox1.Paint += new PaintEventHandler(this.Draw);
			m_pattern = pattern;
		}

		public void Draw(object sender,System.Windows.Forms.PaintEventArgs e)
		{
			e.Graphics.DrawRectangle(new Pen(Brushes.Black,1),0,0,60,60);
			for(int point = 0; point < m_points.Length -1; point++)
			{
				Point one = m_points[point];
				Point two = m_points[point + 1];
				e.Graphics.DrawLine(Pens.Black,one,two);
			}
		}

		private void pictureBox1_MouseMove(object sender,
			System.Windows.Forms.MouseEventArgs e)
		{
			this.label1.Text = string.Format("({0}, {1})", e.X, e.Y);
													  
		}

		private void pictureBox1_MouseDown(object sender,
			System.Windows.Forms.MouseEventArgs e)
		{
			Point[]newPoints = new Point[m_points.Length + 1];
			m_points.CopyTo(newPoints,0);
			newPoints[newPoints.Length-1 ] = new Point(e.X,e.Y);
			m_points = newPoints;
			this.Refresh();
		}

		public override void SavePattern()
		{
			m_pattern.Points = m_points;
		}

	}			
}
