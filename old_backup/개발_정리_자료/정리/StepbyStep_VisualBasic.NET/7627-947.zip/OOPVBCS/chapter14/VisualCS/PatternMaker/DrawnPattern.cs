using System;
using System.Drawing;

namespace PatternMaker
{
	/// <summary>
	/// Summary description for DrawnPattern.
	/// </summary>
	public class DrawnPattern : Pattern
	{
		public DrawnPattern()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private Point [] m_points = new Point [0 ];
		public Point [] Points 
		{
			get {return m_points;}
			set {m_points =value;}
		}

		public override void Draw(object sender,
			System.Windows.Forms.PaintEventArgs e)
		{
			e.Graphics.DrawRectangle(Pens.Black,0,0,60,60);
			for(int point = 0; point < m_points.Length -1; point++)
			{
				Point ptOne = m_points[point];
				Point ptTwo = m_points[point+1];
				e.Graphics.DrawLine(System.Drawing.Pens.Black, ptOne, ptTwo);
			}
		}

		public override PatternEditor GetEditor()
		{
			return new DrawnPatternEditor(this);
		}

		public override Pattern Clone()
		{
			DrawnPattern newPattern = new DrawnPattern();
			newPattern.m_points = (Point [])m_points.Clone();
			return newPattern;
		}
	}
}
