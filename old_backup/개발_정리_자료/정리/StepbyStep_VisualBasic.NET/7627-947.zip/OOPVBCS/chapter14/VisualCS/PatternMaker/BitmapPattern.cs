using System;

namespace PatternMaker
{
	/// <summary>
	/// Summary description for BitmapPattern.
	/// </summary>
	public class BitmapPattern : Pattern
	{
		public BitmapPattern()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private string m_bitmapFile ="";
		public string BitmapFile 
		{
			get {return m_bitmapFile;}
			set {m_bitmapFile = value;}
		}

		public override void Draw(object sender,
			System.Windows.Forms.PaintEventArgs e)
		{
			e.Graphics.DrawImage(new
				System.Drawing.Bitmap(m_bitmapFile),0,0);
		}

		public override PatternEditor GetEditor()
		{
			return new BitmapPatternEditor(this);
		}

		public override Pattern Clone()
		{
			BitmapPattern newPattern = new BitmapPattern();
			newPattern.BitmapFile = this.BitmapFile;
			return newPattern;
		}

	}
}
