using System;

namespace ABetterLibrary
{
	/// <summary>
	/// Summary description for Book.
	/// </summary>
	public class Book
	{
		private string m_text;
		private string m_title;
		public string Title 
		{
			get 
			{
				return m_title;
			}
		}
		public string Text 
		{
			get 
			{
				return m_text;
			}
		}
		public Book(string title, string text)
		{
			m_title = title;
			m_text = text;
		}	
	}
}
