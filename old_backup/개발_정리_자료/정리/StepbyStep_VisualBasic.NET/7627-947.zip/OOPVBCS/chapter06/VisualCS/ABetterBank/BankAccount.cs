using System;

namespace ABetterBank
{
	/// <summary>
	/// Summary description for BankAccount.
	/// </summary>
	public abstract class BankAccount
	{
		public BankAccount()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private decimal m_balance;
		public decimal Balance 
		{
			get {return m_balance;}
		}

		private decimal m_totalDeposits;
		public decimal TotalDeposits 
		{
			get {return m_totalDeposits;}
		}

		private decimal m_totalWithdrawals;
		public decimal TotalWithdrawals 
		{
			get {return m_totalWithdrawals;}
		}

		public decimal Deposit(decimal amount)
		{
			m_totalDeposits += amount;
			return (m_balance += amount);
		}
		public virtual decimal Withdraw(decimal amount)
		{
			m_totalWithdrawals += amount;
			return (m_balance -= amount);
		}

		public abstract string ID {get;}

		public abstract string PrintStatement();



	}
}
