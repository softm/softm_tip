using System;

namespace ABetterBank
{
	/// <summary>
	/// Summary description for CheckingAccount.
	/// </summary>
	public class CheckingAccount : BankAccount
	{
		private string m_owner;
		public CheckingAccount(string owner)
		{
			m_owner =owner;
		}
	
		private int m_checks = 0;
		public override decimal Withdraw(decimal amount)
		{
			m_checks++;
			return (base.Withdraw(amount +0.25M));
		}

		public override string PrintStatement()
		{
			string statement =String.Format(
				"{0}\nOpening balance:$0.00 \nDeposits:{1:C}\n" +
				"Withdrawals:{2:C}\nChecks written:{3}\n" +
				"Checking charges:{4:C}\nEnding balance:{5:C}\n",
				new object[] {this.ID,this.TotalDeposits,
				this.TotalWithdrawals -(m_checks *0.25M),
				this.m_checks,this.m_checks *0.25D,this.Balance});
			return statement;
		}

		public override string ID 
		{
			get	{ return m_owner +"-C"; } 
		}

	}
}
