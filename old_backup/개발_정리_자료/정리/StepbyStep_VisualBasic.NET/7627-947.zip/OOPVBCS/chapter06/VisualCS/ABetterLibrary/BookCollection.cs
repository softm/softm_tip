using System;

namespace ABetterLibrary
{
	/// <summary>
	/// Summary description for BookCollection.
	/// </summary>
	public class BookCollection : System.Collections.DictionaryBase
	{
		public BookCollection()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public void Add(Book book)
		{
			this.Dictionary.Add(book.Title,book);
		}

		public void Remove(string title)
		{
			this.Dictionary.Remove(title);
		}

		public Book this [string title ] 
		{
			get 
			{
				if (this.Dictionary.Contains(title)) 
				{
					return (Book)(this.Dictionary [title ]);
				}
				else 
				{
					return null;
				}
			}
		}

	}
}
