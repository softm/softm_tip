Public MustInherit Class BankAccount

    Private m_balance As Decimal = 0D
    Public ReadOnly Property Balance() As Decimal
        Get
            Return m_balance
        End Get
    End Property

    Private m_totalDeposits As Decimal = 0D
    Public ReadOnly Property TotalDeposits() As Decimal
        Get
            Return m_totalDeposits
        End Get
    End Property

    Private m_totalWithdrawals As Decimal = 0D
    Public ReadOnly Property TotalWithdrawals() As Decimal
        Get
            Return m_totalWithdrawals
        End Get
    End Property

    Public Function Deposit(ByVal amount As Decimal) As Decimal
        m_balance += amount
        m_totalDeposits += amount
        Return (m_balance)
    End Function
    Public Overridable Function Withdraw(ByVal amount As Decimal) As Decimal
        m_balance -= amount
        m_totalWithdrawals += amount
        Return m_balance
    End Function

    Public MustOverride ReadOnly Property ID() As String

    Public MustOverride Function PrintStatement() As String



End Class
