Public Class CheckingAccount
    Inherits BankAccount

    Private m_owner As String
    Public Sub New(ByVal owner As String)
        m_owner = owner
    End Sub

    Dim m_checks As Integer = 0
    Public Overrides Function Withdraw(ByVal amount As Decimal) As Decimal
        m_checks += 1
        Return MyBase.Withdraw(amount + 0.25D)
    End Function

    Public Overrides Function PrintStatement() As String
        Dim statement As String = String.Format("{1}{0}" & _
            "Opening balance:$0.00{0}Deposits:{2:C}{0}" & _
            "Withdrawals:{3:C}{0}Checks written:{4}{0}" & _
            "Checking charges:{5:C}{0}Ending balance:{6:C}{0}", _
            New Object() {ControlChars.CrLf, Me.ID, _
            Me.TotalDeposits, Me.TotalWithdrawals - (m_checks * 0.25D), _
            Me.m_checks, Me.m_checks * 0.25D, Me.Balance})
        Return statement
    End Function

    Public Overrides ReadOnly Property ID() As String
        Get
            Return m_owner & "-C"
        End Get
    End Property



End Class
