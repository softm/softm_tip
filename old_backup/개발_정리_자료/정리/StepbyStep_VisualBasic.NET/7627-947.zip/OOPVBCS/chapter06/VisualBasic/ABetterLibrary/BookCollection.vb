Public Class BookCollection
    Inherits System.Collections.DictionaryBase

    Public Sub Add(ByVal aBook As Book)
        Me.Dictionary.Add(aBook.Title, aBook)
    End Sub

    Public Sub Remove(ByVal title As String)
        Me.Dictionary.Remove(title)
    End Sub

    Default Public ReadOnly Property Item(ByVal title As String) As Book
        Get
            If Me.Dictionary.Contains(title) Then
                Return CType(Me.Dictionary(title), Book)
            Else
                Return Nothing
            End If
        End Get
    End Property


End Class
