Public Class SavingsAccount
    Inherits BankAccount
    Private m_owner As String
    Public Sub New(ByVal owner As String)
        m_owner = owner
    End Sub

    Private m_interest As Decimal = 0.01D
    Public Property Interest() As Decimal
        Get
            Return m_interest
        End Get
        Set(ByVal Value As Decimal)
            m_interest = Value
        End Set
    End Property

    Private m_totalInterest As Decimal = 0D
    Public Function AddInterest() As Decimal
        Dim interest As Decimal = m_interest * Me.Balance
        m_totalInterest += interest
        Me.Deposit(interest)
        Return Me.Balance
    End Function

    Public Overrides Function PrintStatement() As String
        Dim statement As String = String.Format("{1}{0}" & _
            "Opening balance:$0.00{0}Deposits:{2:C}{0}" & _
            "Withdrawals:{3:C}{0}Interest:{4:C}{0}" & _
            "Ending balance:{5:C}{0}", _
            New Object() {ControlChars.CrLf, Me.ID, _
            Me.TotalDeposits - m_totalInterest, _
            Me.TotalWithdrawals, Me.m_totalInterest, Me.Balance})
        Return statement
    End Function

    Public Overrides ReadOnly Property ID() As String
        Get
            Return m_owner & "-S"
        End Get
    End Property


End Class
