Public Class Library
    Private m_shelf As New BookCollection()
    Public Sub CheckIn(ByVal newBook As Book)
        m_shelf.Add(newBook)
    End Sub
    Public Function CheckOut(ByVal title As String) As Book
        Dim theBook As Book = m_shelf(title)
        m_shelf.Remove(title)
        Return theBook
    End Function

    Public Shared Sub Main()
        Dim aLibrary As New Library()
        aLibrary.CheckIn(New Book("First Book", _
            "Here is the text of the first book."))
        aLibrary.CheckIn(New Book("Second Book", _
            "Here is the text of the second book."))
        Dim firstBook As Book = aLibrary.CheckOut("First Book")
        Console.WriteLine("The text of '{0}' is '{1}'.", _
            firstBook.Title, firstBook.Text)
        aLibrary.CheckIn(firstBook)
    End Sub
End Class
