Public Class Book
    Private m_text As String
    Private m_title As String
    Public ReadOnly Property Title() As String
        Get
            Return m_title
        End Get
    End Property
    Public ReadOnly Property Text() As String
        Get
            Return m_text
        End Get
    End Property
    Public Sub New(ByVal title As String, ByVal text As String)
        m_title = title
        m_text = text
    End Sub



End Class
