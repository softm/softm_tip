<Serializable()> Public Class Triangle
    Private m_points() As XYPoint = _
        {New XYPoint(), New XYPoint(), New XYPoint()}
    Public Property Points() As XYPoint()
        Get
            Return m_points
        End Get
        Set(ByVal Value As XYPoint())
            If (Value.Length = 3) Then
                m_points = Value
            End If
        End Set
    End Property

    Public Sub New(ByVal a As XYPoint, ByVal b As XYPoint, ByVal c As XYPoint)
        m_points = New XYPoint() {a, b, c}
    End Sub
    Public Overrides Function ToString() As String
        Dim triangleString As String
        Dim point As Integer
        For point = 0 To m_points.Length - 1
            triangleString += m_points(point).ToString() + " "
        Next
        Return triangleString
    End Function

    Public Sub New()
    End Sub

End Class