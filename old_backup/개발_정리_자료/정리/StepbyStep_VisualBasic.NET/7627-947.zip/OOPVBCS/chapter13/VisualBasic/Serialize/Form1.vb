Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Xml.Serialization
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents selectedPoints As System.Windows.Forms.CheckedListBox
    Friend WithEvents triangleList As System.Windows.Forms.ListBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents addTriangle As System.Windows.Forms.Button
    Friend WithEvents removeTriangle As System.Windows.Forms.Button
    Friend WithEvents clearAll As System.Windows.Forms.Button
    Friend WithEvents saveBinary As System.Windows.Forms.Button
    Friend WithEvents loadBinary As System.Windows.Forms.Button
    Friend WithEvents saveXML As System.Windows.Forms.Button
    Friend WithEvents loadXML As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.selectedPoints = New System.Windows.Forms.CheckedListBox()
        Me.triangleList = New System.Windows.Forms.ListBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.addTriangle = New System.Windows.Forms.Button()
        Me.removeTriangle = New System.Windows.Forms.Button()
        Me.clearAll = New System.Windows.Forms.Button()
        Me.saveBinary = New System.Windows.Forms.Button()
        Me.loadBinary = New System.Windows.Forms.Button()
        Me.saveXML = New System.Windows.Forms.Button()
        Me.loadXML = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select three points"
        '
        'selectedPoints
        '
        Me.selectedPoints.Location = New System.Drawing.Point(16, 40)
        Me.selectedPoints.Name = "selectedPoints"
        Me.selectedPoints.Size = New System.Drawing.Size(152, 94)
        Me.selectedPoints.TabIndex = 1
        '
        'triangleList
        '
        Me.triangleList.Location = New System.Drawing.Point(192, 40)
        Me.triangleList.Name = "triangleList"
        Me.triangleList.Size = New System.Drawing.Size(152, 95)
        Me.triangleList.TabIndex = 2
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(192, 16)
        Me.label2.Name = "label2"
        Me.label2.TabIndex = 3
        Me.label2.Text = "Triangles"
        '
        'addTriangle
        '
        Me.addTriangle.Location = New System.Drawing.Point(16, 144)
        Me.addTriangle.Name = "addTriangle"
        Me.addTriangle.TabIndex = 4
        Me.addTriangle.Text = "Add"
        '
        'removeTriangle
        '
        Me.removeTriangle.Location = New System.Drawing.Point(192, 144)
        Me.removeTriangle.Name = "removeTriangle"
        Me.removeTriangle.TabIndex = 5
        Me.removeTriangle.Text = "Remove"
        '
        'clearAll
        '
        Me.clearAll.Location = New System.Drawing.Point(272, 144)
        Me.clearAll.Name = "clearAll"
        Me.clearAll.TabIndex = 6
        Me.clearAll.Text = "Clear All"
        '
        'saveBinary
        '
        Me.saveBinary.Location = New System.Drawing.Point(16, 224)
        Me.saveBinary.Name = "saveBinary"
        Me.saveBinary.TabIndex = 7
        Me.saveBinary.Text = "Save Binary"
        '
        'loadBinary
        '
        Me.loadBinary.Location = New System.Drawing.Point(96, 224)
        Me.loadBinary.Name = "loadBinary"
        Me.loadBinary.TabIndex = 8
        Me.loadBinary.Text = "Load Binary"
        '
        'saveXML
        '
        Me.saveXML.Location = New System.Drawing.Point(192, 224)
        Me.saveXML.Name = "saveXML"
        Me.saveXML.TabIndex = 9
        Me.saveXML.Text = "Save XML"
        '
        'loadXML
        '
        Me.loadXML.Location = New System.Drawing.Point(272, 224)
        Me.loadXML.Name = "loadXML"
        Me.loadXML.TabIndex = 10
        Me.loadXML.Text = "Load XML"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(360, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.loadXML, Me.saveXML, Me.loadBinary, Me.saveBinary, Me.clearAll, Me.removeTriangle, Me.addTriangle, Me.label2, Me.triangleList, Me.selectedPoints, Me.Label1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private m_binaryFile As String = _
        Application.StartupPath + "\triangles.dat"

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim x As Integer
        Dim y As Integer
        For x = 0 To 6
            For y = 0 To 6
                Me.selectedPoints.Items.Add(New XYPoint(x, y))
            Next
        Next
    End Sub

    Private m_triangles As New TriangleCollection()
    Private Sub addTriangle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addTriangle.Click
        Dim checkedPoints As CheckedListBox.CheckedItemCollection = _
        Me.selectedPoints.CheckedItems()
        If checkedPoints.Count = 3 Then
            m_triangles.Add(New Triangle( _
            CType(checkedPoints(0), XYPoint), _
            CType(checkedPoints(1), XYPoint), _
            CType(checkedPoints(2), XYPoint)))
            triangleList.Items.Clear()
            triangleList.Items.AddRange(m_triangles.ToArray())
            Dim item As Integer
            For Each item In selectedPoints.CheckedIndices
                selectedPoints.SetItemChecked(item, False)
            Next
        Else
            MessageBox.Show("You must select exactly three points.")
        End If
    End Sub

    Private Sub removeTriangle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles removeTriangle.Click
        If triangleList.SelectedIndex <> -1 Then
            m_triangles.Remove(CType(triangleList.SelectedItem, Triangle))
            triangleList.Items.Clear()
            triangleList.Items.AddRange(m_triangles.ToArray())
        End If
    End Sub

    Private Sub clearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles clearAll.Click
        m_triangles.Clear()
        triangleList.Items.Clear()
    End Sub

    Private Sub saveBinary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles saveBinary.Click
        Dim stream As _
New System.IO.FileStream(m_binaryFile, System.IO.FileMode.Create)
        Dim binary As New BinaryFormatter()
        binary.Serialize(stream, m_triangles)
        stream.Close()
    End Sub

    Private Sub loadBinary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles loadBinary.Click
        Dim stream As New System.IO.FileStream(m_binaryFile, _
            System.IO.FileMode.Open)
        Dim binary As New BinaryFormatter()
        m_triangles = CType(binary.Deserialize(stream), TriangleCollection)
        stream.Close()
        triangleList.Items.Clear()
        triangleList.Items.AddRange(m_triangles.ToArray())
    End Sub

    Private m_xmlFile As String = Application.StartupPath & "\triangles.xml"

    Private Sub saveXML_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles saveXML.Click
        Dim writer As New System.IO.StreamWriter(m_xmlFile)
        Dim xmlSerial As New XmlSerializer(m_triangles.GetType())
        xmlSerial.Serialize(writer, m_triangles)
        writer.Close()
    End Sub

    Private Sub loadXML_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles loadXML.Click
        Dim reader As New System.IO.StreamReader(m_xmlFile)
        Dim xmlSerial As _
            New XmlSerializer(System.Type.GetType("Serialize.TriangleCollection"))
        m_triangles = CType(xmlSerial.Deserialize(reader), TriangleCollection)
        reader.Close()
        triangleList.Items.Clear()
        triangleList.Items.AddRange(m_triangles.ToArray())
    End Sub
End Class
