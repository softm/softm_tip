<Serializable()> Public Class XYPoint
    Implements System.Runtime.Serialization.ISerializable

    Private m_x As Integer
    Private m_y As Integer
    Public Property X() As Integer
        Get
            Return m_x
        End Get
        Set(ByVal Value As Integer)
            m_x = Value
        End Set
    End Property
    Public Property Y() As Integer
        Get
            Return m_y
        End Get
        Set(ByVal Value As Integer)
            m_y = Value
        End Set
    End Property

    Public Sub New()
    End Sub
    Public Sub New(ByVal x As Integer, ByVal y As Integer)
        m_x = x
        m_y = y
    End Sub
    Public Overrides Function ToString() As String
        Return String.Format("({0},  {1})", Me.X, Me.Y)
    End Function

    Public Sub GetObjectData(ByVal info As _
    System.Runtime.Serialization.SerializationInfo, _
    ByVal context As System.Runtime.Serialization.StreamingContext) _
    Implements System.Runtime.Serialization.ISerializable.GetObjectData
        info.AddValue("X", m_x)
        info.AddValue("Y", m_y)
    End Sub

    Public Sub New(ByVal info As _
    System.Runtime.Serialization.SerializationInfo, _
    ByVal context As System.Runtime.Serialization.StreamingContext)
        m_x = info.GetInt32("X")
        m_y = info.GetInt32("Y")
    End Sub

End Class