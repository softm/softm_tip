Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents xyPoints As System.Windows.Forms.DataGrid
    Friend WithEvents loadTyped As System.Windows.Forms.Button
    Friend WithEvents display As System.Windows.Forms.Button
    Friend WithEvents loadUntyped As System.Windows.Forms.Button
    Friend WithEvents OleDbDataAdapter1 As System.Data.OleDb.OleDbDataAdapter
    Friend WithEvents OleDbSelectCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbInsertCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbUpdateCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbDeleteCommand1 As System.Data.OleDb.OleDbCommand
    Friend WithEvents OleDbConnection1 As System.Data.OleDb.OleDbConnection
    Friend WithEvents DataSet11 As DataSetExercise.DataSet1
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.xyPoints = New System.Windows.Forms.DataGrid()
        Me.loadUntyped = New System.Windows.Forms.Button()
        Me.loadTyped = New System.Windows.Forms.Button()
        Me.display = New System.Windows.Forms.Button()
        Me.OleDbDataAdapter1 = New System.Data.OleDb.OleDbDataAdapter()
        Me.OleDbSelectCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbInsertCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbUpdateCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbDeleteCommand1 = New System.Data.OleDb.OleDbCommand()
        Me.OleDbConnection1 = New System.Data.OleDb.OleDbConnection()
        Me.DataSet11 = New DataSetExercise.DataSet1()
        CType(Me.xyPoints, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSet11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'xyPoints
        '
        Me.xyPoints.DataMember = ""
        Me.xyPoints.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.xyPoints.Location = New System.Drawing.Point(16, 16)
        Me.xyPoints.Name = "xyPoints"
        Me.xyPoints.Size = New System.Drawing.Size(264, 184)
        Me.xyPoints.TabIndex = 0
        '
        'loadUntyped
        '
        Me.loadUntyped.Location = New System.Drawing.Point(16, 224)
        Me.loadUntyped.Name = "loadUntyped"
        Me.loadUntyped.Size = New System.Drawing.Size(88, 23)
        Me.loadUntyped.TabIndex = 1
        Me.loadUntyped.Text = "Load Untyped"
        '
        'loadTyped
        '
        Me.loadTyped.Location = New System.Drawing.Point(112, 224)
        Me.loadTyped.Name = "loadTyped"
        Me.loadTyped.Size = New System.Drawing.Size(88, 23)
        Me.loadTyped.TabIndex = 2
        Me.loadTyped.Text = "Load Typed"
        '
        'display
        '
        Me.display.Location = New System.Drawing.Point(208, 224)
        Me.display.Name = "display"
        Me.display.TabIndex = 3
        Me.display.Text = "Display"
        '
        'OleDbDataAdapter1
        '
        Me.OleDbDataAdapter1.DeleteCommand = Me.OleDbDeleteCommand1
        Me.OleDbDataAdapter1.InsertCommand = Me.OleDbInsertCommand1
        Me.OleDbDataAdapter1.SelectCommand = Me.OleDbSelectCommand1
        Me.OleDbDataAdapter1.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Points", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("X", "X"), New System.Data.Common.DataColumnMapping("Y", "Y"), New System.Data.Common.DataColumnMapping("Key", "Key")})})
        Me.OleDbDataAdapter1.UpdateCommand = Me.OleDbUpdateCommand1
        '
        'OleDbSelectCommand1
        '
        Me.OleDbSelectCommand1.CommandText = "SELECT [Key], X, Y FROM Points"
        Me.OleDbSelectCommand1.Connection = Me.OleDbConnection1
        '
        'OleDbInsertCommand1
        '
        Me.OleDbInsertCommand1.CommandText = "INSERT INTO Points(X, Y) VALUES (?, ?)"
        Me.OleDbInsertCommand1.Connection = Me.OleDbConnection1
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("X", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(10, Byte), CType(0, Byte), "X", System.Data.DataRowVersion.Current, Nothing))
        Me.OleDbInsertCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Y", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(10, Byte), CType(0, Byte), "Y", System.Data.DataRowVersion.Current, Nothing))
        '
        'OleDbUpdateCommand1
        '
        Me.OleDbUpdateCommand1.CommandText = "UPDATE Points SET X = ?, Y = ? WHERE ([Key] = ?)"
        Me.OleDbUpdateCommand1.Connection = Me.OleDbConnection1
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("X", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(10, Byte), CType(0, Byte), "X", System.Data.DataRowVersion.Current, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Y", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(10, Byte), CType(0, Byte), "Y", System.Data.DataRowVersion.Current, Nothing))
        Me.OleDbUpdateCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Key", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(10, Byte), CType(0, Byte), "Key", System.Data.DataRowVersion.Original, Nothing))
        '
        'OleDbDeleteCommand1
        '
        Me.OleDbDeleteCommand1.CommandText = "DELETE FROM Points WHERE ([Key] = ?)"
        Me.OleDbDeleteCommand1.Connection = Me.OleDbConnection1
        Me.OleDbDeleteCommand1.Parameters.Add(New System.Data.OleDb.OleDbParameter("Original_Key", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, False, CType(10, Byte), CType(0, Byte), "Key", System.Data.DataRowVersion.Original, Nothing))
        '
        'OleDbConnection1
        '
        Me.OleDbConnection1.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Password="""";User ID=Admin;Data Source=C:\OOPVBCS" & _
        "\chapter13\SomeData.mdb;Mode=Share Deny None;Extended Properties="""";Jet OLEDB:Sy" & _
        "stem database="""";Jet OLEDB:Registry Path="""";Jet OLEDB:Database Password="""";Jet O" & _
        "LEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=1;Jet OLEDB:Global Partial Bu" & _
        "lk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password=""""" & _
        ";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLE" & _
        "DB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=F" & _
        "alse;Jet OLEDB:SFP=False"
        '
        'DataSet11
        '
        Me.DataSet11.DataSetName = "DataSet1"
        Me.DataSet11.Locale = New System.Globalization.CultureInfo("en-US")
        Me.DataSet11.Namespace = "http://www.tempuri.org/DataSet1.xsd"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.display, Me.loadTyped, Me.loadUntyped, Me.xyPoints})
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.xyPoints, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSet11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private m_pointsSet As New DataSet()

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim pointsTable As New DataTable("XYPoints")
        m_pointsSet.Tables.Add(pointsTable)
        Dim xColumn As New DataColumn("X", System.Type.GetType("System.Int32"))
        Dim yColumn As New DataColumn("Y", System.Type.GetType("System.Int32"))
        pointsTable.Columns.Add(xColumn)
        pointsTable.Columns.Add(yColumn)
        Dim x As Integer
        Dim y As Integer
        For x = 0 To 5
            For y = 0 To 5
                Dim newRow As DataRow = pointsTable.NewRow()
                newRow("X") = x
                newRow("Y") = y
                pointsTable.Rows.Add(newRow)
            Next
        Next
    End Sub

    Private Sub loadUntyped_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles loadUntyped.Click
        xyPoints.DataSource = m_pointsSet
        xyPoints.DataMember = "XYPoints"
    End Sub

    Private Sub loadTyped_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles loadTyped.Click
        OleDbDataAdapter1.Fill(DataSet11)
        xyPoints.DataSource = DataSet11.Points
    End Sub

    Private Sub display_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles display.Click
        Dim row As Int16 = xyPoints.CurrentCell.RowNumber
        Dim point As String
        Dim x, y As Integer
        If (xyPoints.DataMember = "XYPoints") Then
            x = CType(m_pointsSet.Tables("XYPoints").Rows(row)("X"), _
            Integer)
            y = CType(m_pointsSet.Tables("XYPoints").Rows(row)("Y"), _
            Integer)
        Else
            x = DataSet11.Points(row).X
            y = DataSet11.Points(row).Y
        End If
        point = String.Format("({0},{1})", x, y)
        MessageBox.Show(point)
    End Sub
End Class
