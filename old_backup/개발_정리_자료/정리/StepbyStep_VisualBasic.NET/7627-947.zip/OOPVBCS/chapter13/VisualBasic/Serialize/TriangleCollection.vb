
<Serializable()> Public Class TriangleCollection
    Inherits System.Collections.CollectionBase

    Public Sub Add(ByVal tri As Triangle)
        Me.InnerList.Add(tri)
    End Sub

    Public Sub Remove(ByVal tri As Triangle)
        Me.InnerList.Remove(tri)
    End Sub

    Public Overrides Function ToString() As String
        Dim triangles As String
        Dim tri As Triangle
        For Each tri In Me.InnerList
            triangles += tri.ToString() & ControlChars.CrLf
        Next
        Return triangles
    End Function

    Public Function ToArray() As Object()
        Dim triangles(Me.Count - 1) As Object
        Dim tri As Integer
        For tri = 0 To Me.Count - 1
            triangles(tri) = innerlist(tri)
        Next
        Return triangles
    End Function

    Public Sub New()
    End Sub

    Default Public Property Item(ByVal index As Integer) As Triangle
        Get
            Return CType(Me.InnerList.Item(index), Triangle)
        End Get
        Set(ByVal Value As Triangle)
            Me.InnerList.Item(index) = Value
        End Set
    End Property

End Class