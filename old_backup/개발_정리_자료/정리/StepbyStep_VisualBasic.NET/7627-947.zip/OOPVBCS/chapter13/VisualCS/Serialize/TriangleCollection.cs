using System;

namespace Serialize
{
	/// <summary>
	/// Summary description for TriangleCollecton.
	/// </summary>
	[Serializable()]
	public class TriangleCollection : System.Collections.CollectionBase
	{
		public TriangleCollection()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		public void Add(Triangle tri)
		{
			this.InnerList.Add(tri);
		}
		public void Remove(Triangle tri)
		{
			this.InnerList.Remove(tri);
		}

		public override string ToString()
		{
			string triangles = "";
			foreach(Triangle tri in this.InnerList)
			{
				triangles +=tri.ToString() + "\n";
			}
			return triangles;
		}
		public object [] ToArray()
		{
			object [] triangles = new object[this.Count];
			this.InnerList.CopyTo(triangles, 0);
			return triangles;
		}
	
	
		public Triangle this [int index] 
		{			
			get 
			{
				return (Triangle)(this.List[index]);
			}
			set 
			{
				this.List[index] = value;
			}
		}
	
	}

}
