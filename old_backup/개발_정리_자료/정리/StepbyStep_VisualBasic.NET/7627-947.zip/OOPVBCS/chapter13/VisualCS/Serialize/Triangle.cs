using System;

namespace Serialize
{
	/// <summary>
	/// Summary description for Triangle.
	/// </summary>
	[Serializable()]
	public class Triangle
	{
		public Triangle()
		{
			//
			// TODO: Add constructor logic here
			//
		}

	
		private XYPoint[] m_points = new XYPoint[3];
		public XYPoint[] Points 
		{
			get 
			{
				return m_points;
			}
			set 
			{
				if (value.Length == 3)
				{
					m_points = value;
				}
			}
		}

		public Triangle(XYPoint a,XYPoint b,XYPoint c)
		{
			m_points = new XYPoint[] { a,b,c };
		}

		public override string ToString()
		{
			string triangle = "";
			for (int point = 0; point < m_points.Length; point++)
			{
				triangle += m_points[point].ToString() + " ";
			}
			return triangle;
		}


	
	}

}
