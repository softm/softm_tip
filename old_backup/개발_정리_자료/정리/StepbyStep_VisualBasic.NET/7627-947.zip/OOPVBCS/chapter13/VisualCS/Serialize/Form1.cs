using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Serialize
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.CheckedListBox selectedPoints;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ListBox triangleList;
		private System.Windows.Forms.Button addTriangle;
		private System.Windows.Forms.Button removeTriangle;
		private System.Windows.Forms.Button clearAll;
		private System.Windows.Forms.Button saveBinary;
		private System.Windows.Forms.Button loadBinary;
		private System.Windows.Forms.Button saveXML;
		private System.Windows.Forms.Button loadXML;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private string m_binaryFile =Application.StartupPath + "\\triangles.dat";


		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.selectedPoints = new System.Windows.Forms.CheckedListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.triangleList = new System.Windows.Forms.ListBox();
			this.addTriangle = new System.Windows.Forms.Button();
			this.removeTriangle = new System.Windows.Forms.Button();
			this.clearAll = new System.Windows.Forms.Button();
			this.saveBinary = new System.Windows.Forms.Button();
			this.loadBinary = new System.Windows.Forms.Button();
			this.saveXML = new System.Windows.Forms.Button();
			this.loadXML = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// selectedPoints
			// 
			this.selectedPoints.Location = new System.Drawing.Point(16, 40);
			this.selectedPoints.Name = "selectedPoints";
			this.selectedPoints.Size = new System.Drawing.Size(160, 94);
			this.selectedPoints.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 16);
			this.label1.Name = "label1";
			this.label1.TabIndex = 1;
			this.label1.Text = "Select three points";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(200, 16);
			this.label2.Name = "label2";
			this.label2.TabIndex = 2;
			this.label2.Text = "Triangles";
			// 
			// triangleList
			// 
			this.triangleList.Location = new System.Drawing.Point(200, 40);
			this.triangleList.Name = "triangleList";
			this.triangleList.Size = new System.Drawing.Size(152, 95);
			this.triangleList.TabIndex = 3;
			// 
			// addTriangle
			// 
			this.addTriangle.Location = new System.Drawing.Point(16, 144);
			this.addTriangle.Name = "addTriangle";
			this.addTriangle.TabIndex = 4;
			this.addTriangle.Text = "Add";
			this.addTriangle.Click += new System.EventHandler(this.addTriangle_Click);
			// 
			// removeTriangle
			// 
			this.removeTriangle.Location = new System.Drawing.Point(200, 144);
			this.removeTriangle.Name = "removeTriangle";
			this.removeTriangle.TabIndex = 5;
			this.removeTriangle.Text = "Remove";
			this.removeTriangle.Click += new System.EventHandler(this.removeTriangle_Click);
			// 
			// clearAll
			// 
			this.clearAll.Location = new System.Drawing.Point(280, 144);
			this.clearAll.Name = "clearAll";
			this.clearAll.TabIndex = 6;
			this.clearAll.Text = "Clear All";
			this.clearAll.Click += new System.EventHandler(this.clearAll_Click);
			// 
			// saveBinary
			// 
			this.saveBinary.Location = new System.Drawing.Point(16, 224);
			this.saveBinary.Name = "saveBinary";
			this.saveBinary.TabIndex = 7;
			this.saveBinary.Text = "Save Binary";
			this.saveBinary.Click += new System.EventHandler(this.saveBinary_Click);
			// 
			// loadBinary
			// 
			this.loadBinary.Location = new System.Drawing.Point(96, 224);
			this.loadBinary.Name = "loadBinary";
			this.loadBinary.TabIndex = 8;
			this.loadBinary.Text = "Load Binary";
			this.loadBinary.Click += new System.EventHandler(this.loadBinary_Click);
			// 
			// saveXML
			// 
			this.saveXML.Location = new System.Drawing.Point(200, 224);
			this.saveXML.Name = "saveXML";
			this.saveXML.TabIndex = 9;
			this.saveXML.Text = "Save XML";
			this.saveXML.Click += new System.EventHandler(this.saveXML_Click);
			// 
			// loadXML
			// 
			this.loadXML.Location = new System.Drawing.Point(280, 224);
			this.loadXML.Name = "loadXML";
			this.loadXML.TabIndex = 10;
			this.loadXML.Text = "Load XML";
			this.loadXML.Click += new System.EventHandler(this.loadXML_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(368, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.loadXML,
																		  this.saveXML,
																		  this.loadBinary,
																		  this.saveBinary,
																		  this.clearAll,
																		  this.removeTriangle,
																		  this.addTriangle,
																		  this.triangleList,
																		  this.label2,
																		  this.label1,
																		  this.selectedPoints});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			for (int x = 0; x < 6; x++)
			{
				for (int y = 0; y < 6; y++)
				{
					this.selectedPoints.Items.Add(new XYPoint(x,y));
				}
			}
		}

		private TriangleCollection m_triangles = new TriangleCollection();
		private void addTriangle_Click(object sender, System.EventArgs e)
		{
			CheckedListBox.CheckedItemCollection checkedPoints =
				this.selectedPoints.CheckedItems;
			if (checkedPoints.Count == 3)
			{
				m_triangles.Add(new Triangle((XYPoint)checkedPoints[0],
					(XYPoint)checkedPoints[1], (XYPoint)checkedPoints[2]));
				this.triangleList.Items.Clear();
				this.triangleList.Items.AddRange(m_triangles.ToArray());
				foreach (int item in selectedPoints.CheckedIndices)
				{
					selectedPoints.SetItemChecked(item,false);
				}
			}
			else 
			{
				MessageBox.Show("You must select exactly three points.");
			}
		}

		private void removeTriangle_Click(object sender, System.EventArgs e)
		{
			if (triangleList.SelectedIndex != -1)
			{
				m_triangles.Remove((Triangle)triangleList.SelectedItem);
				triangleList.Items.Clear();
				triangleList.Items.AddRange(m_triangles.ToArray());
			}
		}

		private void clearAll_Click(object sender, System.EventArgs e)
		{
			m_triangles.Clear();
			triangleList.Items.Clear();
		}

		private void saveBinary_Click(object sender, System.EventArgs e)
		{
			System.IO.Stream stream = new System.IO.FileStream(m_binaryFile,
				System.IO.FileMode.Create);
			BinaryFormatter binary = new BinaryFormatter();
			binary.Serialize(stream, m_triangles);
			stream.Close();
		}

		private void loadBinary_Click(object sender, System.EventArgs e)
		{
			System.IO.Stream stream = new System.IO.FileStream(m_binaryFile,
				System.IO.FileMode.Open);
			BinaryFormatter binary = new BinaryFormatter();
			m_triangles =(TriangleCollection)binary.Deserialize(stream);
			stream.Close();
			triangleList.Items.Clear();
			triangleList.Items.AddRange(m_triangles.ToArray());
		}

		private string m_xmlFile = Application.StartupPath + "\\triangles.xml";

		private void saveXML_Click(object sender, System.EventArgs e)
		{
			System.IO.TextWriter writer = new System.IO.StreamWriter(m_xmlFile);
			XmlSerializer xmlSerial =
				new XmlSerializer(typeof(TriangleCollection));
			xmlSerial.Serialize(writer, m_triangles);
			writer.Close();
		}

		private void loadXML_Click(object sender, System.EventArgs e)
		{
			System.IO.TextReader reader =new System.IO.StreamReader(m_xmlFile);
			XmlSerializer xmlSerial =
				new XmlSerializer(typeof(TriangleCollection));
			m_triangles =(TriangleCollection)xmlSerial.Deserialize(reader);
			reader.Close();
			triangleList.Items.Clear();
			triangleList.Items.AddRange(m_triangles.ToArray());
		}

	}
}
