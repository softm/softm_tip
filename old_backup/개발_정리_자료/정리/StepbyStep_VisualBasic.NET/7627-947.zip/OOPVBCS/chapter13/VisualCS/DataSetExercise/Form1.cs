using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DataSetExercise
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.loadUntyped = new System.Windows.Forms.Button();
			this.loadTyped = new System.Windows.Forms.Button();
			this.display = new System.Windows.Forms.Button();
			this.xyPoints = new System.Windows.Forms.DataGrid();
			this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
			this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
			this.oleDbInsertCommand1 = new System.Data.OleDb.OleDbCommand();
			this.oleDbUpdateCommand1 = new System.Data.OleDb.OleDbCommand();
			this.oleDbDeleteCommand1 = new System.Data.OleDb.OleDbCommand();
			this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
			this.dataSet11 = new DataSetExercise.DataSet1();
			((System.ComponentModel.ISupportInitialize)(this.xyPoints)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataSet11)).BeginInit();
			this.SuspendLayout();
			// 
			// loadUntyped
			// 
			this.loadUntyped.Location = new System.Drawing.Point(16, 232);
			this.loadUntyped.Name = "loadUntyped";
			this.loadUntyped.Size = new System.Drawing.Size(88, 23);
			this.loadUntyped.TabIndex = 0;
			this.loadUntyped.Text = "Load Untyped";
			this.loadUntyped.Click += new System.EventHandler(this.loadUntyped_Click);
			// 
			// loadTyped
			// 
			this.loadTyped.Location = new System.Drawing.Point(112, 232);
			this.loadTyped.Name = "loadTyped";
			this.loadTyped.Size = new System.Drawing.Size(88, 23);
			this.loadTyped.TabIndex = 1;
			this.loadTyped.Text = "Load Typed";
			this.loadTyped.Click += new System.EventHandler(this.loadTyped_Click);
			// 
			// display
			// 
			this.display.Location = new System.Drawing.Point(208, 232);
			this.display.Name = "display";
			this.display.TabIndex = 2;
			this.display.Text = "Display";
			this.display.Click += new System.EventHandler(this.display_Click);
			// 
			// xyPoints
			// 
			this.xyPoints.DataMember = "";
			this.xyPoints.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.xyPoints.Location = new System.Drawing.Point(16, 16);
			this.xyPoints.Name = "xyPoints";
			this.xyPoints.Size = new System.Drawing.Size(264, 192);
			this.xyPoints.TabIndex = 3;
			// 
			// oleDbDataAdapter1
			// 
			this.oleDbDataAdapter1.DeleteCommand = this.oleDbDeleteCommand1;
			this.oleDbDataAdapter1.InsertCommand = this.oleDbInsertCommand1;
			this.oleDbDataAdapter1.SelectCommand = this.oleDbSelectCommand1;
			this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																										new System.Data.Common.DataTableMapping("Table", "Points", new System.Data.Common.DataColumnMapping[] {
																																																				  new System.Data.Common.DataColumnMapping("X", "X"),
																																																				  new System.Data.Common.DataColumnMapping("Y", "Y"),
																																																				  new System.Data.Common.DataColumnMapping("Key", "Key")})});
			this.oleDbDataAdapter1.UpdateCommand = this.oleDbUpdateCommand1;
			// 
			// oleDbSelectCommand1
			// 
			this.oleDbSelectCommand1.CommandText = "SELECT [Key], X, Y FROM Points";
			this.oleDbSelectCommand1.Connection = this.oleDbConnection1;
			// 
			// oleDbInsertCommand1
			// 
			this.oleDbInsertCommand1.CommandText = "INSERT INTO Points(X, Y) VALUES (?, ?)";
			this.oleDbInsertCommand1.Connection = this.oleDbConnection1;
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("X", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((System.Byte)(10)), ((System.Byte)(0)), "X", System.Data.DataRowVersion.Current, null));
			this.oleDbInsertCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Y", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((System.Byte)(10)), ((System.Byte)(0)), "Y", System.Data.DataRowVersion.Current, null));
			// 
			// oleDbUpdateCommand1
			// 
			this.oleDbUpdateCommand1.CommandText = "UPDATE Points SET X = ?, Y = ? WHERE ([Key] = ?)";
			this.oleDbUpdateCommand1.Connection = this.oleDbConnection1;
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("X", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((System.Byte)(10)), ((System.Byte)(0)), "X", System.Data.DataRowVersion.Current, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Y", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((System.Byte)(10)), ((System.Byte)(0)), "Y", System.Data.DataRowVersion.Current, null));
			this.oleDbUpdateCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Key", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((System.Byte)(10)), ((System.Byte)(0)), "Key", System.Data.DataRowVersion.Original, null));
			// 
			// oleDbDeleteCommand1
			// 
			this.oleDbDeleteCommand1.CommandText = "DELETE FROM Points WHERE ([Key] = ?)";
			this.oleDbDeleteCommand1.Connection = this.oleDbConnection1;
			this.oleDbDeleteCommand1.Parameters.Add(new System.Data.OleDb.OleDbParameter("Original_Key", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((System.Byte)(10)), ((System.Byte)(0)), "Key", System.Data.DataRowVersion.Original, null));
			// 
			// oleDbConnection1
			// 
			this.oleDbConnection1.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Password="""";User ID=Admin;Data Source=C:\OOPVBCS\chapter13\SomeData.mdb;Mode=Share Deny None;Extended Properties="""";Jet OLEDB:System database="""";Jet OLEDB:Registry Path="""";Jet OLEDB:Database Password="""";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mode=1;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk Transactions=1;Jet OLEDB:New Database Password="""";Jet OLEDB:Create System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLEDB:Don't Copy Locale on Compact=False;Jet OLEDB:Compact Without Replica Repair=False;Jet OLEDB:SFP=False";
			// 
			// dataSet11
			// 
			this.dataSet11.DataSetName = "DataSet1";
			this.dataSet11.Locale = new System.Globalization.CultureInfo("en-US");
			this.dataSet11.Namespace = "http://www.tempuri.org/DataSet1.xsd";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.xyPoints,
																		  this.display,
																		  this.loadTyped,
																		  this.loadUntyped});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.xyPoints)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataSet11)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private System.Windows.Forms.Button loadUntyped;
		private System.Windows.Forms.Button loadTyped;
		private System.Windows.Forms.Button display;
		private System.Windows.Forms.DataGrid xyPoints;
		private System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
		private System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
		private System.Data.OleDb.OleDbCommand oleDbInsertCommand1;
		private System.Data.OleDb.OleDbCommand oleDbUpdateCommand1;
		private System.Data.OleDb.OleDbCommand oleDbDeleteCommand1;
		private System.Data.OleDb.OleDbConnection oleDbConnection1;
		private DataSetExercise.DataSet1 dataSet11;

		private DataSet m_pointsSet =new DataSet();

		private void Form1_Load(object sender, System.EventArgs e)
		{
			DataTable pointsTable = new DataTable("XYPoints");
			m_pointsSet.Tables.Add(pointsTable);
			DataColumn xColumn = new DataColumn("X",typeof(int));
			DataColumn yColumn = new DataColumn("Y",typeof(int));
			pointsTable.Columns.Add(xColumn);
			pointsTable.Columns.Add(yColumn);
			for(int x = 0; x < 6; x++)
			{
				for (int y = 0; y < 6; y++)
				{
					DataRow newRow = pointsTable.NewRow();
					newRow["X"] = x;
					newRow["Y"] = y;
					pointsTable.Rows.Add(newRow);
				}
			}
		}

		private void loadUntyped_Click(object sender, System.EventArgs e)
		{
			this.xyPoints.DataSource = m_pointsSet;
			this.xyPoints.DataMember = "XYPoints";
		}

		private void loadTyped_Click(object sender, System.EventArgs e)
		{
			oleDbDataAdapter1.Fill(dataSet11);
			xyPoints.DataSource = dataSet11.Points;
		}

		private void display_Click(object sender, System.EventArgs e)
		{
			int row = this.xyPoints.CurrentCell.RowNumber;
			string point;
			int x, y;
			if (xyPoints.DataMember == "XYPoints")
			{
				x = (int)m_pointsSet.Tables["XYPoints"].Rows[row]["X"];
				y = (int)m_pointsSet.Tables["XYPoints"].Rows[row]["Y"];
			}
			else 
			{
				x = dataSet11.Points[row].X;
				y = dataSet11.Points[row].Y;
			}
			point =string.Format("({0}, {1})", x,y);
			MessageBox.Show(point);
		}
	}
}
