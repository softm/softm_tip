using System;

namespace Serialize
{
	/// <summary>
	/// Summary description for XYPoint.
	/// </summary>
	[Serializable()]
	public class XYPoint : System.Runtime.Serialization.ISerializable
	{
		private int m_x, m_y;
		public int Y 
		{
			get {return m_y;}
			set {m_y = value;}
		}
		public int X 
		{
			get {return m_x;}
			set {m_x = value;}
		}

		public XYPoint()
		{
		}
		public XYPoint(int x,int y)
		{
			m_x = x;
			m_y = y;
		}
		public override string ToString()
		{
			return string.Format("({0}, {1})", this.X, this.Y);
				
		}
	
		public void GetObjectData(System.Runtime.Serialization.SerializationInfo
			info,System.Runtime.Serialization.StreamingContext context)
		{
			info.AddValue("X", m_x);
			info.AddValue("Y", m_y);
		}

		public XYPoint(System.Runtime.Serialization.SerializationInfo info,
			System.Runtime.Serialization.StreamingContext context)
		{
			m_x =info.GetInt32("X");
			m_y =info.GetInt32("Y");
		}

	}
}
