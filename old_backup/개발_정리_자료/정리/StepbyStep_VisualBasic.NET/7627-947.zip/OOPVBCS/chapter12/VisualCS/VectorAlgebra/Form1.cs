using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace VectorAlgebra
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.NumericUpDown XVectorA;
		private System.Windows.Forms.NumericUpDown YVectorA;
		private System.Windows.Forms.ListBox functions;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.NumericUpDown YVectorB;
		private System.Windows.Forms.NumericUpDown XVectorB;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.NumericUpDown scalar;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox result;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.XVectorA = new System.Windows.Forms.NumericUpDown();
			this.YVectorA = new System.Windows.Forms.NumericUpDown();
			this.functions = new System.Windows.Forms.ListBox();
			this.label4 = new System.Windows.Forms.Label();
			this.YVectorB = new System.Windows.Forms.NumericUpDown();
			this.XVectorB = new System.Windows.Forms.NumericUpDown();
			this.label5 = new System.Windows.Forms.Label();
			this.scalar = new System.Windows.Forms.NumericUpDown();
			this.label6 = new System.Windows.Forms.Label();
			this.result = new System.Windows.Forms.TextBox();
			((System.ComponentModel.ISupportInitialize)(this.XVectorA)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.YVectorA)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.YVectorB)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.XVectorB)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.scalar)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(472, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "X";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(552, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 23);
			this.label2.TabIndex = 1;
			this.label2.Text = "Y";
			// 
			// label3
			// 
			this.label3.ForeColor = System.Drawing.Color.Red;
			this.label3.Location = new System.Drawing.Point(400, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 23);
			this.label3.TabIndex = 2;
			this.label3.Text = "Vector A";
			// 
			// XVectorA
			// 
			this.XVectorA.Location = new System.Drawing.Point(464, 40);
			this.XVectorA.Maximum = new System.Decimal(new int[] {
																	 5,
																	 0,
																	 0,
																	 0});
			this.XVectorA.Minimum = new System.Decimal(new int[] {
																	 5,
																	 0,
																	 0,
																	 -2147483648});
			this.XVectorA.Name = "XVectorA";
			this.XVectorA.Size = new System.Drawing.Size(40, 20);
			this.XVectorA.TabIndex = 3;
			this.XVectorA.ValueChanged += new System.EventHandler(this.VectorChanged);
			// 
			// YVectorA
			// 
			this.YVectorA.Location = new System.Drawing.Point(536, 40);
			this.YVectorA.Maximum = new System.Decimal(new int[] {
																	 5,
																	 0,
																	 0,
																	 0});
			this.YVectorA.Minimum = new System.Decimal(new int[] {
																	 5,
																	 0,
																	 0,
																	 -2147483648});
			this.YVectorA.Name = "YVectorA";
			this.YVectorA.Size = new System.Drawing.Size(40, 20);
			this.YVectorA.TabIndex = 4;
			this.YVectorA.ValueChanged += new System.EventHandler(this.VectorChanged);
			// 
			// functions
			// 
			this.functions.Location = new System.Drawing.Point(464, 72);
			this.functions.Name = "functions";
			this.functions.Size = new System.Drawing.Size(120, 17);
			this.functions.TabIndex = 5;
			this.functions.SelectedIndexChanged += new System.EventHandler(this.VectorChanged);
			// 
			// label4
			// 
			this.label4.ForeColor = System.Drawing.Color.Blue;
			this.label4.Location = new System.Drawing.Point(400, 104);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(56, 23);
			this.label4.TabIndex = 6;
			this.label4.Text = "VectorB";
			// 
			// YVectorB
			// 
			this.YVectorB.Location = new System.Drawing.Point(536, 104);
			this.YVectorB.Maximum = new System.Decimal(new int[] {
																	 5,
																	 0,
																	 0,
																	 0});
			this.YVectorB.Minimum = new System.Decimal(new int[] {
																	 5,
																	 0,
																	 0,
																	 -2147483648});
			this.YVectorB.Name = "YVectorB";
			this.YVectorB.Size = new System.Drawing.Size(40, 20);
			this.YVectorB.TabIndex = 8;
			this.YVectorB.ValueChanged += new System.EventHandler(this.VectorChanged);
			// 
			// XVectorB
			// 
			this.XVectorB.Location = new System.Drawing.Point(464, 104);
			this.XVectorB.Maximum = new System.Decimal(new int[] {
																	 5,
																	 0,
																	 0,
																	 0});
			this.XVectorB.Minimum = new System.Decimal(new int[] {
																	 5,
																	 0,
																	 0,
																	 -2147483648});
			this.XVectorB.Name = "XVectorB";
			this.XVectorB.Size = new System.Drawing.Size(40, 20);
			this.XVectorB.TabIndex = 7;
			this.XVectorB.ValueChanged += new System.EventHandler(this.VectorChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(592, 104);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(16, 23);
			this.label5.TabIndex = 9;
			this.label5.Text = "*";
			// 
			// scalar
			// 
			this.scalar.Location = new System.Drawing.Point(616, 104);
			this.scalar.Maximum = new System.Decimal(new int[] {
																   3,
																   0,
																   0,
																   0});
			this.scalar.Minimum = new System.Decimal(new int[] {
																   3,
																   0,
																   0,
																   -2147483648});
			this.scalar.Name = "scalar";
			this.scalar.Size = new System.Drawing.Size(40, 20);
			this.scalar.TabIndex = 10;
			this.scalar.Value = new System.Decimal(new int[] {
																 1,
																 0,
																 0,
																 0});
			this.scalar.ValueChanged += new System.EventHandler(this.VectorChanged);
			// 
			// label6
			// 
			this.label6.ForeColor = System.Drawing.Color.Green;
			this.label6.Location = new System.Drawing.Point(400, 144);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(56, 23);
			this.label6.TabIndex = 11;
			this.label6.Text = "Result";
			// 
			// result
			// 
			this.result.ForeColor = System.Drawing.Color.Green;
			this.result.Location = new System.Drawing.Point(464, 144);
			this.result.Name = "result";
			this.result.TabIndex = 12;
			this.result.Text = "";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(664, 350);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.result,
																		  this.label6,
																		  this.scalar,
																		  this.label5,
																		  this.YVectorB,
																		  this.XVectorB,
																		  this.label4,
																		  this.functions,
																		  this.YVectorA,
																		  this.XVectorA,
																		  this.label3,
																		  this.label2,
																		  this.label1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			((System.ComponentModel.ISupportInitialize)(this.XVectorA)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.YVectorA)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.YVectorB)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.XVectorB)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.scalar)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			e.Graphics.DrawLine(Pens.Black, 20, 170, 320, 170);
			e.Graphics.DrawLine(Pens.Black, 170, 20, 170, 320);
		}

		private Point VectorToPoint(Vector vector)
		{
			return new Point(vector.X*15 +170,-vector.Y*15 +170);
		}

		private void DrawVector(Vector vector,Color color)
		{
			Point origin =VectorToPoint(new Vector(0,0));
			Point end =VectorToPoint(vector);
			this.CreateGraphics().DrawLine(
				new Pen(new SolidBrush(color),2),origin,end);
		}
		private void DrawVector(Vector aVector,Vector bVector,Color color)
		{
			Point origin =VectorToPoint(bVector);
			Point end =VectorToPoint(aVector +bVector);
			this.CreateGraphics().DrawLine(
				new Pen(new SolidBrush(color),2),origin,end);
		}

		private delegate void VectorMath(Vector a,Vector b);
		System.Collections.SortedList m_maths =
			new System.Collections.SortedList();

		private Vector VectorA 
		{
			get 
			{
				return new Vector((int)this.XVectorA.Value,
					(int)this.YVectorA.Value);
			}
		}
		private Vector VectorB 
		{
			get 
			{
				return new Vector((int)this.XVectorB.Value,
					(int)this.YVectorB.Value);
			}
		}

		private void AddVectors(Vector a,Vector b)
		{
			DrawVector(a,Color.Red);
			DrawVector(b,a,Color.Blue);
			Vector sum =a +b;
			DrawVector(sum,Color.Green);
			this.result.Text =sum.ToString();
		}
		private void SubtractVectors(Vector a,Vector b)
		{
			DrawVector(a,Color.Red);
			DrawVector(-b,a,Color.Blue);
			Vector difference =a -b;
			DrawVector(difference,Color.Green);
			this.result.Text =difference.ToString();
		}
		private void AreEqual(Vector a,Vector b)
		{
			bool equal =(a ==b);
			this.result.Text =equal.ToString();
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			m_maths.Add("Add", new VectorMath(AddVectors));
			m_maths.Add("Subtract", new VectorMath(SubtractVectors));
			m_maths.Add("Are equal", new VectorMath(AreEqual));
			functions.DataSource = m_maths.Keys;

		}

		private void VectorChanged(object sender,System.EventArgs e)
		{
			this.Refresh();
			VectorMath theMath = (VectorMath)m_maths[functions.Text];
			theMath(this.VectorA, (int)scalar.Value * this.VectorB);
		}


	}
}
