using System;

namespace VectorAlgebra
{
	/// <summary>
	/// Summary description for Vector.
	/// </summary>
	public class Vector
	{
		public Vector(int x, int y)
		{
			m_x = x;
			m_y = y;
		}

		private int m_x;
		public int X 
		{
			get {return m_x;}
			set {m_x = value;}
		}
		private int m_y;
		public int Y 
		{
			get {return m_y;}
			set {m_y = value;}
		}

		public static bool operator ==(Vector aVector, Vector bVector)
		{
			return (aVector.X == bVector.X)&&(aVector.Y == bVector.Y);
		}

		public static bool operator !=(Vector aVector, Vector bVector)
		{
			return !(aVector == bVector);
		}

		public override bool Equals(object o)
		{
			return (o is Vector) && (this == (Vector)o);
		}

		public override int GetHashCode()
		{
			return this.X;
		}

		public static Vector operator -(Vector vector)
		{
			return new Vector(-vector.X, -vector.Y);
		}
	
		public static Vector operator +(Vector aVector,Vector bVector)
		{
			return new Vector(aVector.X + bVector.X, aVector.Y + bVector.Y);
		}

		public static Vector operator -(Vector aVector,Vector bVector)
		{
			return aVector + (-bVector);
		}

		public static Vector operator *(int scalar,Vector vector)
		{
			return new Vector(scalar *vector.X, scalar * vector.Y);
		}

		public static Vector Parse(string vectorString)
		{
			try 
			{
				string[] values = vectorString.Split("(, )".ToCharArray());
				int x = int.Parse(values[1]);
				int y = int.Parse(values[3]);
				return new Vector(x,y);
			}
			catch 
			{
				throw new ArgumentException("Unable to parse �" + vectorString
					+"' into a Vector instance.");
			}
		}
		
		public override string ToString()
		{
			return string.Format("({0}, {1})", m_x, m_y);
										   
		}




	}
}
