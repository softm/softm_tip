using System;

namespace SortablePoint
{
	/// <summary>
	/// Summary description for SortablePoint.
	/// </summary>
	public class SortablePoint : IComparable
	{
		public SortablePoint(int x, int y)
		{
			m_x = x;
			m_y = y;
		}
		
		private int m_x = 0;
		public int X 
		{
			get {return m_x;}
		}
		private int m_y = 0;
		public int Y 
		{
			get {return m_y;}
		}

		public override string ToString()
		{
			return string.Format("({0}, {1})", X, Y);
										   
		}

		private static SortablePoint m_center = new SortablePoint(0, 0);

		public static SortablePoint Center 
		{
			get {return m_center;}
			set {m_center =value;}
		}

		public int CompareTo(object obj)
		{
			return this.SquaredDistance() -
				((SortablePoint)obj).SquaredDistance();
		}

		private int SquaredDistance()
		{
			int xDistance = m_center.X - m_x;
			int yDistance = m_center.Y - m_y;
			return (xDistance * xDistance) + (yDistance * yDistance);
		}

		public static SortablePoint Parse(string pointString)
		{
			try 
			{
				string[] values =pointString.Split("( ,)".ToCharArray());
				int x = int.Parse(values[1]);
				int y = int.Parse(values[3]);
				return new SortablePoint(x, y);
			}
			catch 
			{
				throw new ArgumentException("Unable to parse " + pointString
					+ " into a SortablePoint instance.");
			}
		}

	}
}
