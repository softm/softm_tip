namespace Singleton 
{
	class Singleton 
	{
		static Singleton m_instance;
		public static Singleton GetInstance()
		{
			if (m_instance == null)
			{
				m_instance = new Singleton();
			}
			return m_instance;
		}
		private Singleton(){}

		System.Collections.ArrayList m_list =
			new System.Collections.ArrayList();
		public void AddString(string newString)
		{
			m_list.Add(newString);
		}
		public string[] GetStrings()
		{
			return (string[])m_list.ToArray(typeof(string));
		}
	}
}