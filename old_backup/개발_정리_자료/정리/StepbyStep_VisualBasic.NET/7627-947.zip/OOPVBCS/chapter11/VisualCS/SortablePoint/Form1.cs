using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace SortablePoint
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button addPoints;
		private System.Windows.Forms.TextBox newCenter;
		private System.Windows.Forms.Button setNewCenter;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.addPoints = new System.Windows.Forms.Button();
			this.newCenter = new System.Windows.Forms.TextBox();
			this.setNewCenter = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// addPoints
			// 
			this.addPoints.Location = new System.Drawing.Point(136, 248);
			this.addPoints.Name = "addPoints";
			this.addPoints.Size = new System.Drawing.Size(96, 23);
			this.addPoints.TabIndex = 0;
			this.addPoints.Text = "Add Points";
			this.addPoints.Click += new System.EventHandler(this.addPoints_Click);
			// 
			// newCenter
			// 
			this.newCenter.Location = new System.Drawing.Point(16, 280);
			this.newCenter.Name = "newCenter";
			this.newCenter.TabIndex = 1;
			this.newCenter.Text = "";
			// 
			// setNewCenter
			// 
			this.setNewCenter.Location = new System.Drawing.Point(136, 280);
			this.setNewCenter.Name = "setNewCenter";
			this.setNewCenter.Size = new System.Drawing.Size(96, 23);
			this.setNewCenter.TabIndex = 2;
			this.setNewCenter.Text = "Set New Center";
			this.setNewCenter.Click += new System.EventHandler(this.setNewCenter_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 310);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.setNewCenter,
																		  this.newCenter,
																		  this.addPoints});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void setNewCenter_Click(object sender, System.EventArgs e)
		{
			try 
			{
				SortablePoint center =SortablePoint.Parse(newCenter.Text);
				SortablePoint.Center =center;
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message + "\n" + 
					"Setting center to the origin.");
				SortablePoint.Center = new SortablePoint(0, 0);
				newCenter.Text = SortablePoint.Center.ToString();
			}
			this.Refresh();
		}

		private void addPoints_Click(object sender, System.EventArgs e)
		{
			ArrayList points = new ArrayList();
			System.Random rgen = new System.Random();
			SortablePoint pt;
			Graphics graph = this.CreateGraphics();
			for (int count = 0; count < 250; count++)
			{
				points.Add(new SortablePoint(rgen.Next(200), rgen.Next(200)));
			}
			points.Sort();
			for (int count = 0; count < 250; count++)
			{
				pt =(SortablePoint)(points[count]);
				Color color = System.Drawing.Color.FromArgb(25, 25, count);
				System.Drawing.SolidBrush brush =
					new System.Drawing.SolidBrush(color);
				graph.FillEllipse(brush, pt.X, pt.Y, 10, 10);
				brush.Dispose();
			}
		}
	}
}
