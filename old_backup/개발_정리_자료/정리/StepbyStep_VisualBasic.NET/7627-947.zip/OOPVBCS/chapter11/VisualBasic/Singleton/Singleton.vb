Class Singleton
    Shared m_instance As Singleton
    Public Shared Function GetInstance() As Singleton
        If (m_instance Is Nothing) Then
            m_instance = New Singleton()
        End If
        Return m_instance
    End Function
    Private Sub New()
    End Sub

    Dim m_list As System.Collections.ArrayList = _
        New System.Collections.ArrayList()
    Public Sub AddString(ByVal newString As String)
        m_list.Add(newString)
    End Sub
    Public Function GetStrings() As String()
        Return CType(m_list.ToArray(System.Type.GetType("System.String")), _
            String())
    End Function

End Class