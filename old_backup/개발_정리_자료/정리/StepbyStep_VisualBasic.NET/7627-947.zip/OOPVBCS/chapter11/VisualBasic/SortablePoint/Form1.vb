Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents addPoints As System.Windows.Forms.Button
    Friend WithEvents newCenter As System.Windows.Forms.TextBox
    Friend WithEvents setNewCenter As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.addPoints = New System.Windows.Forms.Button()
        Me.newCenter = New System.Windows.Forms.TextBox()
        Me.setNewCenter = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'addPoints
        '
        Me.addPoints.Location = New System.Drawing.Point(136, 248)
        Me.addPoints.Name = "addPoints"
        Me.addPoints.Size = New System.Drawing.Size(96, 23)
        Me.addPoints.TabIndex = 0
        Me.addPoints.Text = "Add Points"
        '
        'newCenter
        '
        Me.newCenter.Location = New System.Drawing.Point(16, 280)
        Me.newCenter.Name = "newCenter"
        Me.newCenter.TabIndex = 1
        Me.newCenter.Text = ""
        '
        'setNewCenter
        '
        Me.setNewCenter.Location = New System.Drawing.Point(136, 280)
        Me.setNewCenter.Name = "setNewCenter"
        Me.setNewCenter.Size = New System.Drawing.Size(96, 23)
        Me.setNewCenter.TabIndex = 2
        Me.setNewCenter.Text = "Set New Center"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 310)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.setNewCenter, Me.newCenter, Me.addPoints})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub setNewCenter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles setNewCenter.Click
        Try
            Dim center As SortablePoint = SortablePoint.Parse(newCenter.Text)
            SortablePoint.Center = center
        Catch ex As Exception
            MessageBox.Show(ex.Message & ControlChars.CrLf & _
                "Setting center to the origin.")
            SortablePoint.Center = New SortablePoint(0, 0)
            newCenter.Text = SortablePoint.Center.ToString()
        End Try
        Me.Refresh()
    End Sub

    Private Sub addPoints_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addPoints.Click
        Dim points As New ArrayList()
        Dim rgen As New System.Random()
        Dim pt As SortablePoint
        Dim count As Integer
        Dim graph As Graphics = Me.CreateGraphics()
        Dim aColor As Color
        For count = 0 To 249
            points.Add(New SortablePoint(rgen.Next(200), rgen.Next(200)))
        Next
        points.Sort()
        For count = 0 To 249
            pt = CType(points(count), SortablePoint)
            aColor = System.Drawing.Color.FromArgb(25, 25, count)
            Dim brush As New System.Drawing.SolidBrush(aColor)
            graph.FillEllipse(brush, pt.X, pt.Y, 10, 10)
            brush.Dispose()
        Next
    End Sub
End Class
