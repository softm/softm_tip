Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents listOne As System.Windows.Forms.ListBox
    Friend WithEvents listTwo As System.Windows.Forms.ListBox
    Friend WithEvents newString As System.Windows.Forms.TextBox
    Friend WithEvents addString As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.listOne = New System.Windows.Forms.ListBox()
        Me.listTwo = New System.Windows.Forms.ListBox()
        Me.newString = New System.Windows.Forms.TextBox()
        Me.addString = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'listOne
        '
        Me.listOne.Location = New System.Drawing.Point(16, 24)
        Me.listOne.Name = "listOne"
        Me.listOne.Size = New System.Drawing.Size(120, 95)
        Me.listOne.TabIndex = 0
        '
        'listTwo
        '
        Me.listTwo.Location = New System.Drawing.Point(152, 24)
        Me.listTwo.Name = "listTwo"
        Me.listTwo.Size = New System.Drawing.Size(120, 95)
        Me.listTwo.TabIndex = 1
        '
        'newString
        '
        Me.newString.Location = New System.Drawing.Point(16, 168)
        Me.newString.Name = "newString"
        Me.newString.TabIndex = 2
        Me.newString.Text = ""
        '
        'addString
        '
        Me.addString.Location = New System.Drawing.Point(16, 224)
        Me.addString.Name = "addString"
        Me.addString.TabIndex = 3
        Me.addString.Text = "Add String"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.addString, Me.newString, Me.listTwo, Me.listOne})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim singletonOne As Singleton
    Dim singletonTwo As Singleton
    Private Sub Form1_Load(ByVal sender As System.Object, _
ByVal e As System.EventArgs) Handles MyBase.Load
        ' The following line won �t compile because there �s no
        ' public constructor.
        ' singletonOne =New Singleton()
        singletonOne = Singleton.GetInstance()
        singletonTwo = Singleton.GetInstance()
    End Sub

    Private Sub addString_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addString.Click
        singletonOne.AddString(newString.Text)
        listOne.DataSource = Nothing
        listOne.Items.Clear()
        listOne.DataSource = singletonOne.GetStrings()
        listTwo.DataSource = Nothing
        listTwo.Items.Clear()
        listTwo.DataSource = singletonTwo.GetStrings()
    End Sub
End Class
