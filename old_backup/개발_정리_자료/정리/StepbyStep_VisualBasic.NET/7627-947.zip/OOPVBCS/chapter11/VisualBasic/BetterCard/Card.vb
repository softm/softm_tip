Imports System.ComponentModel

Public Enum Suit
    Hearts
    Diamonds
    Clubs
    Spades
End Enum
Public Enum FaceValue
    Ace
    Two
    Three
    Four
    Five
    Six
    Seven
    Eight
    Nine
    Ten
    Jack
    Queen
    King
End Enum

Public Class Card
    Inherits System.Windows.Forms.UserControl

    Shared m_images As SortedList = New SortedList()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Card
        '
        Me.Name = "Card"
        Me.Size = New System.Drawing.Size(60, 75)

    End Sub

#End Region

    Public Sub New(ByVal newSuit As Suit, ByVal newValue As FaceValue)
        Me.New()
        m_suit = newSuit
        m_faceValue = newValue
    End Sub


    Shared Sub New()
        Dim theAssembly As System.Reflection.Assembly
        theAssembly = System.Reflection.Assembly.GetExecutingAssembly()
        Dim assemblyName As String = theAssembly.GetName().Name
        Dim iconStream As System.IO.Stream
        Dim resourceName As String
        Dim theIcon As Icon
        Dim theSuit As Object
        Dim aSuit As Integer
        Dim suitNames() As String = System.Enum.GetNames(System.Type.GetType("BetterCard.Suit"))
        For aSuit = 0 To suitNames.Length - 1
            resourceName = assemblyName & "." & suitNames(aSuit) & ".ico"
            iconStream = theAssembly.GetManifestResourceStream(resourceName)
            theIcon = New Icon(iconStream)
            theSuit = System.Enum.Parse( _
            System.Type.GetType("BetterCard.Suit"), suitNames(aSuit))
            m_images.Add(theSuit, theIcon)
        Next
    End Sub



    Private m_faceValue As FaceValue = FaceValue.Ace

    <Category("Game"), Description("Face value of the card.")> _
    Public Property FaceValue() As FaceValue
        Get
            Return m_faceValue
        End Get
        Set(ByVal Value As FaceValue)
            m_faceValue = Value
            Me.Refresh()
        End Set
    End Property

    Private m_suit As Suit = Suit.Hearts

    <Category("Game"), Description("Suit (Hearts, Spades, Diamonds, Clubs)")> _
    Public Property Suit() As Suit
        Get
            Return m_suit
        End Get
        Set(ByVal Value As Suit)
            m_suit = Value
            Me.Refresh()
        End Set
    End Property

    Private m_faceUp As Boolean = True
    <Category("Game"), Description("Is the card face up?")> _
    Public Property FaceUp() As Boolean
        Get
            Return m_faceUp
        End Get
        Set(ByVal Value As Boolean)
            m_faceUp = Value
            Me.Refresh()
        End Set
    End Property

    Private Sub Card_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles MyBase.Paint
        Dim g As Graphics = Me.CreateGraphics()
        g.DrawRectangle(System.Drawing.Pens.Black, 0, 0, _
            Me.ClientRectangle.Width - 1, Me.ClientRectangle.Height - 1)
        If Me.FaceUp Then
            Me.BackColor = Color.White
            g.DrawString(Me.m_faceValue.ToString(), New _
            System.Drawing.Font("Arial", 10, _
            System.Drawing.FontStyle.Bold), _
            System.Drawing.Brushes.Black, 3, 3)
            g.DrawIcon(CType(m_images(m_suit), Icon), 14, 40)
        Else
            Me.BackColor = Color.Blue
        End If
    End Sub

    Public Const FixedWidth As Integer = 60
    Public Const FixedHeight As Integer = 75
    Private Sub Card_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.SizeChanged
        Me.Size = New Size(FixedWidth, FixedHeight)
    End Sub
End Class
