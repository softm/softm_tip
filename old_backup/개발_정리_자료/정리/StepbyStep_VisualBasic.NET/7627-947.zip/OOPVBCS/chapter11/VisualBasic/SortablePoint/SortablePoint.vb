Public Class SortablePoint
    Implements IComparable

    Private m_x As Integer = 0
    Public ReadOnly Property X() As Integer
        Get
            Return m_x
        End Get
    End Property
    Private m_y As Integer = 0
    Public ReadOnly Property Y() As Integer
        Get
            Return m_y
        End Get
    End Property

    Public Sub New(ByVal x As Integer, ByVal y As Integer)
        m_x = x
        m_y = y
    End Sub

    Public Overrides Function ToString() As String
        Return String.Format("({0}, {1})", m_x, m_y)
    End Function

    Private Shared m_center As New SortablePoint(0, 0)

    Public Shared Property Center() As SortablePoint
        Get
            Return m_center
        End Get
        Set(ByVal Value As SortablePoint)
            m_center = Value
        End Set
    End Property


    Public Function CompareTo(ByVal obj As Object) As Integer _
    Implements System.IComparable.CompareTo
        Return Me.SquaredDistance() - CType(obj, _
            SortablePoint).SquaredDistance()
    End Function


    Private Function SquaredDistance() As Integer
        Dim xDistance As Integer = m_center.X - m_x
        Dim yDistance As Integer = m_center.Y - m_y
        Return (xDistance * xDistance) + (yDistance * yDistance)
    End Function

    Public Shared Function Parse(ByVal pointString As String) As SortablePoint
        Try
            Dim values() As String = pointString.Split("( ,)".ToCharArray)
            Dim x As Integer = Integer.Parse(values(1))
            Dim y As Integer = Integer.Parse(values(3))
            Return New SortablePoint(x, y)
        Catch
            Throw New ArgumentException("Unable to parse " & pointString _
            & " into a SortablePoint instance.")
        End Try
    End Function


End Class