using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace TrainGameCS
{
	/// <summary>
	/// Summary description for Track.
	/// </summary>
    [System.ComponentModel.DefaultEvent("CaughtOnFire")]
    public class Track : System.Windows.Forms.UserControl
	{
        private System.ComponentModel.IContainer components;

		public Track()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call
            this.Height = 15;
		}

        protected override void OnSizeChanged(System.EventArgs e) {
            this.Height = TrackHeight;
            // width must be divisible by BarSpacing
            int nBars = this.Width / BarSpacing;
            this.Width = nBars * BarSpacing;
        }

        protected override void OnPaint(System.Windows.Forms.PaintEventArgs e) {
            base.OnPaint(e);
            System.Drawing.Drawing2D.GraphicsPath gp = 
                new System.Drawing.Drawing2D.GraphicsPath();
            gp.FillMode = System.Drawing.Drawing2D.FillMode.Winding;
            int height = TrackHeight / 5;
            int nBars = this.Width / BarSpacing;
            for (int bar = 0; bar < nBars; bar++) {
                gp.AddRectangle(new System.Drawing.Rectangle(bar * BarSpacing,
                    height, BarSpacing, height));
                gp.AddRectangle(new System.Drawing.Rectangle(bar * BarSpacing,
                    height * 3, BarSpacing, height));
                gp.AddRectangle(new System.Drawing.Rectangle(bar * BarSpacing, 
                    0, BarWidth, TrackHeight));
            }
            e.Graphics.FillPath(System.Drawing.Brushes.SaddleBrown,gp);
        }


        private int m_fireFrequency = 1;
        public int FireFrequency {
            get { return m_fireFrequency; }
            set { 
                m_fireFrequency = value;
                timer1.Interval = m_fireFrequency * 1000;
            }
        }

        private const int TrackHeight = 15;            // must be divisible by 5
        private const int BarWidth = TrackHeight / 5;
        private System.Windows.Forms.Timer timer1;  // equal to rail width
        private const int BarSpacing = BarWidth * 2;


        public delegate void CaughtOnFireEventHandler(object sender, 
            CaughtOnFireEventArgs e);
        public event CaughtOnFireEventHandler CaughtOnFire;



		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Track
            // 
            this.Name = "Track";

        }
		#endregion

        private void timer1_Tick(object sender, System.EventArgs e) {
            if (CaughtOnFire != null) {
                System.Random randomNumber = new System.Random();
                CaughtOnFire(this, new CaughtOnFireEventArgs(
                    randomNumber.Next(0,this.Width)));
            }
        }
	}

    public class CaughtOnFireEventArgs : System.EventArgs {
        private int m_location = 0;
        public int Location {
            get {
                return m_location;
            }
        }
        public CaughtOnFireEventArgs(int location) {
            m_location = location;
        }

    
    }



}
