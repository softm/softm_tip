using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace TrainGameCS
{
	/// <summary>
	/// Summary description for Train.
	/// </summary>
	/// 
    [System.ComponentModel.DefaultEvent("DistanceChanged")]
	public class Train : System.Windows.Forms.UserControl
	{
        private System.ComponentModel.IContainer components;

		public Train()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

        public delegate void DistanceChangedEventHandler(object sender,
            DistanceChangedEventArgs e);
        public event DistanceChangedEventHandler DistanceChanged;


        private int m_speed = 0;
        private System.Windows.Forms.Timer timer1;
    
        public int Speed {
            get {
                return m_speed;
            }
            set {
                if (value >= 0) {
                    m_speed = value;
                }
            }
        }

        private int m_distance = 0;
        public int Distance {
            get {
                return m_distance;
            }
        }


        public void Reset() {
            m_distance = 0;
        }






		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Train
            // 
            this.Name = "Train";

        }
		#endregion

        private void timer1_Tick(object sender, System.EventArgs e) {
            if (m_speed > 0) {
                m_distance += (int)((double)m_speed * ((double)timer1.Interval / 1000F));
                if (DistanceChanged != null) {
                    DistanceChanged(this,new DistanceChangedEventArgs(m_distance));
                }
            }
        }
	}

    public class DistanceChangedEventArgs : System.EventArgs {
        private int m_distance;
        public int Distance {
            get { return m_distance; }
        }

        public DistanceChangedEventArgs(int distance) {
            m_distance = distance;
        }
    }
}
