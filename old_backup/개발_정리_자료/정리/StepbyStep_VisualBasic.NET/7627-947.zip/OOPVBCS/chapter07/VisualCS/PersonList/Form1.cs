using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace PersonList
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListBox personList;
		private System.Windows.Forms.TextBox personsName;
		private System.Windows.Forms.Button addPerson;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.personList = new System.Windows.Forms.ListBox();
			this.personsName = new System.Windows.Forms.TextBox();
			this.addPerson = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// personList
			// 
			this.personList.Location = new System.Drawing.Point(16, 16);
			this.personList.Name = "personList";
			this.personList.Size = new System.Drawing.Size(120, 95);
			this.personList.Sorted = true;
			this.personList.TabIndex = 0;
			// 
			// personsName
			// 
			this.personsName.Location = new System.Drawing.Point(16, 136);
			this.personsName.Name = "personsName";
			this.personsName.TabIndex = 1;
			this.personsName.Text = "";
			// 
			// addPerson
			// 
			this.addPerson.Location = new System.Drawing.Point(16, 168);
			this.addPerson.Name = "addPerson";
			this.addPerson.TabIndex = 2;
			this.addPerson.Text = "Add";
			this.addPerson.Click += new System.EventHandler(this.addPerson_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(152, 206);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.addPerson,
																		  this.personsName,
																		  this.personList});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void addPerson_Click(object sender, System.EventArgs e)
		{
			try 
			{
				personList.Items.Add(new Person(personsName.Text));
			}
			catch (NameFormatIncorrectException nameException)
			{
				if (nameException.InnerException != null)
				{
					MessageBox.Show(nameException.Message + "\n" +
						nameException.InnerException.Message);
				}
				else 
				{
					MessageBox.Show(nameException.Message);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			personsName.Text = "";
		}
	}

	public class NameFormatIncorrectException : System.ApplicationException 
	{
		public NameFormatIncorrectException() : base()
		{
		}

		public NameFormatIncorrectException(string message) : base(message)
		{
		}
		public NameFormatIncorrectException(string message,
			Exception innerException):
			base(message,innerException)
		{
		}
	}

	public class Person 
	{
		private string m_first;
		private string m_last;
		public string FirstName 
		{
			get {return m_first;}
			set {m_first = value;}
		}
		public string LastName 
		{
			get {return m_last;}
			set {m_last = value;}
		}

		public override string ToString()
		{
			return m_last + ", " + m_first;
		}

		public Person(string firstlast)
		{
			try 
			{
				string splitCharacters = " ";
				string[] names = firstlast.Split(splitCharacters.ToCharArray());
				m_first = names[0];
				m_last = names[1];
			}
			catch (Exception ex)
			{
				throw new NameFormatIncorrectException("Cannot find the first " + 
				"name and last name in the string: " + firstlast, ex);
			}
		}

	}

}
