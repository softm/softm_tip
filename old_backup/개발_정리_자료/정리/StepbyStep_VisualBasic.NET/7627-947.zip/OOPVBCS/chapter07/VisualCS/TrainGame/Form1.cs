using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace TrainGame
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private TrainGame.Track track1;
		private System.Windows.Forms.PictureBox fire;
		private System.Windows.Forms.TrackBar throttle;
		private TrainGame.Train train1;
		private System.Windows.Forms.Button reset;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.track1 = new TrainGame.Track();
			this.fire = new System.Windows.Forms.PictureBox();
			this.throttle = new System.Windows.Forms.TrackBar();
			this.train1 = new TrainGame.Train();
			this.reset = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.throttle)).BeginInit();
			this.SuspendLayout();
			// 
			// track1
			// 
			this.track1.FireFrequency = 3;
			this.track1.Location = new System.Drawing.Point(16, 80);
			this.track1.Name = "track1";
			this.track1.Size = new System.Drawing.Size(264, 15);
			this.track1.TabIndex = 0;
			this.track1.CaughtOnFire += new TrainGame.Track.CaughtOnFireEventHandler(this.track1_CaughtOnFire);
			// 
			// fire
			// 
			this.fire.Image = ((System.Drawing.Bitmap)(resources.GetObject("fire.Image")));
			this.fire.Location = new System.Drawing.Point(248, 48);
			this.fire.Name = "fire";
			this.fire.Size = new System.Drawing.Size(32, 32);
			this.fire.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.fire.TabIndex = 1;
			this.fire.TabStop = false;
			// 
			// throttle
			// 
			this.throttle.LargeChange = 10;
			this.throttle.Location = new System.Drawing.Point(296, 16);
			this.throttle.Maximum = 50;
			this.throttle.Name = "throttle";
			this.throttle.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.throttle.Size = new System.Drawing.Size(45, 104);
			this.throttle.SmallChange = 5;
			this.throttle.TabIndex = 2;
			this.throttle.TickFrequency = 10;
			this.throttle.ValueChanged += new System.EventHandler(this.throttle_ValueChanged);
			// 
			// train1
			// 
			this.train1.BackgroundImage = ((System.Drawing.Bitmap)(resources.GetObject("train1.BackgroundImage")));
			this.train1.Location = new System.Drawing.Point(16, 48);
			this.train1.Name = "train1";
			this.train1.Size = new System.Drawing.Size(32, 32);
			this.train1.Speed = 0;
			this.train1.TabIndex = 3;
			this.train1.DistanceChanged += new TrainGame.Train.DistanceChangedEventHandler(this.train1_DistanceChanged);
			// 
			// reset
			// 
			this.reset.Location = new System.Drawing.Point(272, 128);
			this.reset.Name = "reset";
			this.reset.TabIndex = 4;
			this.reset.Text = "New game";
			this.reset.Click += new System.EventHandler(this.reset_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(352, 158);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.reset,
																		  this.train1,
																		  this.throttle,
																		  this.fire,
																		  this.track1});
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.throttle)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void track1_CaughtOnFire(object sender, TrainGame.CaughtOnFireEventArgs e)
		{
			fire.Location = new System.Drawing.Point(track1.Left
				+ e.Location,track1.Top - fire.Height);
		}

		private void train1_DistanceChanged(object sender, TrainGame.DistanceChangedEventArgs e)
		{
			train1.Left = track1.Left + e.Distance;
			if (train1.Right >= track1.Right)
			{
				train1.Speed = 0;
				throttle.Value = 0;
			}
		}

		private void throttle_ValueChanged(object sender, System.EventArgs e)
		{
			if (train1.Right <track1.Right)
			{
				train1.Speed =throttle.Value;
			}
			else 
			{
				throttle.Value =0;
			}
		}

		private void reset_Click(object sender, System.EventArgs e)
		{
			train1.ReStart();
			throttle.Value = 0;
			//explicitly set speed, although trackbar_ValueChanged will do it
			train1.Speed = 0;
			train1.Left = track1.Left;
		}
	}
}
