Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Track1 As TrainGame.Track
    Friend WithEvents fire As System.Windows.Forms.PictureBox
    Friend WithEvents throttle As System.Windows.Forms.TrackBar
    Friend WithEvents Train1 As TrainGame.Train
    Friend WithEvents reset As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.Track1 = New TrainGame.Track()
        Me.fire = New System.Windows.Forms.PictureBox()
        Me.throttle = New System.Windows.Forms.TrackBar()
        Me.Train1 = New TrainGame.Train()
        Me.reset = New System.Windows.Forms.Button()
        CType(Me.throttle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Track1
        '
        Me.Track1.FireFrequency = 3
        Me.Track1.Location = New System.Drawing.Point(16, 104)
        Me.Track1.Name = "Track1"
        Me.Track1.Size = New System.Drawing.Size(252, 15)
        Me.Track1.TabIndex = 0
        '
        'fire
        '
        Me.fire.Image = CType(resources.GetObject("fire.Image"), System.Drawing.Bitmap)
        Me.fire.Location = New System.Drawing.Point(232, 72)
        Me.fire.Name = "fire"
        Me.fire.Size = New System.Drawing.Size(32, 32)
        Me.fire.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.fire.TabIndex = 1
        Me.fire.TabStop = False
        '
        'throttle
        '
        Me.throttle.LargeChange = 10
        Me.throttle.Location = New System.Drawing.Point(288, 16)
        Me.throttle.Maximum = 50
        Me.throttle.Name = "throttle"
        Me.throttle.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.throttle.Size = New System.Drawing.Size(45, 104)
        Me.throttle.SmallChange = 5
        Me.throttle.TabIndex = 2
        Me.throttle.TickFrequency = 10
        '
        'Train1
        '
        Me.Train1.BackgroundImage = CType(resources.GetObject("Train1.BackgroundImage"), System.Drawing.Bitmap)
        Me.Train1.Location = New System.Drawing.Point(24, 72)
        Me.Train1.Name = "Train1"
        Me.Train1.Size = New System.Drawing.Size(32, 32)
        Me.Train1.Speed = 0
        Me.Train1.TabIndex = 3
        '
        'reset
        '
        Me.reset.Location = New System.Drawing.Point(264, 128)
        Me.reset.Name = "reset"
        Me.reset.TabIndex = 4
        Me.reset.Text = "New game"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(344, 166)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.reset, Me.Train1, Me.throttle, Me.fire, Me.Track1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.throttle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Track1_CaughtOnFire(ByVal sender As System.Object, ByVal e As TrainGame.CaughtOnFireEventsArgs) Handles Track1.CaughtOnFire
        fire.Location = New System.Drawing.Point(Track1.Left + e.Location, _
            Track1.Top - fire.Height)
    End Sub

    Private Sub Train1_DistanceChanged(ByVal sender As System.Object, ByVal e As TrainGame.DistanceChangedEventArgs) Handles Train1.DistanceChanged
        Train1.Left = Track1.Left + e.Distance
        If Train1.Right >= Track1.Right Then
            Train1.Speed = 0
            throttle.Value = 0
        End If
    End Sub

    Private Sub throttle_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles throttle.ValueChanged
        If Train1.Right < Track1.Right Then
            Train1.Speed = throttle.Value
        Else
            throttle.Value = 0
        End If
    End Sub

    Private Sub reset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles reset.Click
        Train1.ReStart()
        throttle.Value = 0
        ' explicitly set speed, although trackbar_ValueChanged will do it
        Train1.Speed = 0
        Train1.Left = Track1.Left
    End Sub
End Class
