<System.ComponentModel.DefaultEvent("CaughtOnFire")> Public Class Track
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Track
        '
        Me.Name = "Track"

    End Sub

#End Region

    Private m_fireFrequency As Integer = 1
    Public Property FireFrequency() As Integer
        Get
            Return m_fireFrequency
        End Get
        Set(ByVal Value As Integer)
            If Value >= 1 Then
                m_fireFrequency = Value
                Timer1.Interval = m_fireFrequency * 1000
            End If
        End Set
    End Property

    Private Const TrackHeight As Integer = 15           ' Must be divisible by 5
    Private Const BarWidth As Integer = TrackHeight \ 5 'Equal to rail width
    Private Const BarSpacing As Integer = BarWidth * 2


    Private Sub Track_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Height = 15
    End Sub

    Protected Overrides Sub OnSizeChanged(ByVal e As System.EventArgs)
        Me.Height = TrackHeight
        ' Width must be divisible by BarSpacing
        Dim nBars As Integer = Me.Width \ BarSpacing
        Me.Width = nBars * BarSpacing
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As _
System.Windows.Forms.PaintEventArgs)
        MyBase.OnPaint(e)
        Dim gp As New System.Drawing.Drawing2D.GraphicsPath()
        gp.FillMode = Drawing.Drawing2D.FillMode.Winding
        Dim height As Integer = TrackHeight \ 5
        Dim nBars As Integer = Me.Width \ BarSpacing
        Dim bar As Integer
        For bar = 0 To nBars - 1
            gp.AddRectangle(New System.Drawing.Rectangle( _
bar * BarSpacing, height, BarSpacing, height))
            gp.AddRectangle(New System.Drawing.Rectangle( _
bar * BarSpacing, height * 3, BarSpacing, height))
            gp.AddRectangle(New System.Drawing.Rectangle( _
bar * BarSpacing, 0, BarWidth, TrackHeight))
        Next
        e.Graphics.FillPath(System.Drawing.Brushes.SaddleBrown, gp)
    End Sub

    Public Event CaughtOnFire(ByVal sender As Object, _
ByVal e As CaughtOnFireEventsArgs)



    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Dim randomNumber As New System.Random()
        RaiseEvent CaughtOnFire(Me, _
            New CaughtOnFireEventsArgs(randomNumber.Next(0, Me.Width)))
    End Sub
End Class

Public Class CaughtOnFireEventsArgs
    Inherits System.EventArgs

    Private m_location As Integer = 0
    Public ReadOnly Property Location() As Integer
        Get
            Return m_location
        End Get
    End Property

    Public Sub New(ByVal location As Integer)
        m_location = location
    End Sub


End Class