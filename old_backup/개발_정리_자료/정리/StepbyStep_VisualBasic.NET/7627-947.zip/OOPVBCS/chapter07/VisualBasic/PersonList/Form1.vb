Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents personList As System.Windows.Forms.ListBox
    Friend WithEvents personsName As System.Windows.Forms.TextBox
    Friend WithEvents addPerson As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.personList = New System.Windows.Forms.ListBox()
        Me.personsName = New System.Windows.Forms.TextBox()
        Me.addPerson = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'personList
        '
        Me.personList.Location = New System.Drawing.Point(16, 16)
        Me.personList.Name = "personList"
        Me.personList.Size = New System.Drawing.Size(120, 95)
        Me.personList.Sorted = True
        Me.personList.TabIndex = 0
        '
        'personsName
        '
        Me.personsName.Location = New System.Drawing.Point(16, 128)
        Me.personsName.Name = "personsName"
        Me.personsName.TabIndex = 1
        Me.personsName.Text = ""
        '
        'addPerson
        '
        Me.addPerson.Location = New System.Drawing.Point(16, 160)
        Me.addPerson.Name = "addPerson"
        Me.addPerson.TabIndex = 2
        Me.addPerson.Text = "Add"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(152, 198)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.addPerson, Me.personsName, Me.personList})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region




    Private Sub addPerson_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addPerson.Click
        Try
            personList.Items.Add(New Person(personsName.Text))
        Catch nameException As NameFormatIncorrectException
            If Not IsNothing(nameException.InnerException) Then
                MessageBox.Show(nameException.Message & ControlChars.CrLf _
                & nameException.InnerException.Message)
            Else
                MessageBox.Show(nameException.Message)
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
        personsName.Text = ""
    End Sub
End Class

Public Class NameFormatIncorrectException
    Inherits System.ApplicationException

    Public Sub New()
        MyBase.New()
    End Sub
    Public Sub New(ByVal message As String)
        MyBase.New(Message)
    End Sub
    Public Sub New(ByVal message As String, _
    ByVal innerException As Exception)
        MyBase.New(message, innerException)
    End Sub
End Class
Public Class Person
    Private m_first As String
    Private m_last As String
    Public Property FirstName() As String
        Get
            Return m_first
        End Get
        Set(ByVal Value As String)
            m_first = Value
        End Set
    End Property
    Public Property LastName() As String
        Get
            Return m_last
        End Get
        Set(ByVal Value As String)
            m_last = Value
        End Set
    End Property

    Public Overrides Function ToString() As String
        Return m_last & ", " & m_first
    End Function

    Public Sub New(ByVal firstlast As String)
        Try
            Dim splitCharacters As String = " "
            Dim names() As String = _
            firstlast.Split(splitCharacters.ToCharArray())
            m_first = names(0)
            m_last = names(1)
        Catch ex As Exception
            Throw New NameFormatIncorrectException( _
            "Cannot find the first name and last name in the string:" _
            & firstlast, ex)
        End Try
    End Sub

End Class