<System.ComponentModel.DefaultEvent("DistanceChanged")> Public Class Train
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Train
        '
        Me.Name = "Train"

    End Sub

#End Region


    Private m_speed As Integer = 0
    Public Property Speed() As Integer
        Get
            Return m_speed
        End Get
        Set(ByVal Value As Integer)
            If Value >= 0 Then
                m_speed = Value
            End If
        End Set
    End Property

    Private m_distance As Integer = 0
    Public ReadOnly Property Distance() As Integer
        Get
            Return m_distance
        End Get
    End Property

    Public Sub ReStart()
        m_distance = 0
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If m_speed > 0 Then
            m_distance += Convert.ToInt32(Convert.ToInt32(m_speed) _
                * (Convert.ToDouble(Timer1.Interval) / 1000.0F))
            RaiseEvent DistanceChanged(Me, _
                New DistanceChangedEventArgs(m_distance))
        End If
    End Sub

    Public Event DistanceChanged(ByVal sender As Object, _
        ByVal e As DistanceChangedEventArgs)

End Class

Public Class DistanceChangedEventArgs
    Inherits System.EventArgs
    Private m_distance As Integer
    Public ReadOnly Property Distance() As Integer
        Get
            Return m_distance
        End Get
    End Property
    Public Sub New(ByVal distance As Integer)
        m_distance = distance
    End Sub
End Class