Class SortablePoint
    Implements IComparable, IFormattable

    Private m_x As Integer = 0
    Public Property X() As Integer
        Get
            Return m_x
        End Get
        Set(ByVal Value As Integer)
            m_x = Value
        End Set
    End Property
    Private m_y As Integer = 0
    Public Property Y() As Integer
        Get
            Return m_y
        End Get
        Set(ByVal Value As Integer)
            m_y = Value
        End Set
    End Property

    Public Sub New()
    End Sub
    Public Sub New(ByVal x As Integer, ByVal y As Integer)
        m_x = x
        m_y = y
    End Sub

    Public Function CompareTo(ByVal obj As Object) As Integer Implements System.IComparable.CompareTo
        Return Me.SquaredDistance() - _
            CType(obj, SortablePoint).SquaredDistance()
    End Function

    Private Function SquaredDistance() As Integer
        Return (m_x * m_x) + (m_y * m_y)
    End Function

    Public Function ToString(ByVal format As String, _
    ByVal formatProvider As System.IFormatProvider) As String _
    Implements System.IFormattable.ToString
        Dim result As String
        Select Case format.ToUpper()
            Case "L"
                result = String.Format("({0},{1})", m_x, m_y)
            Case "S"
                result = String.Format("{0},{1}", m_x, m_y)
            Case Else
                result = (m_x.ToString(format, formatProvider) & " " _
& m_y.ToString(format, formatProvider))
        End Select
        Return result
    End Function

    Public Overrides Function ToString() As String
        Return Me.ToString("L ")
    End Function
    Public Function ToString(ByVal format As String) As String
        Return Me.ToString(format, Nothing)
    End Function

End Class