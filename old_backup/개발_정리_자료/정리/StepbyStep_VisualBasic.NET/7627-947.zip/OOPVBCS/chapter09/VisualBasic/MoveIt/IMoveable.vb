Public Enum Direction
    Up
    Down
    Left
    Right
End Enum

Public Interface IMoveable

    Property X() As Integer
    Property Y() As Integer

    Sub Move(ByVal aDirection As Direction, ByVal howFar As Integer)

End Interface