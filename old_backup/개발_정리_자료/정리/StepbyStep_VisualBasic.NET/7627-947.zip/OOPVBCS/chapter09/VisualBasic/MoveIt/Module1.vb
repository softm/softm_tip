Module Module1

    Sub Main()
        Dim mover As IMoveable = New Pawn()
        mover.X = 10
        mover.Y = 10
        Console.WriteLine("X:{0} Y:{1}", mover.X, mover.Y)
        Console.WriteLine("Moving up 5 spaces.")
        mover.Move(Direction.Up, 5)
        Console.WriteLine("X:{0} Y:{1}", mover.X, mover.Y)
        Dim aPawn As Pawn = CType(mover, Pawn)
        Console.WriteLine("Is the pawn captured? {0}", aPawn.Captured)
    End Sub

End Module
