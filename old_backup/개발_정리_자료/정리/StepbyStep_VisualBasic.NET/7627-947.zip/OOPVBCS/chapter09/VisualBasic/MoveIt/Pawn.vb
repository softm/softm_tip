Public Class Pawn
    Implements IMoveable

    Public Sub Move(ByVal aDirection As MoveIt.Direction, ByVal howFar _
    As Integer) Implements MoveIt.IMoveable.Move
        Select Case aDirection
            Case Direction.Up
                m_y += howFar
            Case Direction.Down
                m_y -= howFar
            Case Direction.Left
                m_x -= howFar
            Case Direction.Right
                m_x += howFar
        End Select
    End Sub

    Private m_x As Integer = 0

    Public Property X() As Integer Implements MoveIt.IMoveable.X
        Get
            Return m_x
        End Get
        Set(ByVal Value As Integer)
            m_x = Value
        End Set
    End Property

    Private m_y As Integer = 0
    Public Property Y() As Integer Implements MoveIt.IMoveable.Y
        Get
            Return m_y
        End Get
        Set(ByVal Value As Integer)
            m_y = Value
        End Set
    End Property

    Private m_captured As Boolean = False
    Public Property Captured() As Boolean
        Get
            Return m_captured
        End Get
        Set(ByVal Value As Boolean)
            m_captured = Value
        End Set
    End Property

End Class
