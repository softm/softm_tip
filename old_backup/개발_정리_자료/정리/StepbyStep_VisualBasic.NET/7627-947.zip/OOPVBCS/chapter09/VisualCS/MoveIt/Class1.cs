using System;

namespace MoveIt
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			IMoveable mover =new Pawn();
			mover.X =10;
			mover.Y =10;
			Console.WriteLine("X:{0} Y:{1}",mover.X, mover.Y);
			Console.WriteLine("Moving up 5 spaces.");
			mover.Move(Direction.Up, 5);
			Console.WriteLine("X:{0} Y:{1}",mover.X, mover.Y);
			Pawn pawn =(Pawn)mover;
			Console.WriteLine("Is the pawn captured? {0}",pawn.Captured);
		}
	}
}
