namespace MoveIt 
{
	public enum Direction { Up, Down, Left, Right };

	public interface IMoveable 
	{
		int X 
		{
			get;
			set;
		}
		int Y 
		{
			get;
			set;
		}

		void Move(Direction direction, int howFar);

	}
}