using System;

namespace Points
{
	/// <summary>
	/// Summary description for SortablePoint.
	/// </summary>
	public class SortablePoint : IComparable, IFormattable
	{
		public SortablePoint()
		{
		}
		public SortablePoint(int x,int y)
		{
			m_x =x;
			m_y =y;
		}


		private int m_x = 0;
		public int X 
		{
			get {return m_x;}
			set {m_x = value;}
		}
		
		private int m_y = 0;
		public int Y 
		{
			get {return m_y;}
			set {m_y = value;}
		}

		#region Implementation of IComparable
		public int CompareTo(object obj)
		{
			return this.SquaredDistance() - 
				((SortablePoint)obj).SquaredDistance();
		}
		private int SquaredDistance()
		{
			return (m_x * m_x) + (m_y * m_y);
		}

		#endregion
		

		#region Implementation of IFormattable
		public string ToString(string format,System.IFormatProvider
			formatProvider)
		{
			string result;
			switch (format.ToUpper())
			{
				case "L":
					result =string.Format("({0},{1})", X, Y);
					break;
			case "S":   
				result = string.Format("{0}:{1}", X, Y);
				break;
			default:						
				result = X.ToString(formatProvider) + " "
					+Y.ToString(formatProvider);
			break;
		}
			return result;
		}
#endregion

		public override string ToString()
		{
			return this.ToString("L");
		}
		public string ToString(string format)
		{
			return this.ToString(format,null);
		}

	}
}
