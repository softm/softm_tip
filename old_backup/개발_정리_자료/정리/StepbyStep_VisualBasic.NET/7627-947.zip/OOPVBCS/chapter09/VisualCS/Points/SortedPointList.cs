using System;
using System.Collections;

namespace Points
{
	/// <summary>
	/// Summary description for SortedPointList.
	/// </summary>
	public class SortedPointList : IEnumerable
	{
		public SortedPointList()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private ArrayList m_points = new ArrayList();
		public void AddRandomPoints(int howMany,int maximum)
		{
			m_points.Clear();
			System.Random rgen = new System.Random();
			for (int count = 0; count < howMany; count++)
			{
				m_points.Add(new SortablePoint(rgen.Next(maximum),
					rgen.Next(maximum)));
			}
			m_points.Sort();
		}
	
		private class PointEnumerator : IEnumerator 
		{

			ArrayList m_points;
			int m_position = -1;
			int m_initialCount;

			public PointEnumerator(ArrayList points)
			{
				m_points =points;
				m_initialCount =points.Count;
			}

			#region Implementation of IEnumerator
			public void Reset()
			{
				m_position = -1;			
			}

			public bool MoveNext()
			{
				if (m_initialCount == m_points.Count)
				{
					m_position++;
					if (m_position >= m_points.Count)
					{
						return false;
					}
					else 
					{
						return true;
					}
				}
				else 
				{
					throw new InvalidOperationException(
						"Collection has changed during enumeration.");
				}
				return true;
			}
			
			public object Current
			{
				get 
				{
					if (m_initialCount != m_points.Count)
					{
						throw new InvalidOperationException(
							"Collection has changed during enumeration.");
					}
					else if (m_position >= m_points.Count)
					{
						throw new InvalidOperationException(
							"Enumeration value is invalid.");
					}
					else 
					{
						return m_points [m_position ];
					}
				}			
			}
			#endregion
		}

		#region Implementation of IEnumerable
		public System.Collections.IEnumerator GetEnumerator()
		{
			return new PointEnumerator(m_points);
		}
		#endregion

	}

}
