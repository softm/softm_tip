using System;

namespace MoveIt
{
	/// <summary>
	/// Summary description for Pawn.
	/// </summary>
	public class Pawn : IMoveable
	{
		public Pawn()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region Implementation of IMoveable

		private int m_x;
		public int X 
		{
			get {return m_x;}
			set {m_x = value;}
		}

		private int m_y;
		public int Y 
		{
			get {return m_y;}
			set {m_y = value;}
		}

		public void Move(Direction direction,int howFar)
		{
			switch (direction)
			{
				case Direction.Up :
					m_y +=howFar;
					break;
				case Direction.Down :
					m_y -=howFar;
					break;
				case Direction.Left :
					m_x -=howFar;
					break;
				case Direction.Right :
					m_x +=howFar;
					break;
			}
		}		

		private bool m_captured =false;
		public bool Captured 
		{
			get { return m_captured; }
			set { m_captured = value; }
		}


		#endregion
	}
}
