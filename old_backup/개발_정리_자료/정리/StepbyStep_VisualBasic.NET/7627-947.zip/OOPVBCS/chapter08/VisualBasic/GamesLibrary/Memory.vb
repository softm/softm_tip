<DefaultEvent("GameOver")> _
Public Class Memory
    Inherits System.Windows.Forms.UserControl

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region


    Private m_rows As Integer = 2
    <Category("Game"), Description("Number of rows in the grid.")> _
    Public Property Rows() As Integer
        Get
            Return m_rows
        End Get
        Set(ByVal Value As Integer)
            If Value > 0 Then
                m_rows = Value
                Me.Refresh()
            End If
        End Set
    End Property


    Private m_columns As Integer = 2
    <Category("Game"), Description("Number of columns in the grid.")> _
    Public Property Columns() As Integer
        Get
            Return m_columns
        End Get
        Set(ByVal Value As Integer)
            If Value > 0 Then
                m_columns = Value
                Me.Refresh()
            End If
        End Set
    End Property

    Private m_deck As Deck
    <Category("Game "), _
    Description("The deck used to fill the grid with cards.")> _
    Public Property Deck() As Deck
        Get
            Return m_deck
        End Get
        Set(ByVal Value As Deck)
            m_deck = Value
        End Set
    End Property

    Private Const m_spacing As Integer = 10
    Protected Overrides Sub OnPaint(ByVal e As _
    System.Windows.Forms.PaintEventArgs)
        Dim height As Integer = LotsOfFun.Games.Card.FixedHeight
        Dim width As Integer = LotsOfFun.Games.Card.FixedWidth
        Me.Width = (width + m_spacing) * m_columns + m_spacing
        Me.Height = (height + m_spacing) * m_rows + m_spacing
        ' Just draw the outline of the cards; the actual Card
        ' instances are added when Play is called.
        Dim g As Graphics = Me.CreateGraphics()
        Dim row, column As Integer
        For row = 0 To m_rows - 1
            For column = 0 To m_columns - 1
                g.DrawRectangle(System.Drawing.Pens.Gray, _
                column * (width + m_spacing) + m_spacing, _
                row * (height + m_spacing) + m_spacing, width, height)
            Next
        Next
    End Sub

    Private m_clicks As Integer = 0
    Public Event GameOver(ByVal sender As Object, ByVal e As GameOverEventArgs)

    Private Sub CardOver(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim theCard As Card = CType(sender, Card)
        theCard.FaceUp = Not theCard.FaceUp
        theCard.Refresh()
        m_clicks += 1
        CheckForPair()
        If (Me.Controls.Count = 0) Then
            RaiseEvent GameOver(Me, New GameOverEventArgs(m_clicks))
        End If
    End Sub

    Public Sub Play()
        ' Reset controls and clicks before starting the next game.
        Dim aControl As Control
        For Each aControl In Me.Controls
            RemoveHandler aControl.Click, AddressOf Me.CardOver
        Next
        Me.Controls.Clear()
        ' If m_deck is null,the grid is empty,and there is
        ' no game play.
        If Not IsNothing(m_deck) Then
            ' The deck should have the right number of cards
            ' before the game can begin.
            If (m_deck.Count <> (m_rows * m_columns)) Then
                Throw New DeckGridIncompatibilityException(String.Format( _
"Cards:{0}Cells:{1}", m_deck.Count, m_rows * m_columns))
            End If
            ' Add the cards from the deck to the game.
            m_clicks = 0
            m_deck.Shuffle()
            Dim cardCounter As Integer = 0
            Dim row, column As Integer
            For row = 0 To m_rows - 1
                For column = 0 To m_columns - 1
                    Dim aCard As Card = CType(m_deck(cardCounter), Card)
                    aCard.FaceUp = False
                    AddHandler aCard.Click, AddressOf Me.CardOver
                    Me.Controls.Add(aCard)
                    aCard.Left = column * (Card.FixedWidth + m_spacing) _
+ m_spacing
                    aCard.Top = row * (Card.FixedHeight + m_spacing) _
+ m_spacing
                    cardCounter += 1
                Next
            Next
        End If
    End Sub

    Private Sub CheckForPair()
        System.Threading.Thread.Sleep(500)
        Dim nFaceUp As Integer = 0
        Dim cards(1) As Card
        Dim count As Integer
        For count = 0 To Me.Controls.Count - 1
            Dim aCard As Card = CType(Me.Controls(count), Card)
            If aCard.FaceUp Then
                cards(nFaceUp) = aCard
                nFaceUp += 1
            End If
        Next
        If nFaceUp = 2 Then
            If (cards(0).FaceValue = cards(1).FaceValue) Then
                Me.Controls.Remove(cards(0))
                Me.Controls.Remove(cards(1))
                RemoveHandler cards(0).Click, AddressOf Me.CardOver
                RemoveHandler cards(1).Click, AddressOf Me.CardOver
                Me.Refresh()
            Else
                cards(0).FaceUp = False
                cards(1).FaceUp = False
            End If
        End If
    End Sub

End Class

Public Class GameOverEventArgs
    Inherits System.EventArgs
    Private m_clicks As Integer
    Public Sub New(ByVal clicks As Integer)
        m_clicks = clicks
    End Sub
    Public ReadOnly Property Clicks() As Integer
        Get
            Return m_clicks
        End Get
    End Property
End Class

Public Class DeckGridIncompatibilityException
    Inherits System.ApplicationException
    Public Sub New()
        MyBase.New()
    End Sub
    Public Sub New(ByVal message As String)
        MyBase.New(message)
    End Sub
    Public Sub New(ByVal message As String, _
    ByVal innerException As Exception)
        MyBase.New(message, innerException)
    End Sub
End Class
