Public Class Deck
    Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
        MakeDeck()
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        MakeDeck()
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Dim m_suits() As Suit = {Suit.Clubs, Suit.Diamonds, Suit.Hearts, _
Suit.Spades}

    <Category("Game"), Description("The suits in the deck.")> _
    Public Property Suits() As Suit()
        Get
            Return m_suits
        End Get
        Set(ByVal Value As Suit())
            m_suits = Value
            Me.MakeDeck()
        End Set
    End Property

    Dim m_faceValues() As FaceValue = {FaceValue.Ace, FaceValue.Two, _
    FaceValue.Three, FaceValue.Four, FaceValue.Five, FaceValue.Six, _
    FaceValue.Seven, FaceValue.Eight, FaceValue.Nine, FaceValue.Ten, _
    FaceValue.Jack, FaceValue.Queen, FaceValue.King}
    <Category("Game "), Description("The face values in the deck.")> _
        Public Property FaceValues() As FaceValue()
        Get
            Return m_faceValues
        End Get
        Set(ByVal Value As FaceValue())
            m_faceValues = Value
            Me.MakeDeck()
        End Set
    End Property

    Dim m_cards As New System.Collections.ArrayList()
    Private Sub MakeDeck()
        ' Dispose of the existing cards.
        Dim count As Integer
        For count = 0 To m_cards.Count - 1
            CType(m_cards(count), Card).Dispose()
        Next
        m_cards.Clear()
        ' Add the new cards.
        Dim asuit, avalue As Integer
        For asuit = 0 To suits.Length - 1
            For avalue = 0 To m_faceValues.Length - 1
                m_cards.Add(New Card(m_suits(asuit), m_faceValues(avalue)))
            Next
        Next
    End Sub

    Public Sub Shuffle()
        Dim rgen As New System.Random()
        Dim newdeck As New System.Collections.ArrayList()
        While (m_cards.Count > 0)
            ' Choose one card at random.
            Dim removeindex As Integer = rgen.Next(0, m_cards.Count - 1)
            Dim removeobject As Object = m_cards(removeindex)
            m_cards.RemoveAt(removeindex)
            ' Add the removed card to the new collection.
            newdeck.Add(removeobject)
        End While
        ' Replace the old deck with the new deck.
        m_cards = newdeck
    End Sub

    <Category("Game"), Description("Number of cards in the deck.")> _
    Public ReadOnly Property Count() As Integer
        Get
            Return m_cards.Count
        End Get
    End Property

    Default Public ReadOnly Property Cards(ByVal indexer As Integer) As Card
        Get
            If ((indexer >= 0) And (indexer < m_cards.Count)) Then
                Return CType(m_cards(indexer), Card)
            Else
                Throw New ArgumentOutOfRangeException("Index out of range.")
            End If
        End Get
    End Property


End Class
