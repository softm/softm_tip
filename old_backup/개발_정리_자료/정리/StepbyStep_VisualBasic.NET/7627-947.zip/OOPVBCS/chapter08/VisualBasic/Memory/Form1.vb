Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Deck1 As LotsOfFun.Games.Deck
    Friend WithEvents Memory1 As LotsOfFun.Games.Memory
    Private components As System.ComponentModel.IContainer

    'Required by the Windows Form Designer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Deck1 = New LotsOfFun.Games.Deck(Me.components)
        Me.Memory1 = New LotsOfFun.Games.Memory()
        Me.SuspendLayout()
        '
        'Deck1
        '
        Me.Deck1.FaceValues = New LotsOfFun.Games.FaceValue() {LotsOfFun.Games.FaceValue.Ace, LotsOfFun.Games.FaceValue.Jack, LotsOfFun.Games.FaceValue.Queen, LotsOfFun.Games.FaceValue.King}
        Me.Deck1.Suits = New LotsOfFun.Games.Suit() {LotsOfFun.Games.Suit.Clubs, LotsOfFun.Games.Suit.Diamonds, LotsOfFun.Games.Suit.Hearts, LotsOfFun.Games.Suit.Spades}
        '
        'Memory1
        '
        Me.Memory1.Columns = 4
        Me.Memory1.Deck = Me.Deck1
        Me.Memory1.Location = New System.Drawing.Point(16, 16)
        Me.Memory1.Name = "Memory1"
        Me.Memory1.Rows = 4
        Me.Memory1.Size = New System.Drawing.Size(290, 350)
        Me.Memory1.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 382)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Memory1})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Memory1.Play()
    End Sub

    Private Sub Memory1_GameOver(ByVal sender As System.Object, ByVal e As LotsOfFun.Games.GameOverEventArgs) Handles Memory1.GameOver
        Dim result As DialogResult
        result = MessageBox.Show("You win in " & e.Clicks & _
        " turns." & ControlChars.CrLf & "Play again?", _
        "Game over", MessageBoxButtons.YesNo)
        If (result = DialogResult.Yes) Then
            Me.Memory1.Play()
        End If
    End Sub
End Class
