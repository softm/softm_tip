using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace LotsOfFun.Games
{
	/// <summary>
	/// Summary description for Memory.
	/// </summary>
	[DefaultEvent("GameOver")]
	public class Memory : System.Windows.Forms.UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Memory()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion


		private int m_rows =2;
		[Category("Game")]
		[Description("Number of rows in the grid.")]
		public int Rows 
		{
			get {return m_rows;}
			set 
			{
				if (value >0)
				{
					m_rows =value;
					this.Refresh();
				}
			}
		}

		private int m_columns =2;
		[Category("Game")]
		[Description("Number of columns in the grid.")]
		public int Columns 
		{
			get {return m_columns;}
			set 
			{
				if (value >0)
				{
					m_columns =value;
					this.Refresh();
				}
			}
		}

		private Deck m_deck;
		[Category("Game")]
		[Description("The deck used to fill the grid with cards.")]
		public Deck Deck 
		{
			get {return m_deck;}
			set {m_deck =value;}
		}

		private const int m_spacing =10;
		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			int height = LotsOfFun.Games.Card.FixedHeight;
			int width = LotsOfFun.Games.Card.FixedWidth;
			this.Width = (width +m_spacing)* m_columns + m_spacing;
			this.Height = (height +m_spacing)* m_rows + m_spacing;
			//this.Refresh();
			//Just draw the outline of the cards;the actual Card
			//instances are added when Play is called.
			Graphics g = this.CreateGraphics();
			for (int row =0; row < m_rows; row++)
			{
				for (int column =0; column < m_columns; column++)
				{
					g.DrawRectangle(System.Drawing.Pens.Gray,
						column * (width + m_spacing) + m_spacing,
						row * (height + m_spacing) + m_spacing, width, height);
				}
			}
		}

		private int m_clicks = 0;

		public delegate void
			GameOverHandler(object sender,GameOverEventArgs e);
		public event GameOverHandler GameOver;

		private void CardOver(object sender, System.EventArgs e)
		{
			Card card = (Card)sender;
			card.FaceUp =! card.FaceUp;
			card.Refresh();
			m_clicks++;
			CheckForPair();
			if ((this.Controls.Count == 0) && (GameOver !=null))
			{
				GameOver(this, new GameOverEventArgs(m_clicks));
			}
		}


		public void Play()
		{
			//Reset controls and clicks before starting the next game.
			foreach (Control control in this.Controls)
			{
				control.Click -=new System.EventHandler(this.CardOver);
			}
			this.Controls.Clear();
			//If m_deck is null,the grid is empty,and there is
			//no game play.
			if (m_deck !=null)
			{
				//The deck should have the right number of cards
				//before the game can begin.
				if (m_deck.Count != (m_rows * m_columns))
				{
					throw new DeckGridIncompatibilityException(String.Format(
						"Cards:{0}Cells:{1}", m_deck.Count, m_rows *m_columns));
				}
				//Add the cards from the deck to the game.
				m_clicks = 0;
				m_deck.Shuffle();
				int cardCounter = 0;
				for (int row = 0; row < m_rows; row++)
				{
					for (int column = 0; column < m_columns; column++)
					{
						Card card = m_deck [cardCounter ];
						card.FaceUp = false;
						card.Click += new System.EventHandler(this.CardOver);
						this.Controls.Add(card);
						card.Left = column *(Card.FixedWidth + m_spacing)
							+ m_spacing;
						card.Top = row *(Card.FixedHeight + m_spacing)
							+ m_spacing;
						cardCounter++;
					}
				}
			}
		}

		private void CheckForPair()
		{
			System.Threading.Thread.Sleep(500);
			int nfaceup = 0;
			Card[] cards = new Card [2 ];
			for (int i = 0; i < this.Controls.Count; i++)
			{
				Card card = (Card)this.Controls[i];
				if (card.FaceUp)
				{
					cards[nfaceup] = card;
					nfaceup++;
				}
			}
			if (nfaceup == 2)
			{
				if (cards[0].FaceValue == cards[1].FaceValue)
				{
					this.Controls.Remove(cards[0]);
					this.Controls.Remove(cards[1]);
					cards[0].Click -= new System.EventHandler(this.CardOver);
					cards[1].Click -= new System.EventHandler(this.CardOver);
					this.Refresh();
				}
				else 
				{
					cards[0].FaceUp = false;
					cards[1].FaceUp = false;
				}
			}
		}

	}

	public class GameOverEventArgs : System.EventArgs 
	{
		private int m_clicks;
		public GameOverEventArgs(int clicks)
		{
			m_clicks =clicks;
		}
		public int Clicks 
		{
			get {return m_clicks;}
		}
	}

	public class DeckGridIncompatibilityException
		:System.ApplicationException 
	{
		public DeckGridIncompatibilityException():base()
		{
		}
		public DeckGridIncompatibilityException(string message)
			:base(message)
		{
		}
		public DeckGridIncompatibilityException(string message,
			Exception innerException):base(message,innerException)
		{
		}
	}

}
