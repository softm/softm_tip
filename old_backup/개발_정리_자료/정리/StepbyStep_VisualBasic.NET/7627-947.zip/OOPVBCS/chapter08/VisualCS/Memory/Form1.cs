using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Memory
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private LotsOfFun.Games.Deck deck1;
		private LotsOfFun.Games.Memory memory1;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.deck1 = new LotsOfFun.Games.Deck(this.components);
			this.memory1 = new LotsOfFun.Games.Memory();
			this.SuspendLayout();
			// 
			// deck1
			// 
			this.deck1.FaceValues = new LotsOfFun.Games.FaceValue[] {
																		LotsOfFun.Games.FaceValue.Ace,
																		LotsOfFun.Games.FaceValue.Jack,
																		LotsOfFun.Games.FaceValue.Queen,
																		LotsOfFun.Games.FaceValue.King};
			this.deck1.Suits = new LotsOfFun.Games.Suit[] {
															  LotsOfFun.Games.Suit.Clubs,
															  LotsOfFun.Games.Suit.Diamonds,
															  LotsOfFun.Games.Suit.Hearts,
															  LotsOfFun.Games.Suit.Spades};
			// 
			// memory1
			// 
			this.memory1.Columns = 4;
			this.memory1.Deck = this.deck1;
			this.memory1.Location = new System.Drawing.Point(16, 16);
			this.memory1.Name = "memory1";
			this.memory1.Rows = 4;
			this.memory1.Size = new System.Drawing.Size(290, 350);
			this.memory1.TabIndex = 0;
			this.memory1.GameOver += new LotsOfFun.Games.Memory.GameOverHandler(this.memory1_GameOver);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(328, 382);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.memory1});
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			this.memory1.Play();
		}

		private void memory1_GameOver(object sender, LotsOfFun.Games.GameOverEventArgs e)
		{
			DialogResult result;
			result = MessageBox.Show("You win in " + e.Clicks +
				" turns.\nPlay again?", "Game over", MessageBoxButtons.YesNo);
			if (result ==DialogResult.Yes){
				this.memory1.Play();
			}

		}
	}
}
