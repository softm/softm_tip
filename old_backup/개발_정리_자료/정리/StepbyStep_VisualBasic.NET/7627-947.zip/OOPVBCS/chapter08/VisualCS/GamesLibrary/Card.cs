using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace LotsOfFun.Games
{
	public enum Suit 
	{
		Clubs, Spades, Diamonds, Hearts
	};

	public enum FaceValue 
	{
		Ace,Two,Three,Four,Five,Six,Seven,Eight,Nine,Ten,
		Jack,Queen,King
	};

	/// <summary>
	/// Summary description for UserControl1.
	/// </summary>
	public class Card : System.Windows.Forms.UserControl
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		SortedList m_images =new SortedList();
		
		public Card()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			m_images.Add(Suit.Clubs,new Icon("\\OOPVBCS\\Chapter08\\clubs.ico"));
			m_images.Add(Suit.Diamonds,new Icon("\\OOPVBCS\\Chapter08\\diamonds.ico"));
			m_images.Add(Suit.Hearts,new Icon("\\OOPVBCS\\Chapter08\\hearts.ico"));
			m_images.Add(Suit.Spades,new Icon("\\OOPVBCS\\Chapter08\\spades.ico"));

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Card
			// 
			this.Name = "Card";
			this.Size = new System.Drawing.Size(60, 75);
			this.SizeChanged += new System.EventHandler(this.Card_SizeChanged);
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Card_Paint);

		}
		#endregion


		public Card(Suit suit,FaceValue faceValue) : this()
		{
			m_suit =suit;
			m_faceValue =faceValue;
		}

		private FaceValue m_faceValue = FaceValue.Ace;
		[Category("Game")]
		[Description("Face value of the card.")]
		public FaceValue FaceValue 
		{
			get {return m_faceValue;}
			set 
			{
				m_faceValue =value;
				this.Refresh();
			}
		}

		private Suit m_suit =Suit.Hearts;
		[Category("Game")]
		[Description("Suit (Hearts,Spades,Diamonds,Clubs)")]
		public Suit Suit 
		{
				get {return m_suit;}
			set 
			{
				m_suit =value;
				this.Refresh();
			}
		}

		private bool m_faceUp =true;

		private void Card_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			Graphics g =this.CreateGraphics();
			g.DrawRectangle(System.Drawing.Pens.Black, 0, 0,
				this.ClientRectangle.Width-1, this.ClientRectangle.Height-1);
			if (this.m_faceUp)
			{
				this.BackColor =Color.White;
				g.DrawString(this.m_faceValue.ToString(),
					new System.Drawing.Font("Arial", 10, System.Drawing.FontStyle.Bold),
					System.Drawing.Brushes.Black, 3, 3);
				g.DrawIcon((Icon)(this.m_images[m_suit]), 14, 40);
			}
			else 
			{
				this.BackColor =Color.Blue;
			}
		}
		
		public const int FixedWidth =60;
		public const int FixedHeight =75;

		private void Card_SizeChanged(object sender, System.EventArgs e)
		{
			this.Size =new Size(FixedWidth,FixedHeight);
		}
	
		[Category("Game")]
		[Description("Is the card face up?")]
		public bool FaceUp 
		{
			get {return m_faceUp;}
			set 
			{
				m_faceUp =value;
				this.Refresh();
			}
		}



	}
}
