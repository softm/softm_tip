Public Class Form1
    Inherits System.Windows.Forms.Form



#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents listOfBooks As System.Windows.Forms.ListBox
    Friend WithEvents pageLength As System.Windows.Forms.NumericUpDown
    Friend WithEvents pageToDisplay As System.Windows.Forms.NumericUpDown
    Friend WithEvents page As System.Windows.Forms.RichTextBox
    Friend WithEvents titleLabel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.titleLabel = New System.Windows.Forms.Label()
        Me.pageToDisplay = New System.Windows.Forms.NumericUpDown()
        Me.pageLength = New System.Windows.Forms.NumericUpDown()
        Me.listOfBooks = New System.Windows.Forms.ListBox()
        Me.page = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.pageToDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pageLength, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'titleLabel
        '
        Me.titleLabel.Location = New System.Drawing.Point(168, 8)
        Me.titleLabel.Name = "titleLabel"
        Me.titleLabel.Size = New System.Drawing.Size(100, 16)
        Me.titleLabel.TabIndex = 4
        '
        'pageToDisplay
        '
        Me.pageToDisplay.Location = New System.Drawing.Point(168, 168)
        Me.pageToDisplay.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.pageToDisplay.Name = "pageToDisplay"
        Me.pageToDisplay.TabIndex = 2
        Me.pageToDisplay.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'pageLength
        '
        Me.pageLength.Location = New System.Drawing.Point(16, 168)
        Me.pageLength.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.pageLength.Name = "pageLength"
        Me.pageLength.TabIndex = 1
        Me.pageLength.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'listOfBooks
        '
        Me.listOfBooks.Location = New System.Drawing.Point(16, 32)
        Me.listOfBooks.Name = "listOfBooks"
        Me.listOfBooks.Size = New System.Drawing.Size(120, 95)
        Me.listOfBooks.TabIndex = 0
        '
        'page
        '
        Me.page.Location = New System.Drawing.Point(168, 32)
        Me.page.Name = "page"
        Me.page.Size = New System.Drawing.Size(120, 96)
        Me.page.TabIndex = 3
        Me.page.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 16)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "List of books"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 144)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Page length"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(168, 144)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Page to display"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 205)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label3, Me.Label2, Me.Label1, Me.titleLabel, Me.page, Me.pageToDisplay, Me.pageLength, Me.listOfBooks})
        Me.Name = "Form1"
        Me.Text = "Read Books"
        CType(Me.pageToDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pageLength, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

   

    Private Sub Form1_Load(ByVal sender As Object, _
    ByVal e As System.EventArgs) Handles MyBase.Load
        Dim fairyTales As Book = _
            New Book("Fairy Tales", "Once upon a time there was a bear.")
        Dim cookies As Book = New Book("Cookies", _
            "Chocolate chip cookies are the most delicious cookies.")
        Dim m_library() As Book = New Book() {fairyTales, cookies}
        listOfBooks.DataSource = m_library
    End Sub


    Private Sub listOfBooks_SelectedIndexChanged(ByVal sender _
    As System.Object, ByVal e As System.EventArgs) _
    Handles listOfBooks.SelectedIndexChanged
        Dim theBook As Book = CType(listOfBooks.SelectedItem, Book)

        titleLabel.Text = theBook.Title
        theBook.PageLength = Decimal.ToInt32(pageLength.Value)
        page.Text = theBook.GetPage(Decimal.ToInt32(pageToDisplay.Value))
    End Sub

End Class
