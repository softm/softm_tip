Public Class Book

    Private m_text As String = ""
    Public PageLength As Integer = 10
    Private m_title As String

    Public Property Title() As String
        Get
            Return m_title
        End Get
        Set(ByVal Value As String)
            m_title = Value
        End Set
    End Property

    Public Property Text() As String
        Get
            Return m_text
        End Get

        Set(ByVal Value As String)
            m_text = Value
        End Set

    End Property


    Public Function GetPage(ByVal pageNumber As Integer) As String
        Dim start As Integer = (pageNumber - 1) * PageLength
        If (start < Text.Length) And (start >= 0) Then
            If (start + PageLength) < Text.Length Then
                Return Text.Substring(start, PageLength)
            Else
                Return Text.Substring(start, Text.Length - start)
            End If
        Else
            Return ""
        End If
    End Function


    Public Sub New()

    End Sub

    Public Sub New(ByVal title As String, ByVal text As String)
        If (title <> "") And (text <> "") And _
        (Not IsNothing(title)) And (Not IsNothing(text)) Then
            m_title = title
            m_text = text
        Else
            Throw New Exception("Title or text is an empty string.")
        End If

    End Sub

    Public Overrides Function ToString() As String
        Return m_title
    End Function


End Class
