Public Class DrawnPatternEditor
    Inherits PatternEditor

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents save As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.save = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(8, 16)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(62, 62)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 1
        '
        'save
        '
        Me.save.Location = New System.Drawing.Point(8, 120)
        Me.save.Name = "save"
        Me.save.TabIndex = 2
        Me.save.Text = "Save"
        '
        'DrawnPatternEditor
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.save, Me.Label1, Me.PictureBox1})
        Me.Name = "DrawnPatternEditor"
        Me.Size = New System.Drawing.Size(175, 150)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private m_Points() As Point = New Point() {}
    Private m_pattern As DrawnPattern

    Public Sub New(ByVal pattern As DrawnPattern)
        MyBase.New()
        InitializeComponent()
        ReDim Me.m_Points(pattern.Points.Length - 1)
        pattern.Points.CopyTo(Me.m_Points, 0)
        AddHandler Me.pictureBox1.Paint, AddressOf Me.Draw
        m_pattern = pattern
    End Sub

    Public Sub Draw(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.PaintEventArgs)
        e.Graphics.DrawRectangle(New Pen(Brushes.Black, 1), 0, 0, 60, 60)
        Dim point As Integer
        For point = 0 To m_Points.Length - 2
            Dim one As Point = m_Points(point)
            Dim two As Point = m_Points(point + 1)
            e.Graphics.DrawLine(Pens.Black, one, two)
        Next
    End Sub

    Private Sub pictureBox1_MouseMove(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.MouseEventArgs) _
    Handles PictureBox1.MouseMove
        Me.Label1.Text = String.Format("({0},{1})", e.X, e.Y)
    End Sub

    Private Sub pictureBox1_MouseDown(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.MouseEventArgs) _
    Handles PictureBox1.MouseDown
        ReDim Preserve m_Points(m_Points.Length)
        m_Points(m_Points.Length - 1) = New Point(e.X, e.Y)
        Me.Refresh()
    End Sub

    Private Sub save_Click(ByVal sender As System.Object, _
    ByVal e As System.EventArgs) Handles save.Click
        m_pattern.Points = m_Points
        MyBase.RaiseSaved(Me, New System.EventArgs())
    End Sub

End Class
