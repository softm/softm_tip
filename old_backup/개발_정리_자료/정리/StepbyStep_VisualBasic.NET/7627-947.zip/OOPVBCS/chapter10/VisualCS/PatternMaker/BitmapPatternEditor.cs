using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace PatternMaker
{
	/// <summary>
	/// Summary description for BitmapPatternEditor.
	/// </summary>
	public class BitmapPatternEditor : PatternEditor
	{
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button browse;
		private System.Windows.Forms.Button save;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public BitmapPatternEditor()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// TODO: Add any initialization after the InitForm call

		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.browse = new System.Windows.Forms.Button();
			this.save = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.SuspendLayout();
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(61, 61);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// browse
			// 
			this.browse.Location = new System.Drawing.Point(8, 88);
			this.browse.Name = "browse";
			this.browse.TabIndex = 1;
			this.browse.Text = "Browse";
			this.browse.Click += new System.EventHandler(this.browse_Click);
			// 
			// save
			// 
			this.save.Location = new System.Drawing.Point(96, 88);
			this.save.Name = "save";
			this.save.TabIndex = 2;
			this.save.Text = "Save";
			this.save.Click += new System.EventHandler(this.save_Click);
			// 
			// BitmapPatternEditor
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.save,
																		  this.browse,
																		  this.pictureBox1});
			this.Name = "BitmapPatternEditor";
			this.Size = new System.Drawing.Size(175, 150);
			this.ResumeLayout(false);

		}
		#endregion

		private string m_bitmapFile;
		private BitmapPattern m_pattern = null;


		public BitmapPatternEditor(BitmapPattern pattern)
		{
			InitializeComponent();
			m_pattern = pattern;
			m_bitmapFile = pattern.BitmapFile;
			this.pictureBox1.Paint += new PaintEventHandler(this.Draw);
		}

		public void Draw(object sender,
			System.Windows.Forms.PaintEventArgs e)
		{
			e.Graphics.DrawImage(new
				System.Drawing.Bitmap(m_bitmapFile),0,0);
		}

		private void browse_Click(object sender, System.EventArgs e)
		{
			this.openFileDialog1.ShowDialog();
			if (this.openFileDialog1.FileName.Length !=0)
			{
				m_bitmapFile =this.openFileDialog1.FileName;
				this.pictureBox1.Refresh();
			}
		}

		private void save_Click(object sender, System.EventArgs e)
		{
			m_pattern.BitmapFile = m_bitmapFile;
			if (Saved !=null)
			{
				Saved(this,new System.EventArgs());
			}
		}

		public override event SavedEventHandler Saved;



	}

}
