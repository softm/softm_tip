using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ReadBooks
{

	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
        private Library m_library;        

        private System.Windows.Forms.ListBox listOfBooks;
        private System.Windows.Forms.NumericUpDown pageLength;
        private System.Windows.Forms.NumericUpDown pageToDisplay;
        private System.Windows.Forms.RichTextBox page;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.page = new System.Windows.Forms.RichTextBox();
            this.listOfBooks = new System.Windows.Forms.ListBox();
            this.pageLength = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pageToDisplay = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pageLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pageToDisplay)).BeginInit();
            this.SuspendLayout();
            // 
            // page
            // 
            this.page.Location = new System.Drawing.Point(160, 32);
            this.page.Name = "page";
            this.page.Size = new System.Drawing.Size(120, 96);
            this.page.TabIndex = 3;
            this.page.Text = "";
            // 
            // listOfBooks
            // 
            this.listOfBooks.Location = new System.Drawing.Point(16, 32);
            this.listOfBooks.Name = "listOfBooks";
            this.listOfBooks.Size = new System.Drawing.Size(120, 95);
            this.listOfBooks.TabIndex = 0;
            this.listOfBooks.SelectedIndexChanged += new System.EventHandler(this.listOfBooks_SelectedIndexChanged);
            // 
            // pageLength
            // 
            this.pageLength.Location = new System.Drawing.Point(16, 160);
            this.pageLength.Minimum = new System.Decimal(new int[] {
                                                                       1,
                                                                       0,
                                                                       0,
                                                                       0});
            this.pageLength.Name = "pageLength";
            this.pageLength.TabIndex = 1;
            this.pageLength.Value = new System.Decimal(new int[] {
                                                                     1,
                                                                     0,
                                                                     0,
                                                                     0});
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(16, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Page length";
            // 
            // titleLabel
            // 
            this.titleLabel.Location = new System.Drawing.Point(160, 8);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(100, 16);
            this.titleLabel.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "List of books";
            // 
            // pageToDisplay
            // 
            this.pageToDisplay.Location = new System.Drawing.Point(160, 160);
            this.pageToDisplay.Minimum = new System.Decimal(new int[] {
                                                                          1,
                                                                          0,
                                                                          0,
                                                                          0});
            this.pageToDisplay.Name = "pageToDisplay";
            this.pageToDisplay.TabIndex = 2;
            this.pageToDisplay.Value = new System.Decimal(new int[] {
                                                                        1,
                                                                        0,
                                                                        0,
                                                                        0});
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(160, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Page to display";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(292, 197);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.label3,
                                                                          this.label2,
                                                                          this.label1,
                                                                          this.titleLabel,
                                                                          this.page,
                                                                          this.pageToDisplay,
                                                                          this.pageLength,
                                                                          this.listOfBooks});
            this.Name = "Form1";
            this.Text = "Read Books";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pageLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pageToDisplay)).EndInit();
            this.ResumeLayout(false);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void ShowPage_Click(object sender, System.EventArgs e) {
            Book fairyTales;
            fairyTales = new Book();
            fairyTales.Text = "Once upon a time there was a bear.";
            fairyTales.PageLength = 8;
            fairyTales.Title = "Fairy Tales";
            Book cookies = new Book();
            cookies.Text = "Chocolate chip cookies are the most delicious cookies.";
            cookies.PageLength = 8;
            cookies.Title = "Cookie Recipes";
            int page = 3;
            string report;
            report = "Page " + page.ToString() + "\n"
                + fairyTales.Title + ": " + fairyTales.GetPage(page) + "\n"
                + cookies.Title + ": " + cookies.GetPage(page);
            MessageBox.Show(report);
            report = "Titles: " + fairyTales.Title + " and " + cookies.Title;
            MessageBox.Show(report);

        }

        private void Form1_Load(object sender, System.EventArgs e) {
            m_library = new Library();
            Book cookies = new Book();
            cookies.Text = 
                "Chocolate chip cookies are the most delicious cookies.";
            cookies.PageLength = 8;
            cookies.Title = "Cookies";
        
            Book fairyTales = new Book();
            fairyTales.Text = "Once upon a time there was a bear.";
            fairyTales.PageLength = 8;
            fairyTales.Title = "Fairy Tales";
        
            m_library.CheckIn(cookies);
            m_library.CheckIn(fairyTales);
        
            listOfBooks.Items.Add(cookies.Title);
            listOfBooks.Items.Add(fairyTales.Title); 
        }

        private void listOfBooks_SelectedIndexChanged(
            object sender, System.EventArgs e) {
            string title = listOfBooks.SelectedItem.ToString();
            Book theBook = m_library.CheckOut(title);
            theBook.PageLength = (int)pageLength.Value;
            titleLabel.Text = theBook.Title;
            page.Text = theBook.GetPage((int)pageToDisplay.Value);
            m_library.CheckIn(theBook);
        }



	}
}
