using System;
using System.Collections;

namespace ReadBooks
{
	/// <summary>
	/// 
	/// </summary>
	public class Library
	{
		public Library()
		{
			// 
			// TODO: Add constructor logic here
			//
		}

        private SortedList m_shelf = new SortedList();

        public void CheckIn(Book newBook) {
            m_shelf.Add(newBook.Title, newBook);
        }

        public Book CheckOut(string title) {
            Book theBook;
            theBook = (Book)m_shelf[title];
            m_shelf.Remove(title);
            return theBook;
        }


	}
}
