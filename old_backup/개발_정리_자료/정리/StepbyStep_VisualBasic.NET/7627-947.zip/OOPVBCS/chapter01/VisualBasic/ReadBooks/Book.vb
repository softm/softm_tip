Public Class Book

    Public Text As String = ""
    Public PageLength As Integer = 10
    Private m_title As String

    Public Property Title() As String
        Get
            Return m_title
        End Get
        Set(ByVal Value As String)
            m_title = Value
        End Set
    End Property

    Public Function GetPage(ByVal pageNumber As Integer) As String
        Dim start As Integer = (pageNumber - 1) * PageLength
        If (start < Text.Length) And (start >= 0) Then
            If (start + PageLength) < Text.Length Then
                Return Text.Substring(start, PageLength)
            Else
                Return Text.Substring(start, Text.Length - start)
            End If
        Else
            Return ""
        End If
    End Function


End Class
