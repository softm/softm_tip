using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CodeAnalysis
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid listOfFiles;
		private System.Windows.Forms.Button browse;
		private System.Windows.Forms.Button display;
		private System.Windows.Forms.OpenFileDialog openSourceFile;
		
		private const int MaxFiles = 10;
		private SourceFile [] m_sourceFiles = new SourceFile [MaxFiles ];
		private int m_files = 0;
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.listOfFiles = new System.Windows.Forms.DataGrid();
			this.browse = new System.Windows.Forms.Button();
			this.display = new System.Windows.Forms.Button();
			this.openSourceFile = new System.Windows.Forms.OpenFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.listOfFiles)).BeginInit();
			this.SuspendLayout();
			// 
			// listOfFiles
			// 
			this.listOfFiles.DataMember = "";
			this.listOfFiles.Location = new System.Drawing.Point(8, 8);
			this.listOfFiles.Name = "listOfFiles";
			this.listOfFiles.Size = new System.Drawing.Size(280, 216);
			this.listOfFiles.TabIndex = 0;
			// 
			// browse
			// 
			this.browse.Location = new System.Drawing.Point(8, 232);
			this.browse.Name = "browse";
			this.browse.TabIndex = 1;
			this.browse.Text = "Browse";
			this.browse.Click += new System.EventHandler(this.browse_Click);
			// 
			// display
			// 
			this.display.Location = new System.Drawing.Point(208, 232);
			this.display.Name = "display";
			this.display.TabIndex = 2;
			this.display.Text = "Display";
			this.display.Click += new System.EventHandler(this.display_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.display,
																		  this.browse,
																		  this.listOfFiles});
			this.Name = "Form1";
			this.Text = "Code Analysis";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.listOfFiles)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			listOfFiles.DataSource = m_sourceFiles;
		}

		private void browse_Click(object sender, System.EventArgs e)
		{
			try {
				openSourceFile.Filter ="Visual C#files (*.cs)|*.cs";
				System.Windows.Forms.DialogResult result;
				result =openSourceFile.ShowDialog();
				if (result ==System.Windows.Forms.DialogResult.OK){
					SourceFile aFile =new SourceFile(openSourceFile.FileName);
					m_sourceFiles [m_files++] = aFile;
					if (m_files == m_sourceFiles.Length){
						m_files = m_sourceFiles.Length -1;
					}
				}
				listOfFiles.Refresh();
			}
			catch (System.Exception ex){
				MessageBox.Show(ex.Message);
			}
		}

		private void display_Click(object sender, System.EventArgs e)
		{
			int row =listOfFiles.CurrentCell.RowNumber;
			if (row <m_files){
				SourceFile theFile =m_sourceFiles [row ];
				string message = "";
				for (int index = 0; index <theFile.ClassCount; index++){
					message +=theFile.GetClass(index)+ "\n";
				}

				MessageBox.Show(message,"Classes in " + theFile.FileName);
			}
			else {
				MessageBox.Show("Please select a row with data.");
			}
		}
	}
}
