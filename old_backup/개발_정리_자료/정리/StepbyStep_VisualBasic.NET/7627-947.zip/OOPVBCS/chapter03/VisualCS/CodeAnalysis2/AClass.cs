using System;

namespace CodeAnalysis2
{
	/// <summary>
	/// Summary description for AClass.
	/// </summary>
	public class AClass
	{

		string m_name;
		public string Name 
		{
			get {return m_name;}
		}

		string m_filename;
		public string FileName 
		{
			get {return m_filename;}
		}

		public AClass(string name,string filename)
		{
			m_name = name;
			m_filename = filename;
		}
	}
}
