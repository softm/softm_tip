using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace CodeAnalysis2
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid listOfFiles;
		private System.Windows.Forms.Button browse;
		private System.Windows.Forms.Label linesOfCode;
		private System.Windows.Forms.OpenFileDialog openSourceFile;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private Classes m_classes = new Classes();

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.listOfFiles = new System.Windows.Forms.DataGrid();
			this.browse = new System.Windows.Forms.Button();
			this.linesOfCode = new System.Windows.Forms.Label();
			this.openSourceFile = new System.Windows.Forms.OpenFileDialog();
			((System.ComponentModel.ISupportInitialize)(this.listOfFiles)).BeginInit();
			this.SuspendLayout();
			// 
			// listOfFiles
			// 
			this.listOfFiles.DataMember = "";
			this.listOfFiles.Location = new System.Drawing.Point(8, 8);
			this.listOfFiles.Name = "listOfFiles";
			this.listOfFiles.Size = new System.Drawing.Size(280, 216);
			this.listOfFiles.TabIndex = 0;
			// 
			// browse
			// 
			this.browse.Location = new System.Drawing.Point(16, 232);
			this.browse.Name = "browse";
			this.browse.TabIndex = 1;
			this.browse.Text = "Browse";
			this.browse.Click += new System.EventHandler(this.browse_Click);
			// 
			// linesOfCode
			// 
			this.linesOfCode.Location = new System.Drawing.Point(104, 232);
			this.linesOfCode.Name = "linesOfCode";
			this.linesOfCode.Size = new System.Drawing.Size(184, 23);
			this.linesOfCode.TabIndex = 2;
			this.linesOfCode.Text = "Lines of code";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.linesOfCode,
																		  this.browse,
																		  this.listOfFiles});
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.listOfFiles)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void DisplayClasses()
		{
			AClass [] classes = new AClass [m_classes.Count];
			for (int i =0; i < m_classes.Count; i++)
			{
				//Using the indexer
				classes [i ] = m_classes [i ];
			}
			this.listOfFiles.DataSource =classes;
			linesOfCode.Text =
				"Lines of code:" + m_classes.LinesOfCode.ToString();
		}

		private void browse_Click(object sender, System.EventArgs e)
		{
			try 
			{
				openSourceFile.Filter = "Visual C#files (*.cs)|*.cs";
				System.Windows.Forms.DialogResult result;
				result = openSourceFile.ShowDialog();
				if (result == System.Windows.Forms.DialogResult.OK)
				{
					m_classes.ReadFromFile(openSourceFile.FileName);
				}
				DisplayClasses();
			}
			catch (System.Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
	}
}
