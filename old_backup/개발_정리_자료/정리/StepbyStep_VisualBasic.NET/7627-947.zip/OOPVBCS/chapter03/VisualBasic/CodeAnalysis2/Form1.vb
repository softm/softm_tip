Public Class Form1
    Inherits System.Windows.Forms.Form
    Private m_classes As New Classes()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents listOfFiles As System.Windows.Forms.DataGrid
    Friend WithEvents browse As System.Windows.Forms.Button
    Friend WithEvents linesOfCode As System.Windows.Forms.Label
    Friend WithEvents openSourceFile As System.Windows.Forms.OpenFileDialog

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.listOfFiles = New System.Windows.Forms.DataGrid()
        Me.browse = New System.Windows.Forms.Button()
        Me.linesOfCode = New System.Windows.Forms.Label()
        Me.openSourceFile = New System.Windows.Forms.OpenFileDialog()
        CType(Me.listOfFiles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'listOfFiles
        '
        Me.listOfFiles.DataMember = ""
        Me.listOfFiles.Location = New System.Drawing.Point(8, 8)
        Me.listOfFiles.Name = "listOfFiles"
        Me.listOfFiles.Size = New System.Drawing.Size(280, 216)
        Me.listOfFiles.TabIndex = 0
        '
        'browse
        '
        Me.browse.Location = New System.Drawing.Point(8, 232)
        Me.browse.Name = "browse"
        Me.browse.TabIndex = 1
        Me.browse.Text = "Browse"
        '
        'linesOfCode
        '
        Me.linesOfCode.Location = New System.Drawing.Point(96, 232)
        Me.linesOfCode.Name = "linesOfCode"
        Me.linesOfCode.Size = New System.Drawing.Size(192, 23)
        Me.linesOfCode.TabIndex = 2
        Me.linesOfCode.Text = "Lines of code"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.linesOfCode, Me.browse, Me.listOfFiles})
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.listOfFiles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private Sub DisplayClasses()

        Dim classes(m_classes.Count) As AClass
        Dim i As Integer
        For i = 0 To m_classes.Count - 1
            ' Using the default property
            classes(i) = m_classes(i)
        Next
        listOfFiles.DataSource = classes
        linesOfCode.Text = _
            "Lines of code:" & m_classes.LinesOfCode.ToString()
    End Sub

    Private Sub browse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles browse.Click
        Try
            openSourceFile.Filter = "Visual Basic files (*.vb)|*.vb"
            Dim result As System.Windows.Forms.DialogResult
            ' If user selected a file,then create a SourceFile from it.
            result = openSourceFile.ShowDialog()
            If (result = DialogResult.OK) Then
                m_classes.ReadFromFile(openSourceFile.FileName)
            End If
            DisplayClasses()
        Catch ex As System.Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
