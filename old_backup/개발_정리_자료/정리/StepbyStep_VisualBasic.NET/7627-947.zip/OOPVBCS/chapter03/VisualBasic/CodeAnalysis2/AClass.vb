Public Class AClass
    Private m_name As String
    Public ReadOnly Property Name() As String
        Get
            Return m_name
        End Get
    End Property

    Private m_filename As String
    Public ReadOnly Property FileName() As String
        Get
            Return m_filename
        End Get
    End Property

    Public Sub New(ByVal name As String, ByVal filename As String)
        m_name = name
        m_filename = filename
    End Sub

End Class
