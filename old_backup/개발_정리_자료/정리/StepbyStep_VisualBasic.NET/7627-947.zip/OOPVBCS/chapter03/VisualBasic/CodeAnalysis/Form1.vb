Public Class Form1
    Inherits System.Windows.Forms.Form

    Private Const MaxFiles As Integer = 10
    Private m_sourceFiles(MaxFiles) As SourceFile
    Private m_files As Integer = 0

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents listOfFiles As System.Windows.Forms.DataGrid
    Friend WithEvents browse As System.Windows.Forms.Button
    Friend WithEvents display As System.Windows.Forms.Button
    Friend WithEvents openSourceFile As System.Windows.Forms.OpenFileDialog

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.openSourceFile = New System.Windows.Forms.OpenFileDialog()
        Me.display = New System.Windows.Forms.Button()
        Me.browse = New System.Windows.Forms.Button()
        Me.listOfFiles = New System.Windows.Forms.DataGrid()
        CType(Me.listOfFiles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'display
        '
        Me.display.Location = New System.Drawing.Point(208, 232)
        Me.display.Name = "display"
        Me.display.TabIndex = 2
        Me.display.Text = "Display"
        '
        'browse
        '
        Me.browse.Location = New System.Drawing.Point(8, 232)
        Me.browse.Name = "browse"
        Me.browse.TabIndex = 1
        Me.browse.Text = "Browse"
        '
        'listOfFiles
        '
        Me.listOfFiles.DataMember = ""
        Me.listOfFiles.Location = New System.Drawing.Point(8, 8)
        Me.listOfFiles.Name = "listOfFiles"
        Me.listOfFiles.Size = New System.Drawing.Size(280, 216)
        Me.listOfFiles.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.display, Me.browse, Me.listOfFiles})
        Me.Name = "Form1"
        Me.Text = "Code Analysis"
        CType(Me.listOfFiles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region



    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        listOfFiles.DataSource = m_sourceFiles
    End Sub

    Private Sub browse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles browse.Click
        Try
            openSourceFile.Filter = "Visual Basic files (*.vb)|*.vb"
            Dim result As System.Windows.Forms.DialogResult
            result = openSourceFile.ShowDialog()
            If (result = DialogResult.OK) Then
                Dim aFile As New SourceFile(openSourceFile.FileName)
                m_sourceFiles(m_files) = aFile
                m_files += 1
                If (m_files = m_sourceFiles.Length) Then
                    m_files = m_sourceFiles.Length - 1
                End If
            End If
            listOfFiles.Refresh()
        Catch ex As System.Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub display_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles display.Click
        Dim row As Integer = listOfFiles.CurrentCell.RowNumber
        If row < m_files Then
            Dim theFile As SourceFile = m_sourceFiles(row)
            Dim message As String = ""
            Dim index As Integer
            For index = 0 To theFile.ClassCount - 1
                message &= theFile.Classes(index) & ControlChars.CrLf
            Next
            MessageBox.Show(message, "Classes in " & theFile.FileName)
        Else
            MessageBox.Show("Please select a row with data.")
        End If
    End Sub
End Class
