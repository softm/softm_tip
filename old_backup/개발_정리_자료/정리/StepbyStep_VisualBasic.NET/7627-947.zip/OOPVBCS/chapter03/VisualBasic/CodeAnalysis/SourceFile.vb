Public Class SourceFile
    Private m_fullPath As String
    Private m_linesOfCode As Integer
    Private m_classNames() As String
    Private m_classCount As Integer

    Public ReadOnly Property FullPath() As String
        Get
            Return m_fullPath
        End Get
    End Property

    Public ReadOnly Property FileName() As String
        Get
            Dim lastSlash As Integer
            lastSlash = m_fullPath.LastIndexOf("\")
            Return m_fullPath.Substring(lastSlash + 1)
        End Get
    End Property

    Public ReadOnly Property ClassCount() As Integer
        Get
            Return m_classCount
        End Get
    End Property

    Public ReadOnly Property LinesOfCode() As Integer
        Get
            Return m_linesOfCode
        End Get
    End Property

    Public Property Classes(ByVal index As Integer) As String
        Get
            If index < m_classCount Then
                Return m_classNames(index)
            Else
                Throw New System.IndexOutOfRangeException( _
                "There are only " & m_classCount & " classes defined..")
            End If
        End Get

        Set(ByVal Value As String)
            If index < m_classCount Then
                m_classNames(index) = Value
            Else
                Throw New System.IndexOutOfRangeException( _
                "There are only " & m_classCount & " classes defined..")
            End If
        End Set
    End Property





    Public Sub New(ByVal fullPath As String)
        m_classCount = 0
        m_linesOfCode = 0
        m_fullPath = fullPath
        m_classNames = New String(10) {}
        Try
            Dim reader As New System.IO.StreamReader(m_fullPath)
            Dim nameStart As Integer
            Dim oneline As String
            oneline = reader.ReadLine()
            While (Not (oneline Is Nothing))
                oneline = oneline.Trim()
                ' Don �t count blank lines and comment lines.
                If ((oneline <> "") And (Not oneline.StartsWith("�"))) Then
                    m_linesOfCode += 1
                End If
                If (oneline.StartsWith("Public Class ")) Then
                    nameStart = oneline.IndexOf("Class ") + 6
                    Dim names() As String
                    Dim separators() As Char = {ControlChars.Tab, " "c}
                    names = oneline.Substring( _
                    nameStart).Trim().Split(separators)
                    Dim className As String = names(0).Trim()
                    m_classNames(m_classCount) = className
                    m_classCount += 1
                End If
                oneline = reader.ReadLine()
            End While
            reader.Close()
        Catch ex As System.Exception
            Throw New System.Exception( _
            "Problems parsing source file:" + +ex.Message)
        End Try
    End Sub
End Class
