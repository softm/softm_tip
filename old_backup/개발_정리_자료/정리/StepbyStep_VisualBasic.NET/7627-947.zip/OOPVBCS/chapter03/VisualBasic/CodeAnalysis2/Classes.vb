Public Class Classes
    Private m_linesOfCode As Integer = 0
    Private m_classNames As New System.Collections.ArrayList()

    Public Sub ReadFromFile(ByVal fullPath As String)
        Try
            Dim reader As New System.IO.StreamReader(fullPath)
            Dim nameStart As Integer
            Dim oneline As String
            oneline = reader.ReadLine()
            While (Not (oneline Is Nothing))
                oneline = oneline.Trim()
                If ((oneline <> "") And (Not oneline.StartsWith("�"))) Then
                    m_linesOfCode += 1
                End If
                If (oneline.StartsWith("Public Class ")) Then
                    nameStart = oneline.IndexOf("Class ") + 6
                    Dim names() As String
                    Dim separators() As Char = {ControlChars.Tab, " "c}
                    names = oneline.Substring( _
                    nameStart).Trim().Split(separators)
                    Dim className As String = names(0).Trim()
                    m_classNames.Add(New AClass(className, fullPath))
                End If
                oneline = reader.ReadLine()
            End While
            reader.Close()
        Catch ex As System.Exception
            Throw New System.Exception( _
            "Problems parsing source file:" + +ex.Message)
        End Try
    End Sub


    Default Public ReadOnly Property Classes(ByVal index As Integer) As AClass
        Get
            If (index >= 0) And (index < m_classNames.Count) Then
                Return CType(m_classNames(index), AClass)
            Else
                Throw New System.IndexOutOfRangeException( _
                "Index must be between 0 and " & _
                m_classNames.Count.ToString() & ".")
            End If
        End Get
        '   Set(ByVal Value As AClass)
        '       If (index >=0)And (index <m_classNames.Count)Then
        '           m_classNames(index)=Value
        '       Else
        '           Throw New System.IndexOutOfRangeException(_
        '           "Index must be between 0 and " & _
        '           m_classNames.Count.ToString()&".")
        '       End If
        '   End Set
    End Property

    Public ReadOnly Property LinesOfCode() As Integer
        Get
            Return m_linesOfCode
        End Get
    End Property

    Public ReadOnly Property Count() As Integer
        Get
            Return m_classNames.Count
        End Get
    End Property

End Class
