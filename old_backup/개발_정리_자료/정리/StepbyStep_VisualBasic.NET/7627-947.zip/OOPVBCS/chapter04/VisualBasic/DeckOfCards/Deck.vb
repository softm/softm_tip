Public Class Deck
    Private m_cards As New System.Collections.ArrayList()
    Public ReadOnly Property Count() As Integer
        Get
            Return m_cards.Count
        End Get
    End Property

    Default Public ReadOnly Property Cards(ByVal indexer As Integer) As Card
        Get
            If ((indexer >= 0) And (indexer < m_cards.Count)) Then
                Return CType(m_cards(indexer), Card)
            Else
                Throw New ArgumentOutOfRangeException("Index out of range.")
            End If
        End Get
    End Property

    Private Sub MakeDeck(ByVal suits() As Suit, ByVal values() As FaceValue)
        Dim aSuit, aValue As Integer
        Dim newValue As FaceValue
        Dim newSuit As Suit
        Dim newCard As Card
        For aSuit = 0 To suits.Length - 1
            For aValue = 0 To values.Length - 1
                newSuit = suits(aSuit) ' Select a suit..
                newValue = values(aValue) ' Select a value..
                newCard = New Card(newSuit, newValue) ' Create a card..
                m_cards.Add(newcard) ' Add the card..
                ' You can replace the four preceding lines with this:
                ' m_cards.Add(New Card(suits(aSuit),values(aValue)))
            Next
        Next
    End Sub

    Public Sub New()
        Dim suits() As Suit = {Suit.Clubs, Suit.Diamonds, Suit.Hearts, _
        Suit.Spades}
        Dim values() As FaceValue = {FaceValue.Ace, FaceValue.Two, _
        FaceValue.Three, FaceValue.Four, FaceValue.Five, _
        FaceValue.Six, FaceValue.Seven, FaceValue.Eight, _
        FaceValue.Nine, FaceValue.Ten, FaceValue.Jack, _
        FaceValue.Queen, FaceValue.King}
        Me.MakeDeck(suits, values)
    End Sub

    Public Sub New(ByVal suits() As Suit, ByVal values() As FaceValue)
        Me.MakeDeck(suits, values)
    End Sub

    Public Sub Shuffle()
        Dim rGen As New System.Random()
        Dim newDeck As New System.Collections.ArrayList()
        While (m_cards.Count > 0)
            ' Choose one card at random to remove.
            Dim removeIndex As Integer = rGen.Next(0, m_cards.Count - 1)
            Dim removeObject As Object = m_cards(removeIndex)
            m_cards.RemoveAt(removeIndex)
            ' Add the removed card to the new deck.
            newDeck.Add(removeObject)
        End While
        ' replace the old deck with the new deck
        m_cards = newDeck
    End Sub

    ' The deck is empty after dealing the cards..
    Public Sub Deal(ByVal hands() As Hand)
        Dim handIndex As Integer = 0
        While (m_cards.Count > 0)
            hands(handIndex).Add(CType(m_cards(0), Card))
            m_cards.RemoveAt(0)
            handIndex += 1
            If handIndex = hands.Length Then
                handIndex = 0
            End If
        End While
    End Sub

    Public Function Draw() As Card
        Dim topCard As Card = Nothing
        If m_cards.Count > 0 Then
            topCard = CType(m_cards(0), Card)
            m_cards.RemoveAt(0)
        End If
        Return topCard
    End Function

End Class
