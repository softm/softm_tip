Public Class Form1
    Inherits System.Windows.Forms.Form

    Private m_icons As New System.Collections.SortedList()
    Private m_hand1 As New Hand()
    Private m_hand2 As New Hand()
    Private m_pickedUp As Button
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents removePairs As System.Windows.Forms.Button
    Friend WithEvents newGame As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.removePairs = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.newGame = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'removePairs
        '
        Me.removePairs.Location = New System.Drawing.Point(96, 224)
        Me.removePairs.Name = "removePairs"
        Me.removePairs.Size = New System.Drawing.Size(96, 23)
        Me.removePairs.TabIndex = 2
        Me.removePairs.Text = "Remove pairs"
        '
        'Panel1
        '
        Me.Panel1.AllowDrop = True
        Me.Panel1.AutoScroll = True
        Me.Panel1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel1.Location = New System.Drawing.Point(16, 32)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(120, 184)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.AllowDrop = True
        Me.Panel2.AutoScroll = True
        Me.Panel2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel2.Location = New System.Drawing.Point(160, 32)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(120, 184)
        Me.Panel2.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Player 1"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(160, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Player 2"
        '
        'newGame
        '
        Me.newGame.Location = New System.Drawing.Point(96, 256)
        Me.newGame.Name = "newGame"
        Me.newGame.Size = New System.Drawing.Size(96, 23)
        Me.newGame.TabIndex = 3
        Me.newGame.Text = "New game"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 286)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.newGame, Me.removePairs, Me.Panel1, Me.Label1, Me.Label2, Me.Panel2})
        Me.Name = "Form1"
        Me.Text = "Deck of Cards"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        m_icons.Add(Suit.Clubs, Image.FromFile("\OOPVBCS\Chapter04\Clubs.ico"))
        m_icons.Add(Suit.Diamonds, Image.FromFile("\OOPVBCS\Chapter04\Diamonds.ico"))
        m_icons.Add(Suit.Hearts, Image.FromFile("\OOPVBCS\Chapter04\Hearts.ico"))
        m_icons.Add(Suit.Spades, Image.FromFile("\OOPVBCS\Chapter04\Spades.ico"))
        SetUp()
    End Sub

    Private Sub newGame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles newGame.Click
        SetUp()
    End Sub

    Private Sub SetUp()
        Dim suits() As Suit = New Suit() {Suit.Diamonds, Suit.Clubs}
        Dim values() As FaceValue = New FaceValue() {FaceValue.King, _
            FaceValue.Queen, FaceValue.Jack, FaceValue.Ten}
        Dim aDeck As New Deck(suits, values)
        aDeck.Shuffle()
        m_hand1 = New Hand()
        m_hand2 = New Hand()
        aDeck.Deal(New Hand() {m_hand1, m_hand2})
        ShowHand(Panel1, m_hand1)
        ShowHand(Panel2, m_hand2)
    End Sub

    Private Sub ShowHand(ByVal aPanel As Panel, ByVal aHand As Hand)
        aPanel.Controls.Clear()
        Dim aCard As Card
        Dim aButton As Button
        Dim i As Integer
        For i = 0 To aHand.Count - 1
            aCard = aHand(i)
            ' Make the button and add it to the form.
            aButton = New Button()
            aPanel.Controls.Add(aButton)
            With aButton
                ' Modify the appearance of the button.
                .Image = CType(m_icons(aCard.Suit), Image)
                .Text = aCard.FaceValue.ToString()
                .TextAlign = ContentAlignment.BottomCenter
                .ImageAlign = ContentAlignment.TopCenter
                .FlatStyle = FlatStyle.Flat
                .Height = 40
                ' Locate the button on the panel.
                .Top = 45 * i
                ' Save the associated card.
                .Tag = aCard
            End With
            ' Add a MouseDown event to the new button.
            AddHandler aButton.MouseDown, AddressOf ButtonMouseDown
        Next
    End Sub

    Private Sub ButtonMouseDown(ByVal sender As Object, _
    ByVal e As System.Windows.Forms.MouseEventArgs)
        m_pickedUp = CType(sender, Button)
        m_pickedUp.DoDragDrop(sender, DragDropEffects.Move)
    End Sub

    Private Sub panel1_DragEnter(ByVal sender As Object, ByVal e _
    As System.Windows.Forms.DragEventArgs) Handles Panel1.DragEnter
        e.Effect = DragDropEffects.Move
    End Sub

    Private Sub panel2_DragEnter(ByVal sender As Object, ByVal e _
    As System.Windows.Forms.DragEventArgs) Handles Panel2.DragEnter
        e.Effect = DragDropEffects.Move
    End Sub

    Private Sub panel1_DragDrop(ByVal sender As Object, ByVal e _
    As System.Windows.Forms.DragEventArgs) Handles Panel1.DragDrop
        Dim theCard As Card = CType(m_pickedUp.Tag, Card)
        If (Not m_hand1.Contains(theCard)) Then
            m_hand1.Add(theCard)
            m_hand2.Remove(theCard)
        End If
        ShowHand(Panel1, m_hand1)
        ShowHand(Panel2, m_hand2)
        m_pickedUp = Nothing
    End Sub
    Private Sub panel2_DragDrop(ByVal sender As Object, ByVal e _
    As System.Windows.Forms.DragEventArgs) Handles Panel2.DragDrop
        Dim theCard As Card = CType(m_pickedUp.Tag, Card)
        If (Not m_hand2.Contains(theCard)) Then
            m_hand2.Add(theCard)
            m_hand1.Remove(theCard)
        End If
        ShowHand(Panel1, m_hand1)
        ShowHand(Panel2, m_hand2)
        m_pickedUp = Nothing
    End Sub

    Private Sub removePairs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles removePairs.Click
        m_hand1.RemovePairs()
        m_hand2.RemovePairs()
        ShowHand(Panel2, m_hand2)
        ShowHand(Panel1, m_hand1)
    End Sub

    
End Class
