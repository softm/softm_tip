Public Enum Suit
    Hearts
    Diamonds
    Clubs
    Spades
End Enum

Public Enum FaceValue
    Ace
    One
    Two
    Three
    Four
    Five
    Six
    Seven
    Eight
    Nine
    Ten
    Jack
    Queen
    King
End Enum

Public Class Card
    Private m_suit As Suit
    Public Property Suit() As Suit
        Get
            Return m_suit
        End Get
        Set(ByVal Value As Suit)
            m_suit = Value
        End Set
    End Property

    Private m_faceValue As FaceValue
    Public Property FaceValue() As FaceValue
        Get
            Return m_faceValue
        End Get
        Set(ByVal Value As FaceValue)
            m_faceValue = Value
        End Set
    End Property

    Public Sub New(ByVal newSuit As Suit, ByVal newValue As FaceValue)
        m_suit = newSuit
        m_faceValue = newValue
    End Sub


End Class
