Public Class Hand
    Private m_cards As New System.Collections.ArrayList()

    Public Sub New()
    End Sub

    Public Sub New(ByVal cards() As Card)
        m_cards.AddRange(cards)
    End Sub

    Public ReadOnly Property Count() As Integer
        Get
            Return m_cards.Count
        End Get
    End Property

    Default Public ReadOnly Property Cards(ByVal indexer As Integer) As Card
        Get
            Return CType(m_cards(indexer), Card)
        End Get
    End Property

    Public Sub Add(ByVal newCard As Card)
        m_cards.Add(newCard)
    End Sub

    Public Function Contains(ByVal cardToFind As Card) As Boolean
        Return m_cards.Contains(cardToFind)
    End Function


    Public Function Contains(ByVal suitToFind As Suit, _
    ByVal valueToFind As FaceValue) As Boolean
        Dim found As Boolean = False
        Dim aCard As Card
        Dim i As Integer
        For i = 0 To m_cards.Count - 1
            aCard = CType(m_cards(i), Card)
            If ((aCard.Suit = suitToFind) And _
            (aCard.FaceValue = valueToFind)) Then
                found = True
            End If
        Next
        Return found
    End Function

    Public Sub Remove(ByVal cardToRemove As Card)
        If (m_cards.Contains(cardToRemove)) Then
            m_cards.Remove(cardToRemove)
        End If
    End Sub
    Public Sub Remove(ByVal suitToRemove As Suit, _
    ByVal valueToRemove As FaceValue)
        Dim aCard As Card
        Dim i As Integer
        For i = 0 To m_cards.Count - 1
            aCard = CType(m_cards(i), Card)
            If ((aCard.Suit = suitToRemove) And _
            (aCard.FaceValue = valueToRemove)) Then
                m_cards.Remove(aCard)
                Exit For
            End If
        Next
    End Sub

    Public Sub RemovePairs()
        Dim findMatch, possibleMatch As Card
        Dim found As Boolean
        Dim noMatches As New System.Collections.ArrayList()
        Dim i As Integer
        While (m_cards.Count > 0)
            findMatch = CType(m_cards(0), Card)
            found = False
            For i = 1 To m_cards.Count - 1
                possibleMatch = CType(m_cards(i), Card)
                If (possibleMatch.FaceValue = findMatch.FaceValue) Then
                    found = True
                    m_cards.Remove(findMatch)
                    m_cards.Remove(possibleMatch)
                    Exit For
                End If
            Next
            If Not found Then
                noMatches.Add(findMatch)
                m_cards.Remove(findMatch)
            End If
        End While
        m_cards = noMatches
    End Sub

    Public Shared Sub Main()
        Console.WriteLine("Visual Basic Hand Test ")
        Dim queenOfHearts As New Card(Suit.Hearts, FaceValue.Queen)
        Dim twoOfClubs As New Card(Suit.Clubs, FaceValue.Two)
        ' Test:Add(Card [])
        Dim aHand As New Hand(New Card() {queenOfHearts, twoOfClubs})
        ' Test:Contains(Card)Expect:True
        Console.WriteLine( _
        "Hand contains queenOfHearts:{0}.", _
        aHand.Contains(queenOfHearts))
        ' Test:Contains(Suit,Value)Expect:True
        Console.WriteLine("Hand contains Queeen of Hearts:{0}.", _
            aHand.Contains(Suit.Hearts, FaceValue.Queen))
        ' Test:Contains(Card)Expect:False
        Console.WriteLine("Hand contains new queenOfHearts:{0}.", _
            aHand.Contains(New Card(Suit.Hearts, FaceValue.Queen)))
        aHand.Remove(queenOfHearts)
        ' Test:Remove(Card)Expect:False
        Console.WriteLine("Hand contains Queeen of Hearts:{0}.", _
            aHand.Contains(Suit.Hearts, FaceValue.Queen))
        Dim pair As New Hand()
        ' Test:Add(Suit,Value)
        pair.Add(New Card(Suit.Diamonds, FaceValue.Ace))
        pair.Add(New Card(Suit.Clubs, FaceValue.Ace))
        ' Test:Count Expect:2 cards
        Console.WriteLine("Pair has {0}cards.", pair.Count)
        pair.RemovePairs()
        ' Test:Remove Pairs Expect:0 cards
        Console.WriteLine("After RemovePairs,Pair has {0}cards.", pair.Count)
    End Sub


End Class
