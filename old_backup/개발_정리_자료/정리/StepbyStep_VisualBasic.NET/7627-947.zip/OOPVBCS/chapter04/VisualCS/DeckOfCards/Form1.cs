using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DeckOfCards
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Collections.SortedList m_icons = new 
			System.Collections.SortedList();
		private Hand m_hand1 = new Hand();
		private Hand m_hand2 = new Hand();   
		private Button m_pickedup;


        
        
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button removePairs;
        private System.Windows.Forms.Button newGame;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.removePairs = new System.Windows.Forms.Button();
            this.newGame = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AllowDrop = true;
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(128)), ((System.Byte)(128)));
            this.panel1.Location = new System.Drawing.Point(16, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(184, 200);
            this.panel1.TabIndex = 0;
            this.panel1.DragEnter += new System.Windows.Forms.DragEventHandler(this.panel1_DragEnter);
            this.panel1.DragDrop += new System.Windows.Forms.DragEventHandler(this.panel1_DragDrop);
            // 
            // panel2
            // 
            this.panel2.AllowDrop = true;
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(128)), ((System.Byte)(128)), ((System.Byte)(255)));
            this.panel2.Location = new System.Drawing.Point(232, 40);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(184, 200);
            this.panel2.TabIndex = 0;
            this.panel2.DragEnter += new System.Windows.Forms.DragEventHandler(this.panel2_DragEnter);
            this.panel2.DragDrop += new System.Windows.Forms.DragEventHandler(this.panel2_DragDrop);
            // 
            // removePairs
            // 
            this.removePairs.Location = new System.Drawing.Point(152, 264);
            this.removePairs.Name = "removePairs";
            this.removePairs.Size = new System.Drawing.Size(120, 23);
            this.removePairs.TabIndex = 1;
            this.removePairs.Text = "Remove pairs";
            this.removePairs.Click += new System.EventHandler(this.removePairs_Click);
            // 
            // newGame
            // 
            this.newGame.Location = new System.Drawing.Point(152, 304);
            this.newGame.Name = "newGame";
            this.newGame.Size = new System.Drawing.Size(120, 23);
            this.newGame.TabIndex = 2;
            this.newGame.Text = "New game";
            this.newGame.Click += new System.EventHandler(this.newGame_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 8);
            this.label1.Name = "label1";
            this.label1.TabIndex = 3;
            this.label1.Text = "Player 1";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(232, 8);
            this.label2.Name = "label2";
            this.label2.TabIndex = 4;
            this.label2.Text = "Player 2";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(440, 349);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.label2,
                                                                          this.label1,
                                                                          this.newGame,
                                                                          this.removePairs,
                                                                          this.panel1,
                                                                          this.panel2});
            this.Name = "Form1";
            this.Text = "Deck of Cards";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

        private void Form1_Load(object sender, System.EventArgs e) {
			m_icons.Add(Suit.Clubs,Image.FromFile(@"\OOPVBCS\Chapter04\Clubs.ico"));
			m_icons.Add(Suit.Diamonds,Image.FromFile(@"\OOPVBCS\Chapter04\Diamonds.ico"));
			m_icons.Add(Suit.Hearts,Image.FromFile(@"\OOPVBCS\Chapter04\Hearts.ico"));
			m_icons.Add(Suit.Spades,Image.FromFile(@"\OOPVBCS\Chapter04\Spades.ico"));
			SetUp();
        }

        private void newGame_Click(object sender, System.EventArgs e) {
            SetUp();
        }


        private void SetUp() {
			Deck adeck = new Deck(
				new Suit[] { Suit.Diamonds, Suit.Clubs }, 
				new FaceValue[] { FaceValue.King, FaceValue.Queen, 
									FaceValue.Jack, FaceValue.Ten });
			adeck.Shuffle();
			m_hand1 = new Hand();
			m_hand2 = new Hand();
			adeck.Deal(new Hand[] { m_hand1, m_hand2 });
			ShowHand(panel1, m_hand1);
			ShowHand(panel2, m_hand2);
        }


        private void ShowHand(Panel panel, Hand hand) {
			panel.Controls.Clear();
			Card card;
			Button button;
			for (int i = 0; i < hand.Count; i++) {
				card = hand[i];
        
				// Make the button and add it to the form.
				button = new Button();
				panel.Controls.Add(button);
        
				//Modify the appearance.
				button.Image = (Image)m_icons[card.Suit];
				button.Text = card.FaceValue.ToString();
				button.TextAlign = ContentAlignment.BottomCenter;
				button.ImageAlign = ContentAlignment.TopCenter;
				button.FlatStyle = FlatStyle.Flat;
				button.Height = 40;

				// Locate the button on the panel.
				button.Top = 45 * i;
				// Save the associated card.
				button.Tag = card;
				// Add a MouseDown event to the new button.
				button.MouseDown += new
					System.Windows.Forms.MouseEventHandler(buttonMouseDown);
			}
        }

        private void buttonMouseDown(object sender, 
            System.Windows.Forms.MouseEventArgs e) {
            m_pickedup = (Button)sender;
            ((Button)sender).DoDragDrop(sender,DragDropEffects.Move);
        }

        private void panel1_DragEnter(object sender, System.Windows.Forms.DragEventArgs e) {
            e.Effect = DragDropEffects.Move;
        }

        private void panel2_DragEnter(object sender, System.Windows.Forms.DragEventArgs e) {
            e.Effect = DragDropEffects.Move;
        }

        private void panel1_DragDrop(object sender, System.Windows.Forms.DragEventArgs e) {
			Card theCard = (Card)m_pickedup.Tag;
			if (!m_hand1.Contains(theCard)) {
				m_hand1.Add(theCard);
				m_hand2.Remove(theCard);
			}
			ShowHand(panel2, m_hand2);
			ShowHand(panel1, m_hand1);
			m_pickedup = null;
        }

        private void panel2_DragDrop(object sender, System.Windows.Forms.DragEventArgs e) {
			Card theCard = (Card) m_pickedup.Tag;
			if (!m_hand2.Contains(theCard)) {
				m_hand2.Add(theCard);
				m_hand1.Remove(theCard);
			}
			ShowHand(panel2, m_hand2);
			ShowHand(panel1, m_hand1);
			m_pickedup = null;
        }

        private void removePairs_Click(object sender, System.EventArgs e) {
			m_hand1.RemovePairs();
			m_hand2.RemovePairs();
			ShowHand(panel2, m_hand2);
			ShowHand(panel1, m_hand1);
        }



	}
}
