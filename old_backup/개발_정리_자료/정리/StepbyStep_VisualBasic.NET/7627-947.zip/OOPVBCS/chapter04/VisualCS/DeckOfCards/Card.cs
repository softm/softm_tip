using System;

namespace DeckOfCards
{

	public enum Suit 
	{
		Hearts,
		Diamonds,
		Spades,
		Clubs,
	}
	
	public enum FaceValue 
	{
		Ace,Two,Three,Four,Five,Six,Seven,
		Eight,Nine,Ten,Jack,Queen,King
	}

	/// <summary>
	/// Summary description for Card.
	/// </summary>
	public class Card
	{
		public Card()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		private Suit m_suit;
		public Suit Suit 
		{
			get {return m_suit;}
			set {m_suit =value;}
		}

		private FaceValue m_faceValue;
		public FaceValue FaceValue 
		{
			get {return m_faceValue;}
			set {m_faceValue =value;}
		}

		public Card(Suit newSuit,FaceValue newValue)
		{
			m_suit =newSuit;
			m_faceValue =newValue;
		}

	}
}
