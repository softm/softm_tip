Public Class SavingsAccount
    Inherits BankAccount

    Public Overrides ReadOnly Property ID() As String
        Get
            Return Me.m_owner & "-S"
        End Get
    End Property

    Public Sub New(ByVal owner As String)
        MyBase.New(owner)
    End Sub

    Private m_interest As Decimal = 0.01D
    Public Property Interest() As Decimal
        Get
            Return m_interest
        End Get
        Set(ByVal Value As Decimal)
            m_interest = Value
        End Set
    End Property

    Public Function AddInterest() As Decimal
        Me.Deposit(m_interest * Me.Balance)
        Return Me.Balance
    End Function


End Class
