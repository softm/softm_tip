Public Class CheckingAccount
    Inherits BankAccount
    Public Sub New(ByVal owner As String)
        MyBase.New(owner)
    End Sub

    Public Overrides Function Withdraw(ByVal amount As Decimal) As Decimal
        MyBase.Withdraw(amount)
        MyBase.Withdraw(0.25D)
        Return Me.Balance
    End Function

    Public Overrides ReadOnly Property ID() As String
        Get
            Return Me.m_owner & "-C"
        End Get
    End Property


End Class
