Public Class BankAccount
    Protected m_owner As String
    Public Overridable ReadOnly Property ID() As String
        Get
            Return m_owner
        End Get
    End Property

    Private m_balance As Decimal
    Public ReadOnly Property Balance() As Decimal
        Get
            Return m_balance
        End Get
    End Property

    Public Sub New(ByVal owner As String)
        m_owner = owner
        m_balance = 0D
    End Sub

    Public Function Deposit(ByVal amount As Decimal) As Decimal
        m_balance += amount
        Return m_balance
    End Function

    Public Overridable Function Withdraw(ByVal amount As Decimal) As Decimal
        m_balance -= amount
        Return m_balance
    End Function


End Class
