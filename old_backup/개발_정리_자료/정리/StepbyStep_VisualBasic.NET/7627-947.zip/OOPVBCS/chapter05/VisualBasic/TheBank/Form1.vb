Public Class Form1
    Inherits System.Windows.Forms.Form
    Private checking As New CheckingAccount("Your Name")
    Friend WithEvents addInterest As System.Windows.Forms.Button
    Private savings As New SavingsAccount("Your Name")

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents account As System.Windows.Forms.ComboBox
    Friend WithEvents action As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents amount As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents submit As System.Windows.Forms.Button

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.account = New System.Windows.Forms.ComboBox()
        Me.submit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.action = New System.Windows.Forms.ComboBox()
        Me.amount = New System.Windows.Forms.ComboBox()
        Me.addInterest = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'account
        '
        Me.account.DropDownWidth = 248
        Me.account.Location = New System.Drawing.Point(128, 24)
        Me.account.Name = "account"
        Me.account.Size = New System.Drawing.Size(248, 21)
        Me.account.TabIndex = 1
        '
        'submit
        '
        Me.submit.Location = New System.Drawing.Point(16, 176)
        Me.submit.Name = "submit"
        Me.submit.TabIndex = 2
        Me.submit.Text = "Submit"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Account"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(16, 80)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Action"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(16, 128)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Amount"
        '
        'action
        '
        Me.action.DropDownWidth = 248
        Me.action.Items.AddRange(New Object() {"Deposit", "Withdraw"})
        Me.action.Location = New System.Drawing.Point(128, 80)
        Me.action.Name = "action"
        Me.action.Size = New System.Drawing.Size(248, 21)
        Me.action.TabIndex = 1
        '
        'amount
        '
        Me.amount.DropDownWidth = 248
        Me.amount.Location = New System.Drawing.Point(128, 128)
        Me.amount.Name = "amount"
        Me.amount.Size = New System.Drawing.Size(248, 21)
        Me.amount.TabIndex = 1
        '
        'addInterest
        '
        Me.addInterest.Location = New System.Drawing.Point(128, 176)
        Me.addInterest.Name = "addInterest"
        Me.addInterest.TabIndex = 3
        Me.addInterest.Text = "Add interest"
        Me.addInterest.Visible = False
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(392, 222)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.addInterest, Me.submit, Me.amount, Me.Label3, Me.action, Me.Label2, Me.account, Me.Label1})
        Me.Name = "Form1"
        Me.Text = "The Bank"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.account.Items.Add(checking)
        Me.account.Items.Add(savings)
        Me.account.SelectedIndex = 0
        Me.action.SelectedIndex = 0
        Me.amount.Text = "100"
    End Sub

    Private Sub submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles submit.Click
        Dim selectedAccount As BankAccount
        Dim item As Object = Me.account.SelectedItem
        selectedAccount = CType(item, BankAccount)
        Select Case action.Text
            Case "Deposit"
                selectedAccount.Deposit(Decimal.Parse(amount.Text))
            Case "Withdraw"
                selectedAccount.Withdraw(Decimal.Parse(amount.Text))
        End Select
        MessageBox.Show(String.Format("{0}:{1:C}", _
            selectedAccount.ID, selectedAccount.Balance))

    End Sub

    Private Sub account_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles account.SelectedIndexChanged
        If TypeOf (account.SelectedItem) Is SavingsAccount Then
            addInterest.Visible = True
        Else
            addInterest.Visible = False
        End If
    End Sub

    Private Sub addInterest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addInterest.Click
        If TypeOf (account.SelectedItem) Is SavingsAccount Then
            Dim theSavings As SavingsAccount = _
                CType(account.SelectedItem, SavingsAccount)
            theSavings.AddInterest()
            MessageBox.Show(String.Format("{0}:{1:C}", _
                theSavings.ID, theSavings.Balance))
        End If
    End Sub
End Class
