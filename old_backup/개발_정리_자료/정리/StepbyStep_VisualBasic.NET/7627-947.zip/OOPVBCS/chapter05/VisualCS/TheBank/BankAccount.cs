using System;

namespace TheBank
{
	/// <summary>
	/// Summary description for BankAccount.
	/// </summary>
	public class BankAccount
	{

		protected string m_owner;
		virtual public string ID 
		{
			get 
			{
				return m_owner;
			}
		}

		private decimal m_balance;
		public decimal Balance 
		{
			get 
			{
				return m_balance;
			}
		}

		public BankAccount(string owner)
		{
			m_owner =owner;
			m_balance =0M;
		}

		public decimal Deposit(decimal amount)
		{
			m_balance +=amount;
			return m_balance;
		}

		virtual public decimal Withdraw(decimal amount)
		{
			// since an assignment returns the assigned value, 
			// we need only one line
			return (m_balance -=amount);
		}



	}
}
