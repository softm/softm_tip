using System;

namespace TheBank
{
	/// <summary>
	/// Summary description for CheckingAccount.
	/// </summary>
	public class CheckingAccount :TheBank.BankAccount
	{
		public CheckingAccount(string owner):base(owner)
		{
		}
	
		override public decimal Withdraw(decimal amount)
		{
			base.Withdraw(amount);
			base.Withdraw(0.25M);
			return this.Balance;
		}

		override public string ID 
		{
			get 
			{
				return this.m_owner + "-C";
										
			}
		}


	}
}
