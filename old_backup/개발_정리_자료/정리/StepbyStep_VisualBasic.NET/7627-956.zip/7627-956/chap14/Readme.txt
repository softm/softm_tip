           ========================================

                 Lucky Seven Slot Machine 1.5

          (c) Copyright Michael Halvorson 1995-2001

          =========================================


============================================
Welcome to the Lucky Seven Slot Machine Game
============================================

The following information is available in this README file:


  o  USAGE TIPS
  o  UNINSTALLATION
  o  CONTACT INFORMATION


==========
Usage Tips
==========

You "win" the game by getting a 7 in one of the spinner windows
when you click the Spin button. By my calculations, you will win
the game about 28% of the time. Have fun!

==============
UNINSTALLATION
==============

To Uninstall in Microsoft Windows 98, ME, or 2000:

Click the Start button, click Settings, and then click Control
Panel. Use the Add/Remove Programs tool to remove "Lucky" from
the list of installed programs.

===================
Contact Information
===================

For Information about using the Lucky Seven program, read the
book "Microsoft Visual Basic .NET Step by Step", by Michael
Halvorson (Microsoft Press, 2002).  Chapters 2 and 10 describe
how this program was constructed in detail.  To learn more about
this and other Microsoft Press books, visit the Microsoft Press
web site:  http://www.microsoft.com/mspress/.

