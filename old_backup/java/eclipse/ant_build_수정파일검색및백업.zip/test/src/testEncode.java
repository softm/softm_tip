

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import org.apache.http.NameValuePair;

public class testEncode {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String a = "abcdefg";
		try {
			System.out.println("a : " + a );	
			System.out.println("a : " + URLDecoder.decode(a,"UTF-8") );
		    
			for (NameValuePair i : nameValuePairs) {
		    	
		    }
		    
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}
}
