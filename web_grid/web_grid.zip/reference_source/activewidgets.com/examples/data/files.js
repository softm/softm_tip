
var myData = [
	["Features and benefits.doc", "97KB", "Microsoft Word Document", "27-Feb-03 16:53", "doc"],
	["Readme.txt", "2KB", "Text Document", "12-Apr-03 10:21", "txt"],
	["Web Services - White Paper.pdf", "101KB", "Adobe Acrobat Document", "15-Dec-02 22:10", "pdf"],
	["Expense report.xls", "48KB", "Microsoft Excel Spreadsheet", "18-Oct-03 11:55", "xls"],
	["Price history - MSFT, daily.xml", "580KB", "XML Document", "29-Nov-02 19:31", "xml"],
	["WebMatrix.msi", "1,339KB", "Windows Installer Package", "9-Aug-03 15:06", "msi"],
	["License.txt", "3KB", "Text Document", "19-Sep-02 22:29", "txt"],
	["index.htm", "6KB", "HTML Document", "6-Nov-03 23:55", "htm"],
	["xpmsgr.chm", "72KB", "Compiled HTML Help file", "12-Jul-02 5:00", "chm"]
];

